// native_vio/include/locusmind_vio.h
// Full Visual-Inertial Odometry Backend for LocusMind Approach 5
// OpenVINS-inspired MSCKF + IMU Preintegration + Multi-sensor Fusion
//
// Architecture:
//   - IMU Preintegration: bundles IMU between keyframes into relative motion constraints
//   - MSCKF (Multi-State Constraint Kalman Filter): sliding window of poses + feature tracking
//   - Multi-sensor fusion: barometer altitude + magnetometer heading as constraints
//   - Factor graph optimization: Ceres-based backend for loop closure
//
// Compile: clang++ -O3 -std=c++17 -fPIC -shared -o liblocusmind_vio.so

#ifndef LOCUSMIND_VIO_H
#define LOCUSMIND_VIO_H

#include <cstdint>
#include <cstddef>
#include <vector>
#include <array>
#include <memory>

#ifdef __cplusplus
extern "C" {
#endif

// ═════════════════════════════════════════════════════════════════════════════
//  DATA STRUCTURES
// ═════════════════════════════════════════════════════════════════════════════

// 3D Vector
typedef struct {
    double x, y, z;
} Vec3;

// Quaternion (w, x, y, z)
typedef struct {
    double w, x, y, z;
} Quat;

// 6-DOF Pose: position + orientation
typedef struct {
    Vec3 position;    // meters
    Quat orientation; // quaternion
} Pose6D;

// IMU reading (accelerometer + gyroscope)
typedef struct {
    Vec3 accel;       // m/s^2
    Vec3 gyro;        // rad/s
    uint64_t timestamp_us; // microsecond timestamp from ESP32
} ImuReading;

// Barometer reading
typedef struct {
    double pressure_hpa;  // hectopascals
    double altitude_m;    // computed altitude
    uint64_t timestamp_us;
} BaroReading;

// Magnetometer reading
typedef struct {
    Vec3 magnetic_ut;     // microteslas (x, y, z)
    double heading_deg;   // computed heading
    uint64_t timestamp_us;
} MagReading;

// Visual feature: 2D point in image + descriptor
typedef struct {
    float x, y;           // pixel coordinates (normalized 0-1)
    uint8_t descriptor[32]; // BRIEF binary descriptor (32 bytes = 256 bits)
    uint32_t id;          // feature track ID
} VisualFeature;

// Keyframe: camera pose + features
typedef struct {
    uint64_t timestamp_us;
    Pose6D pose;
    VisualFeature* features;
    uint32_t feature_count;
    uint8_t* thumbnail;   // 32x32 grayscale for quick matching
} Keyframe;

// VIO Output: current state estimate
typedef struct {
    Pose6D pose;              // current 6-DOF pose
    Vec3 velocity;            // m/s
    Vec3 gyro_bias;           // rad/s
    Vec3 accel_bias;          // m/s^2
    double altitude_m;        // from barometer
    double heading_deg;       // from magnetometer
    uint32_t tracked_features;
    uint32_t keyframe_count;
    float confidence;         // 0.0 - 1.0
    uint8_t is_tracking;      // 1 if VIO is valid, 0 otherwise (uint8_t for Dart FFI @Uint8())
    char status_msg[64];      // human-readable status
} VioState;

// Wi-Fi fingerprint for location disambiguation
typedef struct {
    char ssid[32];
    int rssi_dbm;           // signal strength
} WifiAp;

typedef struct {
    WifiAp* aps;
    uint32_t ap_count;
    uint64_t timestamp_us;
} WifiFingerprint;

// Multi-modal loop closure check
typedef struct {
    uint8_t visual_match;     // 1 if visual features match (uint8_t for Dart FFI @Uint8())
    uint8_t altitude_match;   // 1 if barometer within threshold
    uint8_t heading_match;    // 1 if magnetometer within threshold
    uint8_t wifi_match;       // 1 if Wi-Fi signature similar
    float confidence;         // combined confidence
    char rejection_reason[128]; // if rejected, why
} LoopClosureResult;

// ═════════════════════════════════════════════════════════════════════════════
//  C API FUNCTIONS (for Dart FFI)
// ═════════════════════════════════════════════════════════════════════════════

// Initialize VIO system
// Returns handle (opaque pointer) or NULL on failure
void* vio_init(double imu_noise_accel, double imu_noise_gyro,
               double imu_bias_accel, double imu_bias_gyro,
               double barometer_noise, double magnetometer_noise);

// Destroy VIO system
void vio_destroy(void* handle);

// Process IMU batch (called at 10Hz when BLE packet arrives)
void vio_process_imu_batch(void* handle, ImuReading* readings, uint32_t count);

// Process barometer reading
void vio_process_baro(void* handle, BaroReading* reading);

// Process magnetometer reading
void vio_process_mag(void* handle, MagReading* reading);

// Process keyframe with visual features
void vio_process_keyframe(void* handle, Keyframe* keyframe);

// Get current VIO state
void vio_get_state(void* handle, VioState* out_state);

// Check if loop closure should be accepted
void vio_check_loop_closure(void* handle, 
                            const char* candidate_note_id,
                            double candidate_altitude,
                            double candidate_heading,
                            WifiFingerprint* candidate_wifi,
                            LoopClosureResult* out_result);

// Save current pose graph to file
// Returns 1 on success, 0 on failure
int32_t vio_save_map(void* handle, const char* filepath);

// Load pose graph from file
// Returns 1 on success, 0 on failure
int32_t vio_load_map(void* handle, const char* filepath);

// Reset VIO (clear all state, keep calibration)
void vio_reset(void* handle);

// Get feature count for debugging
uint32_t vio_get_feature_count(void* handle);

// Get keyframe count for debugging
uint32_t vio_get_keyframe_count(void* handle);

// ═════════════════════════════════════════════════════════════════════════════
//  VERSION
// ═════════════════════════════════════════════════════════════════════════════

#define LOCUSMIND_VIO_VERSION "2.0.0-approach5"
#define LOCUSMIND_VIO_VERSION_MAJOR 2
#define LOCUSMIND_VIO_VERSION_MINOR 0
#define LOCUSMIND_VIO_VERSION_PATCH 0

#ifdef __cplusplus
}
#endif

#endif // LOCUSMIND_VIO_H
