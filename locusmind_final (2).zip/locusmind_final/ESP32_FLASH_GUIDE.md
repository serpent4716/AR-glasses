# LocusMind ESP32 Flash Guide
# locusmind_vio_v8.ino — XIAO ESP32-S3 Sense

---

## Step 1 — Edit the 3 required constants (lines 63–65)

Open `locusmind_vio_v8.ino` and change these three lines at the top:

```cpp
const char* WIFI_SSID     = "YOUR_WIFI_NAME";     // ← your 2.4GHz network SSID
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";  // ← your Wi-Fi password
const char* PHONE_IP      = "192.168.1.XX";        // ← your phone's local IP
```

**Finding your phone's local IP:**
- Android: Settings → Wi-Fi → tap your network → Advanced → IP address
- iOS: Settings → Wi-Fi → tap (i) next to your network → IP Address

> Note: The Wi-Fi credentials are used only for the on-demand MJPEG camera burst
> feature. BLE works without Wi-Fi. If you only need BLE sensor data, you can
> leave these as placeholders — the device will fail to join Wi-Fi but BLE
> will still advertise and connect normally.

---

## Step 2 — Install required Arduino libraries

Open Arduino IDE → Tools → Manage Libraries → search and install:

| Library | Author | Version |
|---------|--------|---------|
| Adafruit SSD1306 | Adafruit | ≥ 2.5 |
| Adafruit GFX Library | Adafruit | ≥ 1.11 |
| MPU6050 | Electronic Cats | ≥ 1.3 |
| Adafruit BMP280 | Adafruit | ≥ 2.6 |
| QMC5883LCompass | MPrograms | latest |

> ⚠️ Use **QMC5883LCompass** (by MPrograms), NOT the older HMC5883L library.
> The firmware calls `compass.init()`, `compass.read()`, `compass.getX()` etc.
> which are QMC5883LCompass API — the HMC5883L library has a different API.

---

## Step 3 — Board settings in Arduino IDE

Tools menu — set exactly:

| Setting | Value |
|---------|-------|
| Board | XIAO_ESP32S3 |
| Upload Speed | 921600 |
| Flash Mode | QIO 80MHz |
| Partition Scheme | **Huge APP (3MB No OTA)** |
| Core Debug Level | None |
| PSRAM | OPI PSRAM |

> ⚠️ The **Huge APP** partition is required. The firmware uses the grayscale
> frame buffer (160×120 = 19,200 bytes), feature arrays, FreeRTOS tasks
> with large stacks, and the BLE + camera stacks simultaneously.
> The default partition will cause boot crashes.

---

## Step 4 — Flash

1. Connect the XIAO ESP32-S3 Sense via USB-C
2. If the device doesn't appear in Tools → Port, hold the BOOT button while
   plugging in to enter download mode
3. Select the correct COM/tty port in Tools → Port
4. Click Upload (→)
5. Wait for "Hard resetting via RTS pin..." — upload complete

---

## Step 5 — Verify with Serial Monitor

Open Tools → Serial Monitor at **115200 baud**.

Expected boot output (actual messages from the firmware):

```
[BOOT] LocusMind VIO v8 - Approach 5
[OLED] OK
[CAM] OK  QQVGA grayscale 160x120
[IMU] MPU6050 OK
[BARO] BMP280 OK
[MAG] Compass OK
[BOOT] All tasks launched
[BLE] Advertising as 'LocusMind-VIO'
```

Then every 10 seconds a heartbeat:
```
[SYS] Heap: 245760 | Features: 12 | Mode: shi_tomasi | BLE: DISC
```

Once the phone connects via BLE:
```
[BLE] Client connected
[SYS] Heap: 198432 | Features: 18 | Mode: shi_tomasi | BLE: CONN
```

---

## Troubleshooting

**[IMU] MPU6050 not found!**
Check I2C wiring. MPU6050 SDA → D4, SCL → D5. Verify 3.3V power.

**[BARO] BMP280 not found!**
BMP280 I2C address is 0x76. Some modules use 0x77 — change `BMP_ADDR` if needed.

**[CAM] Init FAILED → infinite loop**
Camera pins are hardcoded for XIAO ESP32-S3 Sense. If using a different board
the pin definitions at the top of the file need updating.

**BLE not appearing in phone scan**
The device advertises as `LocusMind-VIO`. If it doesn't appear:
- Check the Serial Monitor for `[BLE] Advertising` message
- Some phones require location permission to be granted before BLE scan returns results
- Try toggling Bluetooth off and back on

**Features always 0 / blackout mode**
Cover and uncover the camera lens — if features jump from 0 to >5, the camera
is working. Pointing at a blank white wall will always give 0 features (by design).

**Heap crashes after a few minutes**
Check the partition scheme is set to "Huge APP (3MB No OTA)".

---

## BLE UUIDs (for reference — must match constants.dart)

```
Service:   6e400001-b5a3-f393-e0a9-e50e24dcca9e
IMU:       6e400002-b5a3-f393-e0a9-e50e24dcca9e
Keyframe:  6e400003-b5a3-f393-e0a9-e50e24dcca9e
Command:   6e400004-b5a3-f393-e0a9-e50e24dcca9e
```

These are already set correctly in both the firmware and `lib/utils/constants.dart`.
Do not change them unless you change both files simultaneously.
