#!/bin/bash
# build_ios.sh — Build C++ VIO backend for iOS
# Usage: ./build_ios.sh
# Output: ios/Runner/Frameworks/liblocusmind_vio.dylib

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/native_vio"
BUILD_DIR="$SRC_DIR/build/ios"
OUTPUT_DIR="$SCRIPT_DIR/ios/Runner/Frameworks"

mkdir -p "$BUILD_DIR"
mkdir -p "$OUTPUT_DIR"

echo "Building LocusMind VIO for iOS..."

cd "$BUILD_DIR"

cmake "$SRC_DIR" \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=12.0 \
    -DCMAKE_BUILD_TYPE=Release \
    -DENABLE_NEON=ON \
    -DBUILD_SHARED_LIBS=ON

make -j$(sysctl -n hw.ncpu)

cp "$BUILD_DIR/liblocusmind_vio.dylib" "$OUTPUT_DIR/"

echo ""
echo "✅ Build complete!"
echo "Output: $OUTPUT_DIR/liblocusmind_vio.dylib"
ls -lh "$OUTPUT_DIR/liblocusmind_vio.dylib"
