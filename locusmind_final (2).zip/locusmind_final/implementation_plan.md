# Option A: Phone-Side Processing + Color Camera + Bug Fixes

## Problem Summary

Three issues identified from the user's screenshots and feedback:

1. **VIO never updates** — The `PhoneVioService` relies on a C++ FFI library (`liblocusmind_vio.so`) that was **never compiled**. The `_initVio()` call fails silently, leaving `_vioHandle == null`. Every subsequent `processImuBatch()`, `processBarometer()`, `processMagnetometer()` call hits `if (_vioHandle == null) return;` and does nothing. This is why all values stay at 0.000 even when the ESP32 is sending data.

2. **Red crash screen when placing a note** — The `_dependents.isEmpty` assertion error from `framework.dart` is caused by the `PhoneVioService` singleton being accessed via both `ChangeNotifierProvider.value()` in main.dart AND via `PhoneVioService()` factory constructor inside `_onImuData()` in `esp32_ble_service.dart`. This creates a provider lifecycle conflict.

3. **Grayscale camera** — The ESP32 camera is configured as `PIXFORMAT_GRAYSCALE` for Shi-Tomasi feature extraction. Since we're moving feature extraction to the phone, we switch to `PIXFORMAT_JPEG` for color output.

## Proposed Changes

### ESP32 Firmware (Simplification)

#### [MODIFY] [locusmind_vio_v8.ino](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/esp32_firmware/locusmind_vio_v8/locusmind_vio_v8.ino)

**Camera → Color JPEG:**
- Change `cfg.pixel_format` from `PIXFORMAT_GRAYSCALE` to `PIXFORMAT_JPEG`
- Set `cfg.jpeg_quality = 12` (good quality color)
- Increase resolution to `FRAMESIZE_QVGA` (320×240) since JPEG is compressed
- Remove the `frame2jpg()` conversion in `streamMjpeg()` — camera already outputs JPEG

**Remove visionTask entirely:**
- Delete the `visionTask()` function and its `xTaskCreatePinnedToCore` call
- Delete all Shi-Tomasi, AGAST, BRIEF code (lines ~182–678)
- Delete `gray_frame[]`, `features[]`, `feature_count`, `current_detector` globals
- This frees ~12KB of stack and significant heap — improves stability

**Simplify BLE packet:**
- Remove `"feat"` and `"mode"` fields from the JSON
- Remove keyframe descriptor sending
- Keep only: `t`, `imu`, `baro`, `alt`, `mag`, `head`

---

### Flutter App — Pure Dart VIO

#### [MODIFY] [phone_slam_vio_service.dart](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/lib/services/phone_slam_vio_service.dart)

**Replace the broken FFI backend with a working pure Dart implementation:**
- Remove all FFI imports and calls (`vioInit`, `vioProcessImuBatch`, etc.)
- Implement a **complementary filter** for orientation (fuses gyro + accel)
- Implement **dead reckoning** for position (double-integrates acceleration in world frame, with gravity removal)
- Use barometer directly for altitude (Z-axis)
- Use magnetometer for heading
- Track confidence based on IMU data quality and movement detection
- Keep the same public API (`currentPose`, `isTracking`, `processImuBatch()`, `processBarometer()`, `processMagnetometer()`, `reset()`, etc.) so no other files need changes

#### [DELETE] [vio_ffi_bindings.dart](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/lib/services/vio_ffi_bindings.dart)

No longer needed — all processing is pure Dart.

---

### Flutter App — Bug Fixes

#### [MODIFY] [esp32_ble_service.dart](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/lib/services/esp32_ble_service.dart)

- Fix `_onImuData()`: Use `Provider.of` or accept the VIO service as a constructor parameter instead of `PhoneVioService()` factory — avoids the `_dependents.isEmpty` crash
- Remove feature/keyframe processing code (no longer sent from ESP32)
- Simplify the BLE packet parsing to match the new simplified ESP32 format

#### [MODIFY] [camera_view_screen.dart](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/lib/screens/camera_view_screen.dart)

- The `_dependents.isEmpty` crash during note placement is triggered by the provider lifecycle conflict above. Once `esp32_ble_service.dart` is fixed, this crash goes away.

#### [MODIFY] [constants.dart](file:///C:/Users/DELL/Downloads/Antigrav/locusmind_final/lib/utils/constants.dart)

- Update default ESP32 IP to `192.168.4.1` (AP mode default)
- Remove VIO FFI tuning constants (no longer used)

---

### Files NOT Changed (kept as-is)
- `main.dart` — provider setup stays the same
- `home_screen.dart` — no changes needed
- `vio_debug_screen.dart` — reads from `PhoneVioService` which keeps same API
- `slam_map_screen.dart` — reads from `PhoneVioService` which keeps same API
- All model files, providers, widgets

## Verification Plan

### Manual Verification
1. Upload new ESP32 firmware → serial monitor shows `[CAM] OK QVGA JPEG 320x240`, no `visionTask` log
2. Connect phone to `LocusMind_Camera` Wi-Fi → camera view shows **color** video
3. Open VIO Debug screen → Position/Heading values change when moving the sensors
4. Place a note → no red crash screen
5. BLE connection → `Packets` count increases, `Rate` shows ~10 Hz
