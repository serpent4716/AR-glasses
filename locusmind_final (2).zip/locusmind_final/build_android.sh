#!/bin/bash
# build_android.sh — Build C++ VIO backend for Android
# Usage: ./build_android.sh <NDK_PATH> <API_LEVEL>
# Example: ./build_android.sh /home/user/Android/Sdk/ndk/25.2.9519653 24

set -e

NDK_PATH=${1:-$ANDROID_NDK_HOME}
API_LEVEL=${2:-24}

if [ -z "$NDK_PATH" ]; then
    echo "ERROR: NDK path not provided and ANDROID_NDK_HOME not set"
    echo "Usage: $0 <ndk_path> [api_level]"
    exit 1
fi

echo "Building LocusMind VIO for Android..."
echo "NDK: $NDK_PATH"
echo "API Level: $API_LEVEL"

# Toolchain
TOOLCHAIN=$NDK_PATH/toolchains/llvm/prebuilt/linux-x86_64
TARGET=aarch64-linux-android
CC=$TOOLCHAIN/bin/$TARGET$API_LEVEL-clang
CXX=$TOOLCHAIN/bin/$TARGET$API_LEVEL-clang++
AR=$TOOLCHAIN/bin/llvm-ar
STRIP=$TOOLCHAIN/bin/llvm-strip

# Directories
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/native_vio"
BUILD_DIR="$SRC_DIR/build/android"
OUTPUT_DIR="$SCRIPT_DIR/android/app/src/main/jniLibs/arm64-v8a"

mkdir -p "$BUILD_DIR"
mkdir -p "$OUTPUT_DIR"

# Build
cd "$BUILD_DIR"

cmake "$SRC_DIR" \
    -DCMAKE_TOOLCHAIN_FILE="$NDK_PATH/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM=android-$API_LEVEL \
    -DCMAKE_BUILD_TYPE=Release \
    -DENABLE_NEON=ON \
    -DBUILD_SHARED_LIBS=ON

make -j$(nproc)

# Copy output
cp "$BUILD_DIR/liblocusmind_vio.so" "$OUTPUT_DIR/"
$STRIP "$OUTPUT_DIR/liblocusmind_vio.so"

echo ""
echo "✅ Build complete!"
echo "Output: $OUTPUT_DIR/liblocusmind_vio.so"
ls -lh "$OUTPUT_DIR/liblocusmind_vio.so"
