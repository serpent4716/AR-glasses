# LocusMind — Merged v10 (Flutter App + ESP32-S3 Firmware)

## What was fixed in this merge

### Performance (laggy/glitchy camera feed)
- **Frame throttling**: ESP32Service now limits UI rebuild notifications to ~12 fps max.
  The SLAM pipeline still receives every frame via a separate `frameStream` broadcast.
  This stops the widget tree from being hammered 30+ times per second.
- **SLAM debounce**: PhoneSlamService now runs only ONE NCC isolate at a time.
  If a frame arrives while processing, it is queued as a pending frame instead of
  spawning a second parallel `compute()` call. This was the primary cause of lag.
- **Buffer capped**: MJPEG buffer is capped at 200KB (was 500KB) to reduce RAM pressure.
- **SLAM timer**: Camera screen polls SLAM every 500ms (was 250ms) — halves CPU load.

### Red screen / `_dependents.isEmpty` crash
- **Root cause**: `context.watch<PhoneSlamService>()` was being called inside
  `AnimatedBuilder.builder` which runs mid-animation-tick (mid-frame). This corrupts
  Flutter's dependency tracking.
- **Fix** (already in v9 slam_visualizer_icon.dart): All SLAM state is read via
  `addListener` registered in `didChangeDependencies` — never inside any build/animation
  callback. `AnimatedBuilder.builder` reads only plain Dart fields.

### "Tried to build dirty widget in the wrong build scope" crash
- **Root cause**: The Add Note dialog in CameraViewScreen used `Navigator.pop(ctx)` 
  where `ctx` is the `StatefulBuilder` dialog context. After a `setState` inside
  `StatefulBuilder`, that context can be stale.
- **Fix**: Dialog now calls `Navigator.pop(ctx)` to dismiss itself first, THEN reads
  `context` (screen-level, always valid) for provider access and snackbars.
  Also, `TextEditingController` is disposed in a `finally` block to prevent leaks.

### IMU socket crash
- **Fix**: `startImuReceiver()` now guards against double-binding with an early return
  if the socket is already open.

## Project structure
```
lib/
  main.dart                    — App entry point, singleton providers
  models/note.dart             — Note data model
  database/database_helper.dart — SQLite persistence
  providers/
    notes_provider.dart        — Note state + GPS
    theme_provider.dart        — Theme persistence
  screens/
    splash_screen.dart
    login_screen.dart          — Demo: admin / locusmind
    home_screen.dart
    camera_view_screen.dart    — AR camera + SLAM overlay (FIXED)
    add_edit_note_screen.dart  — Create/edit notes
    settings_screen.dart       — ESP32 IP, PC SLAM URL
    slam_map_screen.dart       — GPS + SLAM top-down map
  services/
    esp32_service.dart         — MJPEG stream + UDP IMU/OLED (THROTTLED)
    phone_slam_service.dart    — NCC SLAM (DEBOUNCED)
    speech_service.dart        — Voice-to-text
    auth_service.dart          — Local auth
  widgets/
    slam_visualizer_icon.dart  — AR overlay + 3D cube (CRASH FIXED)
    note_card.dart
    scrolling_note_text.dart
    sync_status_banner.dart
  utils/constants.dart

esp32_firmware/locusmind_s3/locusmind_s3.ino  — Flash to XIAO ESP32-S3 Sense
```

## Build & run
```bash
flutter pub get
flutter run
```

## ESP32 setup
1. Flash `esp32_firmware/locusmind_s3/locusmind_s3.ino` via Arduino IDE
2. Note the IP shown in Serial Monitor
3. In app → Settings → enter ESP32 IP → Save IP
4. Open Camera View — stream should start automatically
