// main.dart — LocusMind VIO v11
//
// Singletons pre-created at app level and injected via .value() so the
// provider tree never owns their lifecycle and never calls dispose() on them.
// preloadConfig() ensures the saved ESP32 IP is loaded before any screen
// calls startStream(), avoiding the race condition with the default IP.
//
// New in v11:
//   • PhoneSlamService replaced by PhoneVioService (MSCKF + FFI)
//   • Esp32BleService added alongside Esp32Service (Wi-Fi camera stays)
//   • WiFiFingerprintService + ContextClassifierService added
//   • MapPersistenceService.initialize() called after runApp

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/notes_provider.dart';
import 'providers/theme_provider.dart';
import 'services/esp32_service.dart';
import 'services/esp32_ble_service.dart';
import 'services/phone_slam_vio_service.dart';
import 'services/wifi_fingerprint_service.dart';
import 'services/context_classifier_service.dart';
import 'services/map_persistence_service.dart';
import 'services/speech_service.dart';
import 'screens/splash_screen.dart';
import 'utils/constants.dart';

// ── App-level singletons ───────────────────────────────────────────────────
// Created here so they outlive any individual screen and are never
// accidentally disposed by the provider tree.
final _esp32Service    = Esp32Service();
final _phoneVioService = PhoneVioService();
final _esp32BleService = Esp32BleService(_phoneVioService);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _esp32Service.preloadConfig();
  runApp(const LocusMindApp());
  // Initialize map persistence after first frame — loads saved pose graph
  // and starts 30-second auto-save timer.
  WidgetsBinding.instance.addPostFrameCallback((_) {
    MapPersistenceService(_phoneVioService).initialize();
  });
}

class LocusMindApp extends StatelessWidget {
  const LocusMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()..loadTheme()),
        ChangeNotifierProvider(create: (_) => NotesProvider()),
        // Wi-Fi MJPEG camera + UDP IMU stream (unchanged)
        ChangeNotifierProvider.value(value: _esp32Service),
        // BLE 5.0 sensor stream (IMU batch + baro + mag + keyframes)
        ChangeNotifierProvider.value(value: _esp32BleService),
        // MSCKF VIO backend via C++ FFI
        ChangeNotifierProvider.value(value: _phoneVioService),
        // Wi-Fi fingerprinting for loop closure
        ChangeNotifierProvider(create: (_) => WiFiFingerprintService()),
        // Environment classifier + dynamic VIO params
        ChangeNotifierProvider(create: (_) => ContextClassifierService(_phoneVioService)),
        ChangeNotifierProvider(create: (_) => SpeechService()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (_, tp, __) => MaterialApp(
          title: kAppName,
          debugShowCheckedModeBanner: false,
          theme: lightTheme,
          darkTheme: darkTheme,
          themeMode: tp.themeMode,
          home: const SplashScreen(),
        ),
      ),
    );
  }
}
