// utils/constants.dart
// App-wide constants, theme data, and shared-preferences keys.

import 'package:flutter/material.dart';

// ── App metadata ──────────────────────────────────────────────────────────────
const String kAppName = 'LocusMind';
const String kAppVersion = '1.0.0';

// ── SharedPreferences keys ────────────────────────────────────────────────────
const String kPrefIsLoggedIn = 'is_logged_in';
const String kPrefUsername = 'username';
const String kPrefApiBaseUrl = 'api_base_url'; // Pi server URL
const String kPrefPcSlamUrl = 'pc_slam_url'; // PC SLAM server URL
const String kPrefThemeMode = 'theme_mode';

// ── Default server URLs ───────────────────────────────────────────────────────
/// Raspberry Pi Flask server (pi_server.py) — port 5000.
const String kDefaultPiBaseUrl = 'http://192.168.1.100:5000';

/// PC SLAM server (pc_slam_server.py) — port 6001. Empty = disabled.
const String kDefaultPcSlamUrl = '';

// ── API timeout ───────────────────────────────────────────────────────────────
const Duration kApiTimeout = Duration(seconds: 10);

// ── Demo credentials ──────────────────────────────────────────────────────────
const String kDemoUsername = 'admin';
const String kDemoPassword = 'locusmind';

// ── Note color presets (hex strings matching Pi's format) ─────────────────────
const List<String> kPresetColors = [
  '#00FF88', // Pi default — bright green
  '#FF6B6B', // red
  '#4ECDC4', // teal
  '#FFE66D', // yellow
  '#A8E6CF', // mint
  '#FF8B94', // pink
  '#7EC8E3', // sky blue
  '#C3A6FF', // lavender
];

// ── TTL presets for voice-note and quick-add expiry dropdown ──────────────────
/// Maps display label → seconds until expiry (0 = never expires).
const Map<String, int> kTtlPresets = {
  'Never':   0,
  '1 hour':  3600,
  '6 hours': 21600,
  '1 day':   86400,
  '1 week':  604800,
  '1 month': 2592000,
};

// ── Material 3 theme ──────────────────────────────────────────────────────────
final ThemeData lightTheme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    seedColor: const Color(0xFF6750A4),
    brightness: Brightness.light,
  ),
  appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
  cardTheme: CardThemeData(
    elevation: 2,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    filled: true,
  ),
  snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
);

final ThemeData darkTheme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    seedColor: const Color(0xFF6750A4),
    brightness: Brightness.dark,
  ),
  appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
  cardTheme: CardThemeData(
    elevation: 2,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    filled: true,
  ),
  snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
);

// ── ESP32-S3 config ───────────────────────────────────────────────────────────
const String kPrefEsp32Ip       = 'esp32_ip';
const String kPrefEsp32OledPort = 'esp32_oled_port';
const String kPrefEsp32ImuPort  = 'esp32_imu_port';

const String kDefaultEsp32Ip       = '192.168.1.200'; // Change after flashing ESP32
const int    kDefaultEsp32OledPort = 4211;  // UDP port for OLED commands
const int    kDefaultEsp32ImuPort  = 4212;  // UDP port for IMU data
const String kDefaultEsp32StreamUrl = '/stream'; // MJPEG endpoint on ESP32

// ── BLE 5.0 UUIDs (must match ESP32 firmware exactly) ────────────────────────
const String BLE_SERVICE_UUID        = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
const String BLE_IMU_CHAR_UUID       = '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
const String BLE_KEYFRAME_CHAR_UUID  = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
const String BLE_COMMAND_CHAR_UUID   = '6e400004-b5a3-f393-e0a9-e50e24dcca9e';

// ── BLE SharedPreferences keys ────────────────────────────────────────────────
const String kPrefBleDeviceName  = 'ble_device_name';
const String kPrefBleAutoConnect = 'ble_auto_connect';

// ── VIO tuning constants (MPU6050 tuned values) ───────────────────────────────
const double kVioImuNoiseAccel = 0.01;    // m/s²/sqrt(Hz)
const double kVioImuNoiseGyro  = 0.001;   // rad/s/sqrt(Hz)
const double kVioImuBiasAccel  = 0.0001;  // m/s²/sqrt(Hz)
const double kVioImuBiasGyro   = 0.00001; // rad/s/sqrt(Hz)
const double kVioBaroNoise     = 0.5;     // meters
const double kVioMagNoise      = 0.1;     // degrees

// ── Loop closure thresholds ───────────────────────────────────────────────────
const double kLoopClosureAltThresholdM    = 0.30; // 30 cm barometer tolerance
const double kLoopClosureHeadingThreshDeg = 5.0;  // 5° heading tolerance
const int    kLoopClosureMinVisualInliers = 3;
