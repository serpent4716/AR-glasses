// database/database_helper.dart
// SQLite local cache — schema matches Note.toMap() / Note.fromMap().
//
// v4: added anchor_altitude, mag_fingerprint, wifi_fingerprint columns
//     for VIO multi-modal loop closure.

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/note.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _db;
  static const String _dbName = 'locusmind_v4.db';
  static const int _dbVersion = 4;
  static const String _tNotes = 'notes';

  Future<Database> get database async {
    _db ??= await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final path = join(await getDatabasesPath(), _dbName);
    return openDatabase(path, version: _dbVersion,
        onCreate: _onCreate, onUpgrade: _onUpgrade);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $_tNotes (
        id               TEXT    PRIMARY KEY,
        text             TEXT    NOT NULL DEFAULT '',
        color            TEXT    NOT NULL DEFAULT '#00FF88',
        visible          INTEGER NOT NULL DEFAULT 1,
        auto_shown       INTEGER NOT NULL DEFAULT 0,
        anchor_lat       REAL,
        anchor_lon       REAL,
        anchor_fixed     INTEGER NOT NULL DEFAULT 0,
        distance_m       REAL    NOT NULL DEFAULT 0.0,
        pose_tracked     INTEGER NOT NULL DEFAULT 0,
        x                INTEGER NOT NULL DEFAULT 180,
        y                INTEGER NOT NULL DEFAULT 185,
        w                INTEGER NOT NULL DEFAULT 280,
        h                INTEGER NOT NULL DEFAULT 110,
        created_at       REAL    NOT NULL,
        expiry_time      INTEGER,
        is_pending_sync  INTEGER NOT NULL DEFAULT 0,
        anchor_altitude  REAL,
        mag_fingerprint  TEXT,
        wifi_fingerprint TEXT
      )
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 3) {
      // Add expiry_time column to existing db without data loss.
      try {
        await db.execute(
            'ALTER TABLE $_tNotes ADD COLUMN expiry_time INTEGER');
      } catch (_) {
        // Column may already exist (safe to ignore).
      }
    }
    if (oldVersion < 4) {
      // Add VIO multi-modal loop closure columns.
      try {
        await db.execute('ALTER TABLE $_tNotes ADD COLUMN anchor_altitude REAL');
        await db.execute('ALTER TABLE $_tNotes ADD COLUMN mag_fingerprint TEXT');
        await db.execute('ALTER TABLE $_tNotes ADD COLUMN wifi_fingerprint TEXT');
      } catch (_) {
        // Columns may already exist (safe to ignore).
      }
    }
  }

  Future<void> upsertNote(Note note) async {
    final db = await database;
    await db.insert(_tNotes, note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Note>> getAllNotes() async {
    final db   = await database;
    final rows = await db.query(_tNotes, orderBy: 'created_at DESC');
    return rows.map(Note.fromMap).toList();
  }

  Future<Note?> getNoteById(String id) async {
    final db   = await database;
    final rows = await db.query(_tNotes,
        where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : Note.fromMap(rows.first);
  }

  Future<void> deleteNote(String id) async {
    final db = await database;
    await db.delete(_tNotes, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteExpiredNotes() async {
    final db  = await database;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.delete(_tNotes,
        where: 'expiry_time IS NOT NULL AND expiry_time > 0 AND expiry_time < ?',
        whereArgs: [now]);
  }

  Future<List<Note>> getPendingSyncNotes() async {
    final db   = await database;
    final rows = await db.query(_tNotes,
        where: 'is_pending_sync = ?', whereArgs: [1]);
    return rows.map(Note.fromMap).toList();
  }

  /// Replace entire local cache with the list fetched from the Pi.
  Future<void> replaceAll(List<Note> serverNotes) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(_tNotes);
      for (final n in serverNotes) {
        await txn.insert(_tNotes, n.toMap());
      }
    });
  }

  Future<void> clearAll() async {
    final db = await database;
    await db.delete(_tNotes);
  }
}
