// models/note.dart — FIXED (F9)
//
// FIX F9: copyWith() now accepts an explicit sentinel so that
// expiryTime CAN be cleared to null.  Pass clearExpiry: true
// instead of expiryTime: null when you want to remove a TTL.

import 'package:flutter/material.dart';

class Note {
  final String id;
  String text;
  String color;
  bool visible;
  bool autoShown;
  double? anchorLat;
  double? anchorLon;
  bool anchorFixed;
  double distanceM;
  bool poseTracked;
  int x, y, w, h;
  double createdAt;
  bool isPendingSync;
  DateTime? expiryTime;
  double? anchorAltitude;   // barometer altitude at note anchor (meters)
  String? magFingerprint;   // magnetometer heading at anchor as string (degrees)
  String? wifiFingerprint;  // JSON string of {ssid: rssiDbm} map at anchor

  Note({
    required this.id,
    required this.text,
    this.color = '#00FF88',
    this.visible = true,
    this.autoShown = false,
    this.anchorLat,
    this.anchorLon,
    this.anchorFixed = false,
    this.distanceM = 0.0,
    this.poseTracked = false,
    this.x = 180,
    this.y = 185,
    this.w = 280,
    this.h = 110,
    double? createdAt,
    this.isPendingSync = false,
    this.expiryTime,
    this.anchorAltitude,
    this.magFingerprint,
    this.wifiFingerprint,
  }) : createdAt = createdAt ??
            DateTime.now().millisecondsSinceEpoch / 1000.0;

  // ── Expiry helpers ───────────────────────────────────────────────

  bool get isExpired {
    if (expiryTime == null) return false;
    return DateTime.now().isAfter(expiryTime!);
  }

  Duration? get timeRemaining {
    if (expiryTime == null) return null;
    final remaining = expiryTime!.difference(DateTime.now());
    return remaining.isNegative ? null : remaining;
  }

  // ── JSON serialisation ───────────────────────────────────────────

  Map<String, dynamic> toCreateJson() => {
        'text': text,
        'color': color,
      };

  Map<String, dynamic> toUpdateJson() => {
        'text': text,
        'color': color,
        'visible': visible,
        'x': x,
        'y': y,
        'w': w,
        'h': h,
      };

  factory Note.fromJson(Map<String, dynamic> j) => Note(
        id: j['id']?.toString() ?? '',
        text: j['text'] ?? '',
        color: j['color'] ?? '#00FF88',
        visible: j['visible'] ?? true,
        autoShown: j['auto_shown'] ?? false,
        anchorLat: (j['anchor_lat'] as num?)?.toDouble(),
        anchorLon: (j['anchor_lon'] as num?)?.toDouble(),
        anchorFixed: j['anchor_fixed'] ?? false,
        distanceM: (j['distance_m'] as num?)?.toDouble() ?? 0.0,
        poseTracked: j['pose_tracked'] ?? false,
        x: (j['x'] as num?)?.toInt() ?? 180,
        y: (j['y'] as num?)?.toInt() ?? 185,
        w: (j['w'] as num?)?.toInt() ?? 280,
        h: (j['h'] as num?)?.toInt() ?? 110,
        createdAt: (j['created_at'] as num?)?.toDouble() ??
            DateTime.now().millisecondsSinceEpoch / 1000.0,
        isPendingSync: false,
        anchorAltitude:  (j['anchor_altitude'] as num?)?.toDouble(),
        magFingerprint:  j['mag_fingerprint'] as String?,
        wifiFingerprint: j['wifi_fingerprint'] as String?,
      );

  // ── SQLite serialisation ─────────────────────────────────────────

  Map<String, dynamic> toMap() => {
        'id': id,
        'text': text,
        'color': color,
        'visible': visible ? 1 : 0,
        'auto_shown': autoShown ? 1 : 0,
        'anchor_lat': anchorLat,
        'anchor_lon': anchorLon,
        'anchor_fixed': anchorFixed ? 1 : 0,
        'distance_m': distanceM,
        'pose_tracked': poseTracked ? 1 : 0,
        'x': x,
        'y': y,
        'w': w,
        'h': h,
        'created_at': createdAt,
        'expiry_time': expiryTime?.millisecondsSinceEpoch,
        'is_pending_sync': isPendingSync ? 1 : 0,
        'anchor_altitude':  anchorAltitude,
        'mag_fingerprint':  magFingerprint,
        'wifi_fingerprint': wifiFingerprint,
      };

  factory Note.fromMap(Map<String, dynamic> m) => Note(
        id: m['id'],
        text: m['text'] ?? '',
        color: m['color'] ?? '#00FF88',
        visible: (m['visible'] ?? 1) == 1,
        autoShown: (m['auto_shown'] ?? 0) == 1,
        anchorLat: m['anchor_lat'] as double?,
        anchorLon: m['anchor_lon'] as double?,
        anchorFixed: (m['anchor_fixed'] ?? 0) == 1,
        distanceM: (m['distance_m'] as num?)?.toDouble() ?? 0.0,
        poseTracked: (m['pose_tracked'] ?? 0) == 1,
        x: (m['x'] as num?)?.toInt() ?? 180,
        y: (m['y'] as num?)?.toInt() ?? 185,
        w: (m['w'] as num?)?.toInt() ?? 280,
        h: (m['h'] as num?)?.toInt() ?? 110,
        createdAt: (m['created_at'] as num?)?.toDouble() ??
            DateTime.now().millisecondsSinceEpoch / 1000.0,
        expiryTime: m['expiry_time'] != null
            ? DateTime.fromMillisecondsSinceEpoch(m['expiry_time'] as int)
            : null,
        isPendingSync: (m['is_pending_sync'] ?? 0) == 1,
        anchorAltitude:  m['anchor_altitude'] as double?,
        magFingerprint:  m['mag_fingerprint'] as String?,
        wifiFingerprint: m['wifi_fingerprint'] as String?,
      );

  // FIX F9: Use `clearExpiry: true` to explicitly set expiryTime to null.
  // The old `expiryTime: null` pattern was silently ignored (kept old value).
  Note copyWith({
    String?   id,
    String?   text,
    String?   color,
    bool?     visible,
    bool?     autoShown,
    double?   anchorLat,
    double?   anchorLon,
    bool?     anchorFixed,
    double?   distanceM,
    bool?     poseTracked,
    int?      x,
    int?      y,
    int?      w,
    int?      h,
    double?   createdAt,
    bool?     isPendingSync,
    DateTime? expiryTime,
    bool      clearExpiry = false,   // FIX F9: set true to clear TTL to null
    double?   anchorAltitude,
    String?   magFingerprint,
    String?   wifiFingerprint,
  }) =>
      Note(
        id:            id            ?? this.id,
        text:          text          ?? this.text,
        color:         color         ?? this.color,
        visible:       visible       ?? this.visible,
        autoShown:     autoShown     ?? this.autoShown,
        anchorLat:     anchorLat     ?? this.anchorLat,
        anchorLon:     anchorLon     ?? this.anchorLon,
        anchorFixed:   anchorFixed   ?? this.anchorFixed,
        distanceM:     distanceM     ?? this.distanceM,
        poseTracked:   poseTracked   ?? this.poseTracked,
        x:             x             ?? this.x,
        y:             y             ?? this.y,
        w:             w             ?? this.w,
        h:             h             ?? this.h,
        createdAt:     createdAt     ?? this.createdAt,
        isPendingSync: isPendingSync ?? this.isPendingSync,
        // FIX F9: clearExpiry flag wins over the provided value.
        expiryTime:    clearExpiry ? null : (expiryTime ?? this.expiryTime),
        anchorAltitude:  anchorAltitude  ?? this.anchorAltitude,
        magFingerprint:  magFingerprint  ?? this.magFingerprint,
        wifiFingerprint: wifiFingerprint ?? this.wifiFingerprint,
      );

  // ── Color helpers ────────────────────────────────────────────────

  Color get flutterColor => _hexToColor(color);

  static String colorToHex(Color c) =>
      '#${c.red.toRadixString(16).padLeft(2, '0')}'
      '${c.green.toRadixString(16).padLeft(2, '0')}'
      '${c.blue.toRadixString(16).padLeft(2, '0')}'.toUpperCase();

  static Color _hexToColor(String hex) {
    final h = hex.replaceAll('#', '');
    if (h.length == 6) return Color(int.parse('FF$h', radix: 16));
    return const Color(0xFF00FF88);
  }

  DateTime get createdAtDateTime =>
      DateTime.fromMillisecondsSinceEpoch((createdAt * 1000).toInt());

  @override
  String toString() =>
      'Note{id: $id, text: "${text.substring(0, text.length.clamp(0, 30))}"}';
}

// ── GPS state model ───────────────────────────────────────────────────────────

class GpsState {
  final double? lat;
  final double? lon;
  final bool fix;
  final int satellites;
  final double hdop;
  final double? ageSeconds;

  const GpsState({
    this.lat, this.lon,
    this.fix = false,
    this.satellites = 0,
    this.hdop = 99,
    this.ageSeconds,
  });

  factory GpsState.fromJson(Map<String, dynamic> j) => GpsState(
        lat: (j['lat'] as num?)?.toDouble(),
        lon: (j['lon'] as num?)?.toDouble(),
        fix: j['fix'] ?? false,
        satellites: (j['satellites'] as num?)?.toInt() ?? 0,
        hdop: (j['hdop'] as num?)?.toDouble() ?? 99,
        ageSeconds: (j['age_s'] as num?)?.toDouble(),
      );

  String get summary => fix
      ? '${satellites}sat  HDOP:${hdop.toStringAsFixed(1)}  '
        '${lat?.toStringAsFixed(5)},${lon?.toStringAsFixed(5)}'
      : 'No GPS fix';
}

// ── SLAM status model ─────────────────────────────────────────────────────────

class SlamStatus {
  final bool tracking;
  final int keypoints;
  final double fps;

  const SlamStatus({
    this.tracking = false,
    this.keypoints = 0,
    this.fps = 0,
  });

  factory SlamStatus.fromJson(Map<String, dynamic> j) => SlamStatus(
        tracking: j['tracking'] ?? false,
        keypoints: (j['keypoints'] as num?)?.toInt() ?? 0,
        fps: (j['fps'] as num?)?.toDouble() ?? 0,
      );
}
