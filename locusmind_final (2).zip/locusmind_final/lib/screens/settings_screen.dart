// screens/settings_screen.dart — UPDATED (F8 + PC SLAM option)
//
// Additions:
//  • PC SLAM server section (optional, can be left blank to use phone-only SLAM)
//  • IMU UDP note (F8): explains broadcast limitation and recommends setting
//    PHONE_IP to a real IP in the firmware for reliable IMU delivery.
//  • SlamStatusIcon visible in the About card for visual confirmation.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/theme_provider.dart';
import '../services/esp32_service.dart';

import '../utils/constants.dart';
import '../widgets/slam_visualizer_icon.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _esp32IpCtrl  = TextEditingController();
  final _pcSlamCtrl   = TextEditingController();

  bool    _testingEsp  = false;
  bool    _testingPc   = false;
  String? _espResult;
  String? _pcResult;
  bool    _pcSlamEnabled = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _esp32IpCtrl.text  = prefs.getString(kPrefEsp32Ip) ?? kDefaultEsp32Ip;
    final pcUrl = prefs.getString(kPrefPcSlamUrl) ?? '';
    _pcSlamCtrl.text   = pcUrl;
    _pcSlamEnabled     = pcUrl.isNotEmpty;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _esp32IpCtrl.dispose();
    _pcSlamCtrl.dispose();
    super.dispose();
  }

  // ── ESP32 actions ─────────────────────────────────────────

  Future<void> _saveEsp32Ip() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kPrefEsp32Ip, _esp32IpCtrl.text.trim());
    // Flush the in-memory IP cache so the next connection uses this new value.
    if (mounted) context.read<Esp32Service>().invalidateConfig();
    _snack('ESP32 IP saved');
  }

  Future<void> _testEsp32() async {
    setState(() { _testingEsp = true; _espResult = null; });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kPrefEsp32Ip, _esp32IpCtrl.text.trim());
    final ok = await context.read<Esp32Service>().pingEsp32();
    setState(() {
      _testingEsp = false;
      _espResult = ok
          ? '✅ ESP32 reachable!'
          : '❌ Cannot reach ESP32. Check IP and confirm you are on the same Wi-Fi network.';
    });
  }

  // ── PC SLAM actions ───────────────────────────────────────

  Future<void> _savePcSlam() async {
    final prefs = await SharedPreferences.getInstance();
    final url = _pcSlamEnabled ? _pcSlamCtrl.text.trim() : '';
    await prefs.setString(kPrefPcSlamUrl, url);
    _snack(url.isEmpty ? 'PC SLAM disabled — using phone SLAM' : 'PC SLAM URL saved');
  }

  Future<void> _testPcSlam() async {
    final url = _pcSlamCtrl.text.trim();
    if (url.isEmpty) { _snack('Enter a PC SLAM URL first'); return; }
    setState(() { _testingPc = true; _pcResult = null; });
    try {
      final uri = Uri.parse('$url/status');
      // Simple GET to /status on the PC SLAM server (pc_slam_server.py exposes it)
      final client = context.read<Esp32Service>();
      final ok = await client.pingEsp32().timeout(const Duration(seconds: 4));
      // We just do an HTTP test via the platform; use http package approach below.
      throw UnimplementedError(); // fallthrough to generic test
    } catch (_) {
      // Basic reachability test
      try {
        final uri = Uri.parse('${_pcSlamCtrl.text.trim()}/status');
        final response = await Future.any([
          Future.delayed(const Duration(seconds: 4), () => null),
        ]);
        setState(() {
          _testingPc = false;
          _pcResult = '⚠️ Could not connect to PC SLAM server. Ensure pc_slam_server.py is running.';
        });
      } catch (e) {
        setState(() {
          _testingPc = false;
          _pcResult = '❌ Error: $e';
        });
      }
    }
  }

  // ── Helpers ───────────────────────────────────────────────

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          // ── ESP32-S3 ────────────────────────────────────────
          _SectionHeader('XIAO ESP32-S3 Sense', Icons.developer_board),
          const SizedBox(height: 6),
          Text(
            'The ESP32 streams MJPEG on port 80 (/stream). '
            'It receives note text via UDP ${kDefaultEsp32OledPort} '
            'and sends IMU data on UDP ${kDefaultEsp32ImuPort}.',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 6),
          // FIX F8 note:
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.orange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.orange.withOpacity(0.4)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.info_outline, color: Colors.orange, size: 16),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'IMU UDP fix: If IMU data is not arriving, change PHONE_IP in '
                'the firmware from "255.255.255.255" to your phone\'s actual '
                'IP address. Most home routers block broadcast UDP.',
                style: theme.textTheme.bodySmall?.copyWith(color: Colors.orange.shade800),
              )),
            ]),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: _esp32IpCtrl,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'ESP32 IP address',
              prefixIcon: const Icon(Icons.wifi),
              hintText: kDefaultEsp32Ip,
              helperText: 'Find it in Serial Monitor after flashing',
            ),
          ),
          if (_espResult != null) ...[const SizedBox(height: 8), _ResultBanner(_espResult!)],
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: _testingEsp ? null : _testEsp32,
              icon: _testingEsp
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.wifi_find_outlined),
              label: const Text('Test Connection'),
            )),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: _saveEsp32Ip,
              icon: const Icon(Icons.save_outlined),
              label: const Text('Save IP'),
            )),
          ]),
          const SizedBox(height: 28),

          // ── PC SLAM Server (optional) ────────────────────────
          _SectionHeader('PC SLAM Server (optional)', Icons.computer_outlined),
          const SizedBox(height: 6),
          Text(
            'Run pc_slam_server.py on a laptop on the same Wi-Fi to use '
            'full ORB descriptor matching instead of the phone\'s lightweight '
            'NCC tracker. Leave blank to use phone-only SLAM.',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Enable PC SLAM', style: TextStyle(fontSize: 14)),
            subtitle: Text(
              _pcSlamEnabled ? 'Frames will be sent to the PC server' : 'Using phone-only SLAM',
              style: theme.textTheme.bodySmall,
            ),
            value: _pcSlamEnabled,
            onChanged: (v) => setState(() => _pcSlamEnabled = v),
          ),
          if (_pcSlamEnabled) ...[
            const SizedBox(height: 6),
            TextFormField(
              controller: _pcSlamCtrl,
              keyboardType: TextInputType.url,
              enabled: _pcSlamEnabled,
              decoration: const InputDecoration(
                labelText: 'PC SLAM server URL',
                prefixIcon: Icon(Icons.link),
                hintText: 'http://192.168.1.50:6001',
                helperText: 'Run: python pc_slam_server.py --port 6001',
              ),
            ),
            if (_pcResult != null) ...[const SizedBox(height: 8), _ResultBanner(_pcResult!)],
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: FilledButton.icon(
                onPressed: _savePcSlam,
                icon: const Icon(Icons.save_outlined),
                label: const Text('Save & Enable'),
              )),
            ]),
            const SizedBox(height: 6),
            Text(
              'How to run: pip install flask opencv-python numpy  •  '
              'python pc_slam_server.py',
              style: theme.textTheme.bodySmall?.copyWith(
                  fontFamily: 'monospace',
                  color: theme.colorScheme.onSurfaceVariant),
            ),
          ] else ...[
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: _savePcSlam,
              icon: const Icon(Icons.save_outlined),
              label: const Text('Save (disabled)'),
            ),
          ],
          const SizedBox(height: 28),

          // ── Theme ────────────────────────────────────────────
          _SectionHeader('Appearance', Icons.palette_outlined),
          const SizedBox(height: 8),
          Consumer<ThemeProvider>(
            builder: (_, tp, __) => Card(
              margin: EdgeInsets.zero,
              child: Column(children: [
                _ThemeTile('System Default', Icons.brightness_auto,
                    tp.themeMode == ThemeMode.system, () => tp.setTheme(ThemeMode.system)),
                const Divider(height: 1, indent: 16),
                _ThemeTile('Light', Icons.light_mode_outlined,
                    tp.themeMode == ThemeMode.light, () => tp.setTheme(ThemeMode.light)),
                const Divider(height: 1, indent: 16),
                _ThemeTile('Dark', Icons.dark_mode_outlined,
                    tp.themeMode == ThemeMode.dark, () => tp.setTheme(ThemeMode.dark)),
              ]),
            ),
          ),
          const SizedBox(height: 28),

          // ── About ────────────────────────────────────────────
          _SectionHeader('About', Icons.info_outline),
          const SizedBox(height: 8),
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  // NEW: live 3D cube icon in About card
                  SizedBox(
                    width: 40, height: 40,
                    child: SlamStatusIcon(size: 40),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(kAppName,
                        style: theme.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                    Text('v$kAppVersion  •  XIAO ESP32-S3 Sense',
                        style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant)),
                  ])),
                ]),
                const SizedBox(height: 12),
                Text(
                  'LocusMind AR companion for the XIAO ESP32-S3 Sense. '
                  'The ESP32 streams live camera frames, sends IMU pitch/roll at 50 Hz, '
                  'and displays triggered note text on a 0.49" OLED. '
                  'Phone GPS is used to anchor notes to location. '
                  'Optionally, run pc_slam_server.py on a laptop for full ORB tracking.',
                  style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionHeader(this.title, this.icon);
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(children: [
      Icon(icon, size: 17, color: theme.colorScheme.primary),
      const SizedBox(width: 6),
      Expanded(child: Text(title, style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600, color: theme.colorScheme.primary))),
    ]);
  }
}

class _ResultBanner extends StatelessWidget {
  final String text;
  const _ResultBanner(this.text);
  @override
  Widget build(BuildContext context) {
    final isOk = text.startsWith('✅');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: isOk ? Colors.green.shade50 : Colors.red.shade50,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(text, style: TextStyle(
          fontSize: 12,
          color: isOk ? Colors.green.shade800 : Colors.red.shade800)),
    );
  }
}

class _ThemeTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _ThemeTile(this.label, this.icon, this.selected, this.onTap);
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListTile(
      leading: Icon(icon, color: selected ? theme.colorScheme.primary : null),
      title: Text(label),
      trailing: selected ? Icon(Icons.check_circle, color: theme.colorScheme.primary) : null,
      onTap: onTap,
    );
  }
}
