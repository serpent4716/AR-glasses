// screens/slam_map_screen.dart — v2 (VIO)
//
// GPS-Anchored Sparse Visual Map with IMU Dead Reckoning.
// Now uses PhoneVioService (MSCKF + FFI) instead of NCC SLAM.
// Pose is full 6-DOF in metres; heading extracted from quaternion.
//
// What it shows:
//   • Top-down map: your GPS position at centre, note anchor pins around you
//   • Camera heading cone from VIO quaternion yaw
//   • VIO feature cloud when tracking (coloured by confidence)
//   • GPS breadcrumb trail (last 60 positions)
//   • Distance rings at 5 m / 15 m / 50 m
//   • Perspective 3D tilt toggle
//   • Live VIO confidence indicator
//   • Uncertainty ellipse during visual blackout (trackedFeatures < 5)

import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import '../models/note.dart';
import '../providers/notes_provider.dart';
import '../services/esp32_service.dart';
import '../services/phone_slam_vio_service.dart';
import '../widgets/slam_visualizer_icon.dart';

class SlamMapScreen extends StatefulWidget {
  const SlamMapScreen({super.key});

  @override
  State<SlamMapScreen> createState() => _SlamMapScreenState();
}

class _SlamMapScreenState extends State<SlamMapScreen>
    with TickerProviderStateMixin {

  // ── GPS tracking ────────────────────────────────────────────
  Position?            _myPos;
  final List<_GpsCrumb> _trail = [];
  StreamSubscription<Position>? _gpsSub;
  static const int _kMaxTrail = 80;

  // ── IMU heading (from ESP32 complementary filter) ───────────
  double _headingDeg  = 0;
  double _pitchDeg    = 0;
  double _imuConfidence = 0;
  StreamSubscription<ImuFrame>? _imuSub;

  // ── Map interaction ─────────────────────────────────────────
  double _zoom          = 18.0;   // metres per half-screen
  bool   _perspective3d = false;
  double _manualHeading = 0;      // user-dragged rotation

  // ── Animation ───────────────────────────────────────────────
  late final AnimationController _pulseCtrl;
  late final Animation<double>   _pulseAnim;

  // ── VIO state (via listener) ─────────────────────────────────
  PhoneVioService? _slam;
  VioPose _pose = const VioPose();

  void _onSlamChanged() {
    if (!mounted) return;
    setState(() => _pose = _slam!.currentPose);
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startGps();
      _startImu();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final newSlam = context.read<PhoneVioService>();
    if (_slam != newSlam) {
      _slam?.removeListener(_onSlamChanged);
      _slam = newSlam;
      _slam!.addListener(_onSlamChanged);
      _pose = _slam!.currentPose;
    }
  }

  // ── GPS stream ────────────────────────────────────────────────

  Future<void> _startGps() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.deniedForever ||
          perm == LocationPermission.denied) return;

      // Seed with last known immediately
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) {
        setState(() {
          _myPos = last;
          _addCrumb(last);
        });
      }

      // Then stream live updates
      _gpsSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 1, // update every 1 metre
        ),
      ).listen((pos) {
        if (!mounted) return;
        setState(() {
          _myPos = pos;
          _addCrumb(pos);
        });
      });
    } catch (e) {
      debugPrint('[Map] GPS error: $e');
    }
  }

  void _addCrumb(Position pos) {
    _trail.add(_GpsCrumb(lat: pos.latitude, lon: pos.longitude,
        ts: DateTime.now()));
    if (_trail.length > _kMaxTrail) _trail.removeAt(0);
  }

  // ── IMU heading ───────────────────────────────────────────────
  // Use VIO quaternion yaw when tracking; fall back to ESP32 gyro otherwise.

  void _startImu() {
    final esp = context.read<Esp32Service>();
    _imuSub = esp.imuStream.listen((imu) {
      if (!mounted) return;
      setState(() {
        _pitchDeg = imu.pitch;
        // Use VIO heading if tracking, otherwise integrate gyro
        if (_pose.isTracking) {
          _headingDeg = _extractYaw(_pose.qw, _pose.qx, _pose.qy, _pose.qz);
        } else {
          _headingDeg = (_headingDeg + imu.gz * 0.02) % 360;
        }
        _imuConfidence = (1.0 - (imu.angularMagnitude / 200).clamp(0, 1));
      });
    });
  }

  /// Extract yaw (heading) in degrees from a unit quaternion.
  static double _extractYaw(double qw, double qx, double qy, double qz) {
    final yawRad = atan2(2 * (qw * qz + qx * qy),
                         1 - 2 * (qy * qy + qz * qz));
    return (yawRad * 180 / pi) % 360;
  }

  @override
  void dispose() {
    _slam?.removeListener(_onSlamChanged);
    _gpsSub?.cancel();
    _imuSub?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Build ─────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final notes = context.watch<NotesProvider>().notes
        .where((n) => n.anchorLat != null).toList();

    return Scaffold(
      backgroundColor: const Color(0xFF080E1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080E1A),
        foregroundColor: Colors.white,
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          SlamStatusIcon(size: 22),
          const SizedBox(width: 8),
          const Text('SLAM Map', style: TextStyle(fontSize: 14,
              fontFamily: 'monospace', letterSpacing: 1)),
        ]),
        actions: [
          // 3D perspective toggle
          IconButton(
            icon: Icon(_perspective3d ? Icons.view_in_ar : Icons.map_outlined,
                color: _perspective3d ? Colors.greenAccent : Colors.white70),
            tooltip: _perspective3d ? 'Switch to top-down' : 'Switch to 3D perspective',
            onPressed: () => setState(() => _perspective3d = !_perspective3d),
          ),
          // Zoom out
          IconButton(
            icon: const Icon(Icons.zoom_out),
            onPressed: () => setState(() => _zoom = (_zoom * 1.6).clamp(5, 500)),
          ),
          // Zoom in
          IconButton(
            icon: const Icon(Icons.zoom_in),
            onPressed: () => setState(() => _zoom = (_zoom / 1.6).clamp(5, 500)),
          ),
        ],
      ),
      body: Column(children: [
        // ── Legend / status bar ───────────────────────────────────
        _StatusBar(
          myPos:     _myPos,
          pose:      _pose,
          heading:   _headingDeg,
          pitch:     _pitchDeg,
          zoom:      _zoom,
          noteCount: notes.length,
        ),

        // ── Map canvas ────────────────────────────────────────────
        Expanded(
          child: GestureDetector(
            onScaleUpdate: (d) {
              setState(() {
                _zoom = (_zoom / d.scale).clamp(5, 500);
                _manualHeading += d.rotation * 180 / pi;
              });
            },
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => CustomPaint(
                painter: _MapPainter(
                  myPos:        _myPos,
                  trail:        List.from(_trail),
                  notes:        notes,
                  pose:         _pose,
                  headingDeg:   _headingDeg + _manualHeading,
                  pitchDeg:     _pitchDeg,
                  zoom:         _zoom,
                  pulse:        _pulseAnim.value,
                  perspective3d: _perspective3d,
                ),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        ),

        // ── Note legend strip ─────────────────────────────────────
        if (notes.isNotEmpty)
          _NoteLegend(notes: notes, myPos: _myPos),
      ]),
    );
  }
}

// ── Status bar ────────────────────────────────────────────────

class _StatusBar extends StatelessWidget {
  final Position? myPos;
  final VioPose   pose;
  final double    heading, pitch, zoom;
  final int       noteCount;

  const _StatusBar({required this.myPos, required this.pose,
      required this.heading, required this.pitch,
      required this.zoom, required this.noteCount});

  @override
  Widget build(BuildContext context) {
    final hasGps = myPos != null;
    // Confidence colour: green ≥ 0.75, amber ≥ 0.45, red otherwise
    final confColor = pose.confidence >= 0.75
        ? Colors.greenAccent
        : pose.confidence >= 0.45 ? Colors.orange : Colors.redAccent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      color: const Color(0xFF0D1420),
      child: Row(children: [
        _Pill(
          color: hasGps ? Colors.greenAccent : Colors.orange,
          icon: hasGps ? Icons.gps_fixed : Icons.gps_off,
          label: hasGps
              ? '${myPos!.accuracy.toStringAsFixed(0)}m acc'
              : 'No GPS',
        ),
        const SizedBox(width: 8),
        _Pill(
          color: pose.isTracking ? confColor : Colors.white30,
          icon: Icons.track_changes,
          label: pose.isTracking
              ? 'VIO ${pose.trackedFeatures}ft'
              : pose.status.length > 12
                  ? pose.status.substring(0, 12)
                  : pose.status,
        ),
        const SizedBox(width: 8),
        _Pill(
          color: Colors.blueAccent,
          icon: Icons.explore,
          label: '${heading.toStringAsFixed(0)}°',
        ),
        const Spacer(),
        _Pill(
          color: Colors.white54,
          icon: Icons.place,
          label: '$noteCount pins',
        ),
        const SizedBox(width: 8),
        _Pill(
          color: Colors.white38,
          icon: Icons.zoom_in_map,
          label: '${zoom.toStringAsFixed(0)}m',
        ),
      ]),
    );
  }
}

class _Pill extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String label;
  const _Pill({required this.color, required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 11, color: color),
    const SizedBox(width: 3),
    Text(label, style: TextStyle(color: color, fontSize: 10, fontFamily: 'monospace')),
  ]);
}

// ── Note legend ───────────────────────────────────────────────

class _NoteLegend extends StatelessWidget {
  final List<Note> notes;
  final Position?  myPos;
  const _NoteLegend({required this.notes, required this.myPos});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      color: const Color(0xFF0D1420),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: notes.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final n = notes[i];
          final dist = myPos != null && n.anchorLat != null
              ? Geolocator.distanceBetween(
                  myPos!.latitude, myPos!.longitude,
                  n.anchorLat!, n.anchorLon!)
              : null;
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _hexColor(n.color).withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: _hexColor(n.color).withOpacity(0.5)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.place, size: 12, color: _hexColor(n.color)),
              const SizedBox(width: 4),
              Text(
                n.text.length > 12 ? '${n.text.substring(0, 12)}…' : n.text,
                style: TextStyle(color: _hexColor(n.color),
                    fontSize: 11, fontFamily: 'monospace'),
              ),
              if (dist != null) ...[
                const SizedBox(width: 4),
                Text(
                  dist < 1000 ? '${dist.toStringAsFixed(0)}m' : '${(dist/1000).toStringAsFixed(1)}km',
                  style: const TextStyle(color: Colors.white38, fontSize: 10),
                ),
              ],
            ]),
          );
        },
      ),
    );
  }

  Color _hexColor(String hex) {
    try {
      return Color(int.parse('FF${hex.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return Colors.greenAccent;
    }
  }
}

// ── GPS crumb ─────────────────────────────────────────────────

class _GpsCrumb {
  final double lat, lon;
  final DateTime ts;
  const _GpsCrumb({required this.lat, required this.lon, required this.ts});
}

// ═══════════════════════════════════════════════════════════════
//  Map Painter
// ═══════════════════════════════════════════════════════════════

class _MapPainter extends CustomPainter {
  final Position?       myPos;
  final List<_GpsCrumb> trail;
  final List<Note>      notes;
  final VioPose         pose;
  final double          headingDeg;
  final double          pitchDeg;
  final double          zoom;        // metres visible per half-screen
  final double          pulse;
  final bool            perspective3d;

  const _MapPainter({
    required this.myPos,
    required this.trail,
    required this.notes,
    required this.pose,
    required this.headingDeg,
    required this.pitchDeg,
    required this.zoom,
    required this.pulse,
    required this.perspective3d,
  });

  @override
  bool shouldRepaint(covariant _MapPainter o) => true; // animating

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width  / 2;
    final cy = size.height / 2;

    // Tilt matrix for pseudo-3D mode
    final tilt = perspective3d ? (pitchDeg.abs().clamp(0, 45) / 45.0) : 0.0;

    canvas.save();
    canvas.translate(cx, cy);

    // Apply 3D perspective tilt
    if (perspective3d && tilt > 0) {
      final matrix = Matrix4.identity()
        ..setEntry(3, 1, -tilt * 0.0008)
        ..rotateX(tilt * 0.4);
      canvas.transform(Float64List.fromList(matrix.storage));
    }

    // Rotate map so heading is "up"
    canvas.rotate(-(headingDeg * pi / 180));

    // Metres → pixels
    double mToPx(double m) => (m / zoom) * (size.height / 2);

    // Convert GPS offset to canvas XY (relative to my position)
    Offset gpsToCanvas(double lat, double lon) {
      if (myPos == null) return Offset.zero;
      final dlat = (lat - myPos!.latitude) * 111320;
      final dlon = (lon - myPos!.longitude) * 111320 * cos(myPos!.latitude * pi / 180);
      return Offset(mToPx(dlon), -mToPx(dlat));
    }

    // ── Distance rings ──────────────────────────────────────────
    final ringDistances = zoom < 20
        ? [2.0, 5.0, 10.0]
        : zoom < 100
            ? [5.0, 15.0, 50.0]
            : [50.0, 150.0, 500.0];

    for (final d in ringDistances) {
      final r = mToPx(d);
      canvas.drawCircle(
        Offset.zero,
        r,
        Paint()
          ..color = Colors.white.withOpacity(0.06)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
      // Label
      final tp = TextPainter(
        text: TextSpan(
          text: d < 1000 ? '${d.toStringAsFixed(0)}m' : '${(d/1000).toStringAsFixed(0)}km',
          style: const TextStyle(color: Color(0x44FFFFFF), fontSize: 9, fontFamily: 'monospace'),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(-tp.width / 2, -r - 12));
    }

    // ── Grid lines (N/S/E/W guides) ──────────────────────────────
    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (double d = -size.width; d < size.width; d += mToPx(zoom / 4)) {
      canvas.drawLine(Offset(d, -size.height), Offset(d, size.height), gridPaint);
      canvas.drawLine(Offset(-size.width, d), Offset(size.width, d), gridPaint);
    }

    // ── GPS breadcrumb trail ────────────────────────────────────
    if (trail.length > 1 && myPos != null) {
      final path = Path();
      bool first = true;
      for (final crumb in trail) {
        final pt = gpsToCanvas(crumb.lat, crumb.lon);
        final age = DateTime.now().difference(crumb.ts).inSeconds;
        if (first) { path.moveTo(pt.dx, pt.dy); first = false; }
        else        { path.lineTo(pt.dx, pt.dy); }
      }
      canvas.drawPath(path, Paint()
        ..color = const Color(0x5500FF88)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round);

      // Trail dots (older = more transparent)
      for (int i = 0; i < trail.length; i++) {
        final crumb = trail[i];
        final pt    = gpsToCanvas(crumb.lat, crumb.lon);
        final frac  = i / trail.length;
        canvas.drawCircle(pt, 2,
            Paint()..color = const Color(0xFF00FF88).withOpacity(frac * 0.6));
      }
    }

    // ── Note anchor pins ────────────────────────────────────────
    for (final note in notes) {
      if (note.anchorLat == null) continue;
      final pt    = gpsToCanvas(note.anchorLat!, note.anchorLon!);
      final color = _noteColor(note.color);
      final dist  = myPos != null
          ? Geolocator.distanceBetween(myPos!.latitude, myPos!.longitude,
              note.anchorLat!, note.anchorLon!)
          : null;

      // Trigger radius circle (5 m by default)
      canvas.drawCircle(pt, mToPx(5),
          Paint()..color = color.withOpacity(0.08)..style = PaintingStyle.fill);
      canvas.drawCircle(pt, mToPx(5),
          Paint()..color = color.withOpacity(0.25)..style = PaintingStyle.stroke
                 ..strokeWidth = 1);

      // Pin stem
      canvas.drawLine(
        Offset(pt.dx, pt.dy - 22),
        Offset(pt.dx, pt.dy),
        Paint()..color = color..strokeWidth = 1.5..strokeCap = StrokeCap.round,
      );

      // Pin head (pulsing if close)
      final isClose = dist != null && dist < 15;
      final pinR    = isClose ? 7.0 + pulse * 3 : 7.0;
      canvas.drawCircle(pt - const Offset(0, 22), pinR,
          Paint()..color = color.withOpacity(isClose ? 0.4 + pulse * 0.3 : 0.3));
      canvas.drawCircle(pt - const Offset(0, 22), pinR,
          Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.5);
      canvas.drawCircle(pt - const Offset(0, 22), 2.5,
          Paint()..color = Colors.white);

      // Note label
      _drawLabel(canvas, pt + const Offset(10, -22),
          note.text.length > 14 ? '${note.text.substring(0,14)}…' : note.text,
          color);

      // Distance label
      if (dist != null) {
        final dLabel = dist < 1000
            ? '${dist.toStringAsFixed(0)}m'
            : '${(dist/1000).toStringAsFixed(1)}km';
        _drawLabel(canvas, pt + const Offset(10, -8), dLabel,
            Colors.white.withOpacity(0.5), fontSize: 9);
      }
    }

    // ── VIO feature cloud (when tracking) / uncertainty ellipse (blackout) ──
    if (pose.isTracking && myPos != null) {
      _drawFeatureCloud(canvas, pose);
    } else if (!pose.isTracking) {
      _drawUncertaintyEllipse(canvas, pose, pulse);
    }

    canvas.restore();

    // ── Camera frustum (drawn after restore, in screen space) ────
    _drawCameraFrustum(canvas, size, cx, cy);

    // ── My position (centre) ─────────────────────────────────────
    _drawMyPosition(canvas, cx, cy);

    // ── North indicator ──────────────────────────────────────────
    _drawNorthIndicator(canvas, size);
  }

  void _drawFeatureCloud(Canvas canvas, VioPose pose) {
    // Render tracked feature dots around the camera frustum origin.
    // Colour reflects VIO confidence: green = high, amber = medium, red = low.
    final int count = pose.trackedFeatures.clamp(0, 24);
    final conf = pose.confidence.clamp(0.0, 1.0);
    final dotCol = conf >= 0.75
        ? const Color(0xFF00FF88)
        : conf >= 0.45 ? const Color(0xFFFFB300) : const Color(0xFFFF3D00);

    for (int i = 0; i < count; i++) {
      final angle = i * (2 * pi / count.clamp(1, 24));
      final radius = 4.0 + (i % 4) * 1.5;
      final pt = Offset(radius * cos(angle), radius * sin(angle));
      canvas.drawCircle(
        pt, 2.0,
        Paint()..color = dotCol.withOpacity(0.5 + conf * 0.5),
      );
    }
  }

  /// Expanding semi-transparent uncertainty ellipse during visual blackout.
  /// The ellipse grows with the pulse animation to signal growing IMU drift.
  void _drawUncertaintyEllipse(Canvas canvas, VioPose pose, double pulse) {
    // Horizontal uncertainty grows faster than vertical (planar motion assumption)
    final baseR = 12.0 + pulse * 8.0;
    final rect = Rect.fromCenter(
      center: Offset.zero,
      width:  baseR * 2.4,
      height: baseR * 1.6,
    );
    canvas.drawOval(
      rect,
      Paint()
        ..color = const Color(0x33FF6600).withOpacity(0.15 + pulse * 0.15)
        ..style = PaintingStyle.fill,
    );
    canvas.drawOval(
      rect,
      Paint()
        ..color = const Color(0xFFFF6600).withOpacity(0.4 + pulse * 0.3)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
    // Blackout label
    final tp = TextPainter(
      text: const TextSpan(
        text: 'IMU only',
        style: TextStyle(
          color: Color(0xFFFF6600), fontSize: 9, fontFamily: 'monospace'),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(-tp.width / 2, baseR * 0.9));
  }

  void _drawCameraFrustum(Canvas canvas, Size size, double cx, double cy) {
    final headRad = headingDeg * pi / 180;
    const fov     = 62.0 * pi / 180; // OV2640 approx horizontal FOV
    const reach   = 60.0;

    final left  = Offset(cx + reach * sin(headRad - fov/2),
                         cy - reach * cos(headRad - fov/2));
    final right = Offset(cx + reach * sin(headRad + fov/2),
                         cy - reach * cos(headRad + fov/2));

    final path = Path()
      ..moveTo(cx, cy)
      ..lineTo(left.dx, left.dy)
      ..lineTo(right.dx, right.dy)
      ..close();

    canvas.drawPath(path, Paint()
      ..color = const Color(0x220088FF)
      ..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()
      ..color = const Color(0x884488FF)
      ..style = PaintingStyle.stroke..strokeWidth = 1.2);

    // Label
    final tp = TextPainter(
      text: const TextSpan(text: '📷',
          style: TextStyle(fontSize: 14)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(cx - tp.width/2,
        cy - reach * cos(headRad) - tp.height/2 - 16));
  }

  void _drawMyPosition(Canvas canvas, double cx, double cy) {
    // Outer glow
    canvas.drawCircle(Offset(cx, cy), 18,
        Paint()..color = const Color(0x224488FF)..style = PaintingStyle.fill);
    // Accuracy ring
    if (myPos != null) {
      // don't draw accuracy > 100m — too large
    }
    // Inner dot
    canvas.drawCircle(Offset(cx, cy), 10,
        Paint()..color = const Color(0x884488FF));
    canvas.drawCircle(Offset(cx, cy), 10,
        Paint()..color = const Color(0xFF4488FF)..style = PaintingStyle.stroke..strokeWidth = 2);
    canvas.drawCircle(Offset(cx, cy), 4,
        Paint()..color = Colors.white);
  }

  void _drawNorthIndicator(Canvas canvas, Size size) {
    const r = 20.0;
    final cx = size.width - 30.0;
    final cy = 40.0;
    final headRad = headingDeg * pi / 180;

    // Circle
    canvas.drawCircle(Offset(cx, cy), r,
        Paint()..color = const Color(0x33FFFFFF)..style = PaintingStyle.stroke..strokeWidth = 1);

    // N arrow (rotated by heading)
    final nx = cx + r * 0.7 * sin(headRad);
    final ny = cy - r * 0.7 * cos(headRad);
    canvas.drawLine(Offset(cx, cy), Offset(nx, ny),
        Paint()..color = const Color(0xFFFF3D00)..strokeWidth = 2..strokeCap = StrokeCap.round);

    final tp = TextPainter(
      text: const TextSpan(text: 'N',
          style: TextStyle(color: Color(0xFFFF3D00), fontSize: 9, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(nx - tp.width/2, ny - tp.height/2));
  }

  void _drawLabel(Canvas canvas, Offset pos, String text, Color color,
      {double fontSize = 10}) {
    final tp = TextPainter(
      text: TextSpan(text: text,
          style: TextStyle(color: color, fontSize: fontSize, fontFamily: 'monospace')),
      textDirection: TextDirection.ltr,
    )..layout();
    // Background
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(pos.dx - 2, pos.dy - 1, tp.width + 4, tp.height + 2),
        const Radius.circular(3),
      ),
      Paint()..color = const Color(0xCC080E1A),
    );
    tp.paint(canvas, pos);
  }

  Color _noteColor(String hex) {
    try {
      return Color(int.parse('FF${hex.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return Colors.greenAccent;
    }
  }
}

// ── Matrix4 helper (no external package needed) ────────────────

class Matrix4 {
  final List<double> storage = List.filled(16, 0);

  Matrix4.identity() {
    storage[0]  = 1; storage[5]  = 1;
    storage[10] = 1; storage[15] = 1;
  }

  void setEntry(int row, int col, double value) {
    storage[col * 4 + row] = value;
  }

  void rotateX(double angle) {
    final c = cos(angle);
    final s = sin(angle);
    storage[5]  = c;
    storage[6]  = s;
    storage[9]  = -s;
    storage[10] = c;
  }
}
