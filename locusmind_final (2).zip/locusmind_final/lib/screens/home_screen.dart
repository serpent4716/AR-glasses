// screens/home_screen.dart — v3 (VIO)
// Changes from v2:
//   • PhoneSlamService → PhoneVioService
//   • Esp32BleService started in initState (BLE sensor stream)
//   • WiFiFingerprintService started in initState (loop closure)
//   • ContextClassifierService started in initState (dynamic params)
//   • BLE status indicator dot in AppBar
//   • VIO Debug screen accessible from overflow menu

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/notes_provider.dart';
import '../providers/theme_provider.dart';
import '../services/auth_service.dart';
import '../services/esp32_service.dart';
import '../services/esp32_ble_service.dart';
import '../services/phone_slam_vio_service.dart';
import '../services/wifi_fingerprint_service.dart';
import '../services/context_classifier_service.dart';
import '../widgets/note_card.dart';
import '../widgets/sync_status_banner.dart';
import '../widgets/slam_visualizer_icon.dart';
import '../utils/constants.dart';
import 'add_edit_note_screen.dart';
import 'camera_view_screen.dart';
import 'settings_screen.dart';
import 'slam_map_screen.dart';
import 'vio_debug_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Timer? _distanceTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NotesProvider>().initialize();
      context.read<Esp32Service>().startImuReceiver();
      // BLE 5.0 sensor stream — connects to ESP32-S3 for IMU/baro/mag
      context.read<Esp32BleService>().startBleScan();
      // Wi-Fi fingerprinting — scans every 1s for loop closure validation
      context.read<WiFiFingerprintService>().startScanning();
      // Environment classifier — adjusts VIO params every 2s
      context.read<ContextClassifierService>().startClassifying();
      // Refresh GPS distances every 30 seconds
      _distanceTimer = Timer.periodic(
        const Duration(seconds: 30),
        (_) => context.read<NotesProvider>().refreshDistances(),
      );
    });
  }

  @override
  void dispose() {
    _distanceTimer?.cancel();
    context.read<Esp32Service>().stopImuReceiver();
    context.read<WiFiFingerprintService>().stopScanning();
    context.read<ContextClassifierService>().stopClassifying();
    super.dispose();
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sign Out')),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await AuthService().logout();
      await context.read<NotesProvider>().clearAll();
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
    }
  }

  void _showHowToUse() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Row(children: [
          Icon(Icons.help_outline, size: 20),
          SizedBox(width: 8),
          Text('How to Use LocusMind'),
        ]),
        content: const SingleChildScrollView(
          child: _HowToContent(),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(_),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          // 3-D rotating cube that reflects live VIO state
          SlamStatusIcon(size: 26),
          const SizedBox(width: 8),
          const Text(kAppName, style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
        actions: [
          // BLE connection status dot
          Consumer<Esp32BleService>(
            builder: (_, ble, __) {
              final color = switch (ble.state) {
                BleConnectionState.connected    => Colors.greenAccent,
                BleConnectionState.connecting   => Colors.orange,
                BleConnectionState.scanning     => Colors.blueAccent,
                BleConnectionState.disconnected => Colors.white30,
                BleConnectionState.error        => Colors.redAccent,
              };
              final tooltip = switch (ble.state) {
                BleConnectionState.connected    => 'BLE: Connected',
                BleConnectionState.connecting   => 'BLE: Connecting…',
                BleConnectionState.scanning     => 'BLE: Scanning…',
                BleConnectionState.disconnected => 'BLE: Disconnected',
                BleConnectionState.error        => 'BLE: Error — ${ble.error ?? "unknown"}',
              };
              return Tooltip(
                message: tooltip,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 16),
                  child: Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                ),
              );
            },
          ),
          // Theme toggle
          Consumer<ThemeProvider>(
            builder: (_, tp, __) => IconButton(
              icon: Icon(tp.themeMode == ThemeMode.dark
                  ? Icons.light_mode_outlined
                  : Icons.dark_mode_outlined),
              onPressed: () => tp.setTheme(
                  tp.themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark),
            ),
          ),
          // Camera / AR view
          Consumer<Esp32Service>(
            builder: (_, esp, __) => IconButton(
              icon: Stack(clipBehavior: Clip.none, children: [
                const Icon(Icons.videocam_outlined),
                if (esp.isStreaming)
                  Positioned(
                    right: -2, top: -2,
                    child: Container(
                      width: 8, height: 8,
                      decoration: const BoxDecoration(
                        color: Colors.greenAccent, shape: BoxShape.circle),
                    ),
                  ),
              ]),
              tooltip: 'ESP32 Camera + AR',
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const CameraViewScreen())),
            ),
          ),
          // VIO Map button
          IconButton(
            icon: const Icon(Icons.map_outlined),
            tooltip: 'VIO Map — see note positions in space',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SlamMapScreen())),
          ),
          // Menu
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'settings')  Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
              if (v == 'vio_debug') Navigator.push(context, MaterialPageRoute(builder: (_) => const VioDebugScreen()));
              if (v == 'how')       _showHowToUse();
              if (v == 'logout')    _logout();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'settings',
                  child: ListTile(leading: Icon(Icons.settings_outlined),
                      title: Text('Settings'), contentPadding: EdgeInsets.zero)),
              const PopupMenuItem(value: 'vio_debug',
                  child: ListTile(leading: Icon(Icons.developer_mode_outlined),
                      title: Text('VIO Debug'), contentPadding: EdgeInsets.zero)),
              const PopupMenuItem(value: 'how',
                  child: ListTile(leading: Icon(Icons.help_outline),
                      title: Text('How to use'), contentPadding: EdgeInsets.zero)),
              const PopupMenuItem(value: 'logout',
                  child: ListTile(leading: Icon(Icons.logout),
                      title: Text('Sign Out'), contentPadding: EdgeInsets.zero)),
            ],
          ),
        ],
      ),
      body: Consumer<NotesProvider>(
        builder: (context, provider, _) => Column(children: [
          const SyncStatusBanner(),
          // Note list
          Expanded(
            child: provider.isLoading && provider.notes.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : provider.notes.isEmpty
                    ? _EmptyState(onAdd: () => _openAdd(context))
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 8, bottom: 100),
                        itemCount: provider.notes.length,
                        itemBuilder: (_, i) {
                          final note = provider.notes[i];
                          return NoteCard(
                            note: note,
                            onEdit:          () => _openEdit(context, note),
                            onDelete:        () => provider.deleteNote(note.id),
                            onToggleVisible: () => provider.toggleVisibility(note),
                          );
                        },
                      ),
          ),
        ]),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openAdd(context),
        icon: const Icon(Icons.add),
        label: const Text('New Note'),
      ),
    );
  }

  void _openAdd(BuildContext context) => Navigator.push(
      context, MaterialPageRoute(builder: (_) => const AddEditNoteScreen()));

  void _openEdit(BuildContext context, note) => Navigator.push(context,
      MaterialPageRoute(builder: (_) => AddEditNoteScreen(existingNote: note)));
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SlamStatusIcon(size: 72),
          const SizedBox(height: 20),
          Text('No AR notes yet',
              style: theme.textTheme.titleLarge
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
          const SizedBox(height: 8),
          Text(
            'Add a note, point the ESP32 camera at\nthe location, then tap 📌 to pin it.',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.add),
            label: const Text('Add First Note'),
          ),
        ]),
      ),
    );
  }
}

// ── How to use content ────────────────────────────────────────

class _HowToContent extends StatelessWidget {
  const _HowToContent();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: const [
        _Step('1', 'Flash & Connect ESP32',
            'Flash locusmind_vio_v8.ino to your XIAO ESP32-S3 Sense. '
            'Edit WIFI_SSID, WIFI_PASSWORD and PHONE_IP at the top of the file, '
            'then upload. The device appears in BLE scan automatically.'),
        SizedBox(height: 12),
        _Step('2', 'Wait for BLE Connection',
            'The green dot in the top-right of the home screen turns green '
            'when the ESP32 connects via BLE 5.0. IMU, barometer, and '
            'magnetometer data will start flowing within seconds.'),
        SizedBox(height: 12),
        _Step('3', 'Create a Note',
            'Tap New Note on the home screen. Type your reminder text. '
            'GPS anchor is set automatically from your phone location.'),
        SizedBox(height: 12),
        _Step('4', 'Open Camera View',
            'Tap the camera icon in the top-right. The live MJPEG feed from '
            'the ESP32 appears with a 3-D AR wireframe overlay.'),
        SizedBox(height: 12),
        _Step('5', 'Pin a VIO Anchor',
            'Move the device so VIO is tracking (green badge shows feature count). '
            'Tap 📌 on a note row. This stores the barometer altitude and '
            'magnetometer heading as a multi-modal anchor fingerprint.'),
        SizedBox(height: 12),
        _Step('6', 'VIO Tracking',
            'The MSCKF VIO backend fuses IMU preintegration with visual '
            'features from the ESP32 camera at 10Hz. The VIO badge shows '
            'live feature count. Below 5 features an uncertainty ellipse '
            'appears on the map showing IMU-only dead reckoning.'),
        SizedBox(height: 12),
        _Step('7', 'Loop Closure',
            'When you return to a previously visited location, four sensors '
            'must agree: visual features + barometer (±30cm) + '
            'magnetometer (±5°) + Wi-Fi routers. All four must match '
            'to correct accumulated drift.'),
        SizedBox(height: 12),
        _Step('8', 'VIO Debug Screen',
            'Open the menu (⋮) → VIO Debug to see live pose, feature count, '
            'BLE packet rate, Wi-Fi fingerprint, and environment classification.'),
        SizedBox(height: 12),
        _Step('9', 'Distance Reading',
            'The distance shown on cards is phone GPS → note GPS anchor. '
            'It updates every 30 seconds while the home screen is open. '
            'Distances under 1 m are shown in cm; over 1 km in km.'),
      ],
    );
  }
}

class _Step extends StatelessWidget {
  final String number, title, body;
  const _Step(this.number, this.title, this.body);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(
        radius: 12,
        backgroundColor: theme.colorScheme.primary,
        child: Text(number,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      ),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(body, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
      ])),
    ]);
  }
}
