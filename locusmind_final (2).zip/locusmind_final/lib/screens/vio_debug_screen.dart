// lib/screens/vio_debug_screen.dart
// APPROACH 5: Real-time VIO debugging and visualization
// Shows: 6-DOF pose, IMU biases, barometer, magnetometer, features, keyframes

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/phone_slam_vio_service.dart';
import '../services/esp32_ble_service.dart';
import '../services/wifi_fingerprint_service.dart';

class VioDebugScreen extends StatelessWidget {
  const VioDebugScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('VIO Debug'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<PhoneVioService>().reset();
            },
            tooltip: 'Reset VIO',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── VIO Status Card ─────────────────────────────────────
            _StatusCard(),
            const SizedBox(height: 16),

            // ── 6-DOF Pose ──────────────────────────────────────────
            _PoseCard(),
            const SizedBox(height: 16),

            // ── Sensor Readings ─────────────────────────────────────
            _SensorCard(),
            const SizedBox(height: 16),

            // ── BLE Statistics ────────────────────────────────────
            _BleCard(),
            const SizedBox(height: 16),

            // ── Wi-Fi Fingerprint ─────────────────────────────────
            _WifiCard(),
            const SizedBox(height: 16),

            // ── Raw Debug Info ────────────────────────────────────
            _DebugInfoCard(),
          ],
        ),
      ),
    );
  }
}

// ── Status Card ─────────────────────────────────────────────────

class _StatusCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<PhoneVioService>(
      builder: (_, vio, __) {
        final pose = vio.currentPose;
        final color = pose.isTracking
            ? (pose.confidence > 0.75 ? Colors.green : Colors.orange)
            : Colors.red;

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.gps_fixed, color: color),
                  const SizedBox(width: 8),
                  Text('VIO Status', style: Theme.of(context).textTheme.titleMedium),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      pose.status,
                      style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ),
                ]),
                const SizedBox(height: 12),
                _StatRow('Confidence', '${(pose.confidence * 100).toStringAsFixed(1)}%'),
                _StatRow('Tracking', pose.isTracking ? 'YES' : 'NO'),
                _StatRow('Features', '${pose.trackedFeatures}'),
                _StatRow('Keyframes', '${pose.keyframeCount}'),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Pose Card ───────────────────────────────────────────────────

class _PoseCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<PhoneVioService>(
      builder: (_, vio, __) {
        final p = vio.currentPose;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('6-DOF Pose', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _StatRow('Position X', '${p.x.toStringAsFixed(3)} m'),
                _StatRow('Position Y', '${p.y.toStringAsFixed(3)} m'),
                _StatRow('Position Z', '${p.z.toStringAsFixed(3)} m'),
                const Divider(height: 16),
                _StatRow('Quaternion W', '${p.qw.toStringAsFixed(4)}'),
                _StatRow('Quaternion X', '${p.qx.toStringAsFixed(4)}'),
                _StatRow('Quaternion Y', '${p.qy.toStringAsFixed(4)}'),
                _StatRow('Quaternion Z', '${p.qz.toStringAsFixed(4)}'),
                const Divider(height: 16),
                _StatRow('Velocity X', '${p.vx.toStringAsFixed(3)} m/s'),
                _StatRow('Velocity Y', '${p.vy.toStringAsFixed(3)} m/s'),
                _StatRow('Velocity Z', '${p.vz.toStringAsFixed(3)} m/s'),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Sensor Card ─────────────────────────────────────────────────

class _SensorCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<PhoneVioService>(
      builder: (_, vio, __) {
        final p = vio.currentPose;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Sensors', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _StatRow('Altitude', '${p.altitude.toStringAsFixed(2)} m'),
                _StatRow('Heading', '${p.heading.toStringAsFixed(1)}°'),
                _StatRow('Barometer', 'Active'),
                _StatRow('Magnetometer', 'Active'),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── BLE Card ────────────────────────────────────────────────────

class _BleCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<Esp32BleService>(
      builder: (_, esp, __) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('BLE Connection', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _StatRow('State', esp.state.name),
                _StatRow('Packets', '${esp.packetsReceived}'),
                _StatRow('Rate', '${esp.packetRate.toStringAsFixed(1)} Hz'),
                if (esp.error != null)
                  Text('Error: ${esp.error}', style: const TextStyle(color: Colors.red, fontSize: 12)),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Wi-Fi Card ──────────────────────────────────────────────────

class _WifiCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<WiFiFingerprintService>(
      builder: (_, wifi, __) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Wi-Fi Fingerprint', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _StatRow('Scanning', wifi.isScanning ? 'YES' : 'NO'),
                _StatRow('APs seen', '${wifi.currentFingerprint.length}'),
                if (wifi.currentFingerprint.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    wifi.currentFingerprintJson,
                    style: const TextStyle(fontSize: 10, fontFamily: 'monospace'),
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Debug Info Card ─────────────────────────────────────────────

class _DebugInfoCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<PhoneVioService>(
      builder: (_, vio, __) {
        final info = vio.debugInfo;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Raw Debug Info', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                ...info.entries.map((e) => _StatRow(e.key, e.value.toString())),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Stat Row Helper ─────────────────────────────────────────────

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  const _StatRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
