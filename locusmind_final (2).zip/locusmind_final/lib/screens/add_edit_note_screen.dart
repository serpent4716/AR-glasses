// screens/add_edit_note_screen.dart — v3
// GPS FIX: uses getLastKnownPosition first (instant), upgrades in background.
// No red errors. Local save only.

import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../models/note.dart';
import '../providers/notes_provider.dart';
import '../utils/constants.dart';

class AddEditNoteScreen extends StatefulWidget {
  final Note? existingNote;
  const AddEditNoteScreen({super.key, this.existingNote});

  @override
  State<AddEditNoteScreen> createState() => _AddEditNoteScreenState();
}

class _AddEditNoteScreenState extends State<AddEditNoteScreen> {
  final _formKey        = GlobalKey<FormState>();
  final _textController = TextEditingController();

  Color  _selectedColor = const Color(0xFF00FF88);
  bool   _visible       = true;
  bool   _isSaving      = false;
  String _selectedTtl   = 'Never';

  // GPS
  Position? _gpsPosition;
  bool      _gpsLoading = true;  // start true — we attempt immediately
  String    _gpsStatus  = 'Getting location…';

  // Voice
  final SpeechToText _speech         = SpeechToText();
  bool               _speechAvailable = false;
  bool               _isListening    = false;

  bool get _isEdit => widget.existingNote != null;

  @override
  void initState() {
    super.initState();
    _initSpeech();
    if (_isEdit) {
      final n = widget.existingNote!;
      _textController.text = n.text;
      _selectedColor       = n.flutterColor;
      _visible             = n.visible;
      _gpsLoading          = false;
      _gpsStatus           = '';
    } else {
      _fetchGpsMultiTier();
    }
  }

  // Three-tier GPS: lastKnown (instant) → coarse (fast) → precise (best)
  Future<void> _fetchGpsMultiTier() async {
    setState(() { _gpsLoading = true; _gpsStatus = 'Getting location…'; });

    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever ||
          permission == LocationPermission.denied) {
        if (mounted) setState(() {
          _gpsLoading = false;
          _gpsStatus = 'Location permission denied — enable in Settings';
        });
        return;
      }

      final serviceOn = await Geolocator.isLocationServiceEnabled();
      if (!serviceOn) {
        if (mounted) setState(() {
          _gpsLoading = false;
          _gpsStatus = 'Location services off — enable in phone Settings';
        });
        return;
      }

      // Tier 1: last known (instant, even indoors)
      try {
        final last = await Geolocator.getLastKnownPosition();
        if (last != null && mounted) {
          setState(() {
            _gpsPosition = last;
            _gpsStatus   = 'Location (cached): ${last.latitude.toStringAsFixed(5)}, '
                '${last.longitude.toStringAsFixed(5)}';
            _gpsLoading  = false;
          });
          // Continue upgrading in background
        }
      } catch (_) {}

      // Tier 2: coarse (network/cell, 1-3 s)
      try {
        setState(() => _gpsStatus = 'Getting precise location…');
        final coarse = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low,
        ).timeout(const Duration(seconds: 5));
        if (mounted) setState(() {
          _gpsPosition = coarse;
          _gpsStatus   = '📍 ${coarse.latitude.toStringAsFixed(5)}, '
              '${coarse.longitude.toStringAsFixed(5)}';
          _gpsLoading  = false;
        });
      } catch (_) {}

      // Tier 3: precise GPS (best accuracy, longer wait)
      if (mounted && _gpsPosition == null) {
        try {
          final precise = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
          ).timeout(const Duration(seconds: 8));
          if (mounted) setState(() {
            _gpsPosition = precise;
            _gpsStatus   = '📍 ${precise.latitude.toStringAsFixed(5)}, '
                '${precise.longitude.toStringAsFixed(5)}';
            _gpsLoading  = false;
          });
        } catch (_) {
          if (mounted) setState(() {
            _gpsLoading = false;
            _gpsStatus  = _gpsPosition != null
                ? _gpsStatus  // keep last known if we have it
                : 'No GPS fix — note saves without location';
          });
        }
      } else if (mounted) {
        setState(() => _gpsLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() {
        _gpsLoading = false;
        _gpsStatus  = 'Location error: $e';
      });
    }
  }

  Future<void> _initSpeech() async {
    _speechAvailable = await _speech.initialize();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _textController.dispose();
    _speech.cancel();
    super.dispose();
  }

  void _openColorPicker() {
    Color tmp = _selectedColor;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Pick note color'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: _selectedColor,
            onColorChanged: (c) => tmp = c,
            enableAlpha: false,
            labelTypes: const [],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () { setState(() => _selectedColor = tmp); Navigator.pop(context); },
            child: const Text('Choose'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleListening() async {
    if (!_speechAvailable) { _showSnack('Microphone not available'); return; }
    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
    } else {
      setState(() => _isListening = true);
      await _speech.listen(
        onResult: (r) {
          if (r.finalResult) {
            setState(() { _textController.text = r.recognizedWords; _isListening = false; });
          }
        },
        listenFor: const Duration(seconds: 30),
        pauseFor:  const Duration(seconds: 3),
      );
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final provider = context.read<NotesProvider>();
    final hexColor = Note.colorToHex(_selectedColor);
    final ttlSec   = kTtlPresets[_selectedTtl] ?? 0;

    try {
      if (_isEdit) {
        final updated = widget.existingNote!.copyWith(
          text:    _textController.text.trim(),
          color:   hexColor,
          visible: _visible,
        );
        await provider.updateNote(updated);
        if (mounted) _showSnack('Note updated ✓');
      } else {
        final now    = DateTime.now();
        final expiry = ttlSec > 0 ? now.add(Duration(seconds: ttlSec)) : null;
        final tempId = now.millisecondsSinceEpoch.toRadixString(16).substring(0, 8);
        final newNote = Note(
          id:          tempId,
          text:        _textController.text.trim(),
          color:       hexColor,
          visible:     _visible,
          anchorLat:   _gpsPosition?.latitude,
          anchorLon:   _gpsPosition?.longitude,
          anchorFixed: _gpsPosition != null,
          expiryTime:  expiry,
        );
        await provider.addNote(newNote);
        if (mounted) {
          final msg = _gpsPosition != null
              ? 'Note saved ✓  Now open Camera View → point at location → tap PIN'
              : 'Note saved ✓  (no GPS fix — open Camera View → tap PIN to anchor)';
          _showSnack(msg);
        }
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) _showSnack('Save failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red.shade700 : null,
      duration: Duration(seconds: isError ? 5 : 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit Note' : 'New AR Note')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Preview
            Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: _selectedColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _selectedColor.withOpacity(0.45), width: 1.5),
              ),
              child: Row(children: [
                Icon(Icons.sticky_note_2, color: _selectedColor, size: 30),
                const SizedBox(width: 12),
                Expanded(child: Text(
                  _textController.text.isEmpty ? 'Note preview…' : _textController.text,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: _selectedColor),
                  maxLines: 2, overflow: TextOverflow.ellipsis,
                )),
              ]),
            ),

            // GPS anchor — always shows, even while loading
            if (!_isEdit)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: _gpsPosition != null
                        ? Colors.green.shade50
                        : _gpsLoading
                            ? Colors.blue.shade50
                            : Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _gpsPosition != null
                        ? Colors.green.shade300
                        : _gpsLoading ? Colors.blue.shade300 : Colors.orange.shade300),
                  ),
                  child: Row(children: [
                    if (_gpsLoading)
                      const SizedBox(width: 14, height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2))
                    else
                      Icon(
                        _gpsPosition != null ? Icons.gps_fixed : Icons.gps_off,
                        size: 16,
                        color: _gpsPosition != null
                            ? Colors.green.shade700 : Colors.orange.shade700,
                      ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_gpsStatus,
                        style: TextStyle(
                          fontSize: 12,
                          color: _gpsPosition != null
                              ? Colors.green.shade800
                              : _gpsLoading ? Colors.blue.shade800 : Colors.orange.shade800,
                        ))),
                    if (!_gpsLoading && _gpsPosition == null)
                      TextButton(
                        onPressed: _fetchGpsMultiTier,
                        style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                            minimumSize: const Size(50, 28),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                        child: const Text('Retry', style: TextStyle(fontSize: 12)),
                      ),
                  ]),
                ),
              ),

            // Text field
            _SectionLabel('Note Text', Icons.notes),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: TextFormField(
                controller: _textController,
                minLines: 2, maxLines: 5, maxLength: 200,
                decoration: const InputDecoration(
                    hintText: 'What do you want to remember at this location?'),
                onChanged: (_) => setState(() {}),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter text' : null,
              )),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: _MicButton(isListening: _isListening,
                    available: _speechAvailable, onTap: _toggleListening),
              ),
            ]),
            const SizedBox(height: 20),

            // Color
            _SectionLabel('Color', Icons.palette_outlined),
            const SizedBox(height: 8),
            Row(children: [
              ...kPresetColors.map((hex) {
                final c = _hexToColor(hex);
                final sel = Note.colorToHex(_selectedColor) == hex.toUpperCase();
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedColor = c),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      width: 30, height: 30,
                      decoration: BoxDecoration(
                        color: c, shape: BoxShape.circle,
                        border: sel ? Border.all(color: theme.colorScheme.onSurface, width: 2.5) : null,
                      ),
                    ),
                  ),
                );
              }),
              GestureDetector(
                onTap: _openColorPicker,
                child: Container(
                  width: 30, height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const SweepGradient(colors: [
                      Colors.red, Colors.yellow, Colors.green, Colors.blue, Colors.red]),
                    border: Border.all(color: theme.colorScheme.outline, width: 1),
                  ),
                  child: const Icon(Icons.add, size: 14, color: Colors.white),
                ),
              ),
            ]),
            const SizedBox(height: 20),

            // TTL (new notes only)
            if (!_isEdit) ...[
              _SectionLabel('Auto-Delete After', Icons.timer_outlined),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedTtl,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.schedule)),
                onChanged: (v) => setState(() => _selectedTtl = v!),
                items: kTtlPresets.keys.map((label) =>
                    DropdownMenuItem(value: label, child: Text(label))).toList(),
              ),
              const SizedBox(height: 20),
            ],

            // Visibility
            _SectionLabel('AR Visibility', Icons.visibility_outlined),
            const SizedBox(height: 4),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _visible,
              onChanged: (v) => setState(() => _visible = v),
              title: Text(_visible ? 'Visible in AR' : 'Hidden in AR'),
              subtitle: Text(
                _visible
                    ? 'OLED shows this note when camera recognises the anchor scene.'
                    : 'Note is stored but OLED will not show it.',
                style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant)),
            ),
            const SizedBox(height: 20),

            // How to pin hint
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer.withOpacity(0.4),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(children: [
                Icon(Icons.info_outline, size: 16, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  'After saving: open Camera View → point at your real-world location → '
                  'tap the 📌 PIN button next to this note.',
                  style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onPrimaryContainer),
                )),
              ]),
            ),
            const SizedBox(height: 24),

            // Buttons
            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              )),
              const SizedBox(width: 12),
              Expanded(flex: 2, child: FilledButton.icon(
                onPressed: _isSaving ? null : _save,
                icon: _isSaving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.save_outlined),
                label: Text(_isEdit ? 'Update Note' : 'Save Note'),
              )),
            ]),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionLabel(this.title, this.icon);
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(children: [
      Icon(icon, size: 16, color: theme.colorScheme.primary),
      const SizedBox(width: 6),
      Text(title, style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600, color: theme.colorScheme.primary)),
    ]);
  }
}

class _MicButton extends StatelessWidget {
  final bool isListening, available;
  final VoidCallback onTap;
  const _MicButton({required this.isListening, required this.available, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: isListening ? Colors.red.shade50 : theme.colorScheme.surfaceContainerHighest,
        shape: BoxShape.circle,
        border: isListening ? Border.all(color: Colors.red, width: 2) : null,
      ),
      child: IconButton(
        icon: Icon(isListening ? Icons.mic : Icons.mic_none, color: isListening ? Colors.red : null),
        onPressed: available ? onTap : null,
        tooltip: isListening ? 'Stop' : 'Voice input',
      ),
    );
  }
}

Color _hexToColor(String hex) {
  final h = hex.replaceAll('#', '');
  if (h.length == 6) return Color(int.parse('FF$h', radix: 16));
  return const Color(0xFF00FF88);
}
