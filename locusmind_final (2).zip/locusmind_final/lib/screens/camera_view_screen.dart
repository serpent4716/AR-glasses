// screens/camera_view_screen.dart — MERGED v10
//
// Performance & crash fixes:
//   • SLAM timer interval 500ms (was 250ms) — halves CPU load, still smooth.
//   • _runSlam() debounce flag prevents overlapping async calls.
//   • Image.memory() uses gaplessPlayback:true so there's no flicker.
//   • Dialog: Navigator.pop(context) instead of Navigator.pop(ctx) — ctx may
//     be stale if the surrounding StatefulBuilder re-built; using the screen
//     context avoids the "Tried to build dirty widget in the wrong build scope"
//     crash that appeared when leaving AddNote mid-entry.
//   • _showAddNoteDialog: TextEditingController disposed in a finally block.
//   • Removed stray context.read<NotesProvider>() inside the dialog FilledButton
//     onPressed — uses the captured `context` from the screen level.
//   • No context.watch() inside AnimatedBuilder or ListenableBuilder builders.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/notes_provider.dart';
import '../services/esp32_service.dart';
import '../services/phone_slam_vio_service.dart';
import '../services/speech_service.dart';
import '../models/note.dart';
import '../utils/constants.dart';
import '../widgets/scrolling_note_text.dart';
import '../widgets/slam_visualizer_icon.dart';
import 'slam_map_screen.dart';

class CameraViewScreen extends StatefulWidget {
  const CameraViewScreen({super.key});

  @override
  State<CameraViewScreen> createState() => _CameraViewScreenState();
}

class _CameraViewScreenState extends State<CameraViewScreen> {
  late final Esp32Service    _esp32;
  late final PhoneVioService _slam;

  // _slamTimer kept for future use (e.g. periodic loop closure checks)
  Timer?  _slamTimer;
  String? _trackedNoteId;
  bool    _slamRunning = false;

  DateTime _lastOledSend      = DateTime.fromMillisecondsSinceEpoch(0);
  static const Duration _kOledResendInterval = Duration(seconds: 5);

  @override
  void initState() {
    super.initState();
    _esp32 = context.read<Esp32Service>();
    _slam  = context.read<PhoneVioService>();
    _esp32.startImuReceiver();
    // VIO runs continuously via BLE — no polling timer needed here.
    // Timer retained in case future loop closure polling is added.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _esp32.startStream();
    });
  }

  // ── VIO state polling ─────────────────────────────────────────
  // VIO updates come via BLE→PhoneVioService→notifyListeners().
  // We listen via ListenableBuilder in build(). This method is kept
  // for OLED dispatch when a note is "near" based on GPS distance.

  Future<void> _runSlam() async {
    if (_slamRunning) return;
    _slamRunning = true;

    // Check if any note is close enough to display on OLED (GPS-based)
    if (mounted) {
      final notes = context.read<NotesProvider>().notes;
      final vioTracking = _slam.isTracking;

      // Find closest anchored note
      Note? closest;
      double closestDist = double.infinity;
      for (final n in notes) {
        if (n.anchorLat == null) continue;
        if (n.distanceM < closestDist) {
          closestDist = n.distanceM;
          closest = n;
        }
      }

      final now = DateTime.now();
      final isNewMatch = closest?.id != _trackedNoteId;
      final oledDue = now.difference(_lastOledSend) >= _kOledResendInterval;

      if (closest != null && closestDist < 15 && (isNewMatch || oledDue)) {
        if (closest.visible) {
          final dist = closest.distanceM > 1 ? '~${_fmtDist(closest.distanceM)}' : '';
          await _esp32.sendNoteToOled(
            closest.text.length > 10 ? closest.text.substring(0, 10) : closest.text,
            line2: dist,
          );
          _lastOledSend = now;
        }
        if (isNewMatch && mounted) {
          _trackedNoteId = closest.id;
          setState(() {});
        }
      } else if (_trackedNoteId != null && closestDist >= 15) {
        _trackedNoteId = null;
        await _esp32.clearOled();
        if (mounted) setState(() {});
      }
    }

    _slamRunning = false;
  }

  String _fmtDist(double m) {
    if (m < 1)    return '${(m * 100).toStringAsFixed(0)}cm';
    if (m < 1000) return '${m.toStringAsFixed(0)}m';
    return '${(m / 1000).toStringAsFixed(1)}km';
  }

  // ── Save visual anchor ────────────────────────────────────────
  // VIO anchors are stored via current pose + barometer + mag fingerprint.
  // The actual anchor data is populated when the note is created/edited.

  Future<void> _saveAnchor(Note note) async {
    if (!_slam.isTracking) {
      _snack('VIO not tracking — move device to establish visual tracking first',
          isError: true);
      return;
    }
    final pose = _slam.currentPose;
    final np = context.read<NotesProvider>();
    // Store current barometer altitude and heading as the anchor fingerprint
    await np.updateNote(note.copyWith(
      anchorAltitude: pose.altitude,
      magFingerprint: pose.heading.toStringAsFixed(1),
    ));
    _snack('✓ VIO anchor saved for "${note.text.substring(0, note.text.length.clamp(0, 20))}"');
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red.shade700 : null,
      duration: Duration(seconds: isError ? 4 : 2),
    ));
  }

  // ── Build ─────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('AR Camera View', style: TextStyle(fontSize: 14)),
        actions: [
          // FPS display — only listens to Esp32Service, not rebuilt every frame
          ListenableBuilder(
            listenable: _esp32,
            builder: (_, __) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Center(child: Text(
                '${_esp32.fps.toStringAsFixed(0)} fps',
                style: TextStyle(
                  color: _esp32.fps > 5 ? Colors.greenAccent : Colors.orange,
                  fontSize: 12, fontFamily: 'monospace',
                ),
              )),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.map_outlined, color: Colors.white70, size: 20),
            tooltip: 'Open SLAM Map',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SlamMapScreen())),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: SlamStatusIcon(size: 28)),
          ),
        ],
      ),
      body: Column(children: [
        // ── Camera + AR overlay ────────────────────────────────
        Expanded(
          flex: 3,
          child: ListenableBuilder(
            listenable: _esp32,
            builder: (_, __) {
              switch (_esp32.state) {
                case Esp32State.connecting:
                  return const Center(child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Colors.greenAccent),
                      SizedBox(height: 12),
                      Text('Connecting to ESP32…',
                          style: TextStyle(color: Colors.white70)),
                    ],
                  ));

                case Esp32State.error:
                  return Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.wifi_off, color: Colors.orange, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        _esp32.error ?? 'Cannot reach ESP32',
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: _esp32.startStream,
                        child: const Text('Retry',
                            style: TextStyle(color: Colors.greenAccent)),
                      ),
                    ]),
                  ));

                case Esp32State.streaming:
                  final frame = _esp32.latestFrame;
                  if (frame == null) {
                    return const Center(child: Text('Waiting for first frame…',
                        style: TextStyle(color: Colors.white54)));
                  }
                  return _buildCameraStack(frame);

                case Esp32State.disconnected:
                  return Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.wifi_find, color: Colors.white38, size: 48),
                      const SizedBox(height: 12),
                      const Text('Not connected to ESP32',
                          style: TextStyle(color: Colors.white54, fontSize: 13),
                          textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: _esp32.startStream,
                        child: const Text('Connect',
                            style: TextStyle(color: Colors.greenAccent)),
                      ),
                    ]),
                  ));
              }
            },
          ),
        ),

        // ── FABs ───────────────────────────────────────────────
        _CameraFabs(onAddNote: () => _showAddNoteDialog(context)),

        // ── Notes list ─────────────────────────────────────────
        Expanded(
          flex: 2,
          child: Container(
            color: const Color(0xFF0D1117),
            child: Consumer<NotesProvider>(
              builder: (_, np, __) {
                if (np.notes.isEmpty) {
                  return const Center(child: Text(
                    'No notes yet — tap + to add one',
                    style: TextStyle(color: Colors.white38, fontSize: 13)));
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                      child: Row(children: [
                        const Text('NOTES', style: TextStyle(
                          color: Colors.greenAccent, fontSize: 10,
                          fontFamily: 'monospace', letterSpacing: 2)),
                        const SizedBox(width: 8),
                        // ListenableBuilder so _slam changes don't rebuild whole list
                        ListenableBuilder(
                          listenable: _slam,
                          builder: (_, __) {
                            if (!_slam.isTracking) return const SizedBox.shrink();
                            return Text(
                              '● TRACKING  ${_slam.currentPose.trackedFeatures} features',
                              style: const TextStyle(
                                color: Colors.greenAccent, fontSize: 10,
                                fontFamily: 'monospace'),
                            );
                          },
                        ),
                      ]),
                    ),
                    Expanded(child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemCount: np.notes.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 4),
                      itemBuilder: (_, i) {
                        final n = np.notes[i];
                        final isTracked = n.id == _trackedNoteId;
                        return _NoteRow(
                          note:      n,
                          isTracked: isTracked,
                          onPin:     () => _saveAnchor(n),
                          fmtDist:   _fmtDist,
                        );
                      },
                    )),
                  ],
                );
              },
            ),
          ),
        ),
      ]),
    );
  }

  // ── Camera stack ──────────────────────────────────────────────

  Widget _buildCameraStack(dynamic frame) {
    return LayoutBuilder(builder: (_, constraints) {
      final W = constraints.maxWidth;
      final H = constraints.maxHeight;
      return Stack(
        fit: StackFit.expand,
        children: [
          Image.memory(
            frame,
            gaplessPlayback: true,
            fit: BoxFit.contain,
            width: W, height: H,
          ),
          Positioned.fill(
            child: SlamVisualizerIcon(screenW: W, screenH: H, refW: 320, refH: 240),
          ),
          Positioned(
            top: 8, right: 8,
            child: ListenableBuilder(
              listenable: _slam,
              builder: (_, __) => _HudBadge(
                label:    'VIO',
                active:   _slam.isTracking,
                features: _slam.currentPose.trackedFeatures,
              ),
            ),
          ),
          const _VoiceTranscriptOverlay(),
        ],
      );
    });
  }

  // ── Add note dialog ───────────────────────────────────────────

  Future<void> _showAddNoteDialog(BuildContext context) async {
    final ctrl = TextEditingController();
    String selectedTtl = 'Never';

    try {
      await showDialog(
        context: context,
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setS) => AlertDialog(
            title: const Text('New Note'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: ctrl,
                decoration: const InputDecoration(
                  labelText: 'Note text',
                  hintText: 'What do you want to remember?',
                ),
                autofocus: true,
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              Row(children: [
                const Text('Expires: ', style: TextStyle(fontSize: 13)),
                const SizedBox(width: 8),
                Expanded(child: DropdownButton<String>(
                  isExpanded: true,
                  value: selectedTtl,
                  onChanged: (v) => setS(() => selectedTtl = v!),
                  items: kTtlPresets.keys.map((label) => DropdownMenuItem(
                    value: label,
                    child: Text(label, style: const TextStyle(fontSize: 13)),
                  )).toList(),
                )),
              ]),
            ]),
            actions: [
              TextButton(
                // Use ctx here (dialog context) — safe because pop is synchronous
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  final text = ctrl.text.trim();
                  if (text.isEmpty) return;
                  Navigator.pop(ctx); // dismiss dialog FIRST
                  final np   = context.read<NotesProvider>(); // screen context
                  final ttlS = kTtlPresets[selectedTtl] ?? 0;
                  await np.addNoteWithTtl(text: text, ttlSeconds: ttlS);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Note added: "$text" — tap 📌 to pin it')));
                  }
                },
                child: const Text('Add'),
              ),
            ],
          ),
        ),
      );
    } finally {
      ctrl.dispose();
    }
  }

  @override
  void dispose() {
    _slamTimer?.cancel();
    _esp32.stopStream();
    _esp32.stopImuReceiver();
    super.dispose();
  }
}

// ── Camera FABs ───────────────────────────────────────────────

class _CameraFabs extends StatelessWidget {
  final VoidCallback onAddNote;
  const _CameraFabs({required this.onAddNote});

  @override
  Widget build(BuildContext context) {
    return Consumer<SpeechService>(
      builder: (ctx, speech, __) => Container(
        color: Colors.black,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(children: [
          FloatingActionButton.small(
            heroTag: 'cam_add',
            onPressed: onAddNote,
            backgroundColor: Colors.black54,
            foregroundColor: Colors.greenAccent,
            tooltip: 'Add text note',
            child: const Icon(Icons.add),
          ),
          const Spacer(),
          FloatingActionButton.small(
            heroTag: 'cam_voice',
            onPressed: () => _handleVoice(ctx, speech),
            backgroundColor: speech.isListening ? Colors.red : Colors.black54,
            foregroundColor: speech.isListening ? Colors.white : Colors.greenAccent,
            tooltip: speech.isListening ? 'Stop recording' : 'Voice note',
            child: Icon(speech.isListening ? Icons.stop : Icons.mic),
          ),
        ]),
      ),
    );
  }

  Future<void> _handleVoice(BuildContext context, SpeechService speech) async {
    if (speech.isListening) { await speech.stopListening(); return; }
    await speech.startListening((text) async {
      final np = context.read<NotesProvider>();
      await np.addNoteWithTtl(text: text, ttlSeconds: 86400);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Voice note: "$text" — tap 📌 to pin it')));
      }
    });
  }
}

// ── Voice transcript overlay ──────────────────────────────────

class _VoiceTranscriptOverlay extends StatelessWidget {
  const _VoiceTranscriptOverlay();

  @override
  Widget build(BuildContext context) {
    return Consumer<SpeechService>(
      builder: (_, speech, __) {
        if (!speech.isListening && speech.lastWords.isEmpty) {
          return const SizedBox.shrink();
        }
        return Positioned(
          bottom: 8, left: 12, right: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: speech.isListening ? Colors.red : Colors.greenAccent,
                width: 1.5),
            ),
            child: Text(
              speech.isListening && speech.lastWords.isEmpty
                  ? '● Listening…'
                  : speech.lastWords,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              maxLines: 3, overflow: TextOverflow.ellipsis,
            ),
          ),
        );
      },
    );
  }
}

// ── HUD badge ─────────────────────────────────────────────────

class _HudBadge extends StatelessWidget {
  final String label;
  final bool   active;
  final int    features;
  const _HudBadge({required this.label, required this.active, this.features = 0});

  @override
  Widget build(BuildContext context) {
    final conf = (features / 15.0).clamp(0.0, 1.0);
    final col  = active
        ? (conf >= 0.75 ? const Color(0xFF00FF88)
           : conf >= 0.45 ? const Color(0xFFFFB300)
           : const Color(0xFFFF3D00))
        : Colors.white24;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: col, width: 1),
      ),
      child: Text(
        active ? '$label  ${features}ft' : label,
        style: TextStyle(
          color: active ? col : Colors.white38,
          fontSize: 10, fontFamily: 'monospace',
        ),
      ),
    );
  }
}

// ── Note row ──────────────────────────────────────────────────

class _NoteRow extends StatelessWidget {
  final Note note;
  final bool isTracked;
  final VoidCallback onPin;
  final String Function(double) fmtDist;

  const _NoteRow({
    required this.note,
    required this.isTracked,
    required this.onPin,
    required this.fmtDist,
  });

  @override
  Widget build(BuildContext context) {
    final color = _hexToColor(note.color);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: isTracked
            ? Colors.greenAccent.withOpacity(0.08)
            : Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isTracked
              ? Colors.greenAccent.withOpacity(0.4)
              : Colors.white12,
          width: isTracked ? 1.5 : 0.5,
        ),
      ),
      child: Row(children: [
        Container(width: 3, height: 30, color: color,
            margin: const EdgeInsets.only(right: 8)),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ScrollingNoteText(
              text: note.text,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              pixelsPerSecond: 28,
            ),
            Row(children: [
              if (isTracked)
                const Text('● TRACKING',
                    style: TextStyle(color: Colors.greenAccent, fontSize: 10))
              else if (note.anchorLat != null)
                Text('📍 ${fmtDist(note.distanceM)} away',
                    style: const TextStyle(color: Colors.white54, fontSize: 10))
              else
                const Text('No GPS anchor',
                    style: TextStyle(color: Colors.white38, fontSize: 10)),
            ]),
          ],
        )),
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.push_pin_outlined, size: 18),
              color: isTracked ? Colors.greenAccent : Colors.white38,
              tooltip: 'Save visual anchor',
              onPressed: onPin,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
            ),
            Text('PIN', style: TextStyle(
              fontSize: 8,
              color: isTracked ? Colors.greenAccent : Colors.white38,
            )),
          ],
        ),
      ]),
    );
  }

  Color _hexToColor(String hex) {
    try {
      return Color(int.parse('FF${hex.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return Colors.greenAccent;
    }
  }
}
