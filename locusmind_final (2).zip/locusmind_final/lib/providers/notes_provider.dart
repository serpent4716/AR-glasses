// providers/notes_provider.dart — v8
//
// GPS FIX: Uses getLastKnownPosition() first (instant, works indoors),
// then tries getCurrentPosition() as an upgrade. This means notes
// always get a GPS anchor even when there's no satellite fix.

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import '../models/note.dart';
import '../database/database_helper.dart';

enum SyncStatus { idle, syncing, success, error }

class NotesProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper();

  List<Note> _notes       = [];
  bool       _isLoading   = false;
  String?    _errorMessage;
  SyncStatus _syncStatus  = SyncStatus.idle;
  Timer?     _ttlTimer;

  List<Note> get notes        => List.unmodifiable(_notes);
  bool       get isLoading    => _isLoading;
  String?    get errorMessage => _errorMessage;
  SyncStatus get syncStatus   => _syncStatus;

  // ── Init ──────────────────────────────────────────────────────────

  Future<void> initialize() async {
    await _loadLocal();
    _startTtlTimer();
  }

  Future<void> _loadLocal() async {
    _isLoading = true;
    notifyListeners();
    try {
      _notes = await _db.getAllNotes();
      _errorMessage = null;
    } catch (e) {
      debugPrint('[Notes] load error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  // ── GPS — three-tier strategy ─────────────────────────────────────
  //
  // Tier 1: getLastKnownPosition()  — instant, works indoors,
  //         uses last cached GPS the OS has from any app.
  // Tier 2: getCurrentPosition() low accuracy — fast coarse fix.
  // Tier 3: getCurrentPosition() high accuracy — only if time allows.
  //
  // Returns null only if location permission is completely denied.

  Future<Position?> _getPhoneLocation() async {
    try {
      // Ask for permission first
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever ||
          permission == LocationPermission.denied) {
        debugPrint('[GPS] permission denied');
        return null;
      }

      // Check service enabled
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        debugPrint('[GPS] location services disabled on device');
        return null;
      }

      // Tier 1: last known position (instant — always try this first)
      try {
        final last = await Geolocator.getLastKnownPosition();
        if (last != null) {
          debugPrint('[GPS] last known: ${last.latitude}, ${last.longitude}');
          // Also kick off a fresh fix in background
          _upgradeGpsInBackground();
          return last;
        }
      } catch (e) {
        debugPrint('[GPS] getLastKnownPosition failed: $e');
      }

      // Tier 2: coarse fast fix (network/cell tower, ~1-3 s)
      try {
        final coarse = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low,
        ).timeout(const Duration(seconds: 5));
        debugPrint('[GPS] coarse fix: ${coarse.latitude}, ${coarse.longitude}');
        return coarse;
      } catch (e) {
        debugPrint('[GPS] coarse fix failed: $e');
      }

      // Tier 3: precise GPS (may take 10-30 s outdoors)
      try {
        final precise = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        ).timeout(const Duration(seconds: 8));
        debugPrint('[GPS] precise fix: ${precise.latitude}, ${precise.longitude}');
        return precise;
      } catch (e) {
        debugPrint('[GPS] precise fix failed: $e');
      }

      return null;
    } catch (e) {
      debugPrint('[GPS] _getPhoneLocation error: $e');
      return null;
    }
  }

  // Background GPS upgrade — updates the most recent note's anchor silently
  void _upgradeGpsInBackground() {
    Future.microtask(() async {
      try {
        final fresh = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium,
        ).timeout(const Duration(seconds: 10));
        // Update the most recently added note if it was just anchored
        if (_notes.isNotEmpty) {
          final n = _notes.first;
          if (n.anchorLat != null) {
            final updated = n.copyWith(
              anchorLat:   fresh.latitude,
              anchorLon:   fresh.longitude,
              anchorFixed: true,
            );
            await _db.upsertNote(updated);
            _notes[0] = updated;
            notifyListeners();
            debugPrint('[GPS] Upgraded anchor: ${fresh.latitude}, ${fresh.longitude}');
          }
        }
      } catch (_) {}
    });
  }

  // ── TTL expiry timer ──────────────────────────────────────────────

  void _startTtlTimer() {
    _ttlTimer?.cancel();
    _ttlTimer = Timer.periodic(const Duration(seconds: 60), (_) async {
      final now    = DateTime.now();
      final before = _notes.length;
      _notes.removeWhere((n) {
        final expiry = n.expiryTime;
        return expiry != null && now.isAfter(expiry);
      });
      if (_notes.length != before) {
        await _db.deleteExpiredNotes();
        notifyListeners();
      }
    });
  }

  // ── Create ────────────────────────────────────────────────────────

  Future<void> addNote(Note note) async {
    _isLoading = true;
    notifyListeners();
    try {
      // Use whatever GPS we have (last known or live)
      final pos = await _getPhoneLocation();
      final anchored = note.copyWith(
        anchorLat:   pos?.latitude  ?? note.anchorLat,
        anchorLon:   pos?.longitude ?? note.anchorLon,
        anchorFixed: (pos != null) || note.anchorFixed,
        isPendingSync: false,
      );
      await _db.upsertNote(anchored);
      _notes.insert(0, anchored);
      _errorMessage = null;
      debugPrint('[Notes] Added: "${anchored.text}"  '
          'GPS=${anchored.anchorLat?.toStringAsFixed(5)},${anchored.anchorLon?.toStringAsFixed(5)}');
    } catch (e) {
      debugPrint('[Notes] addNote error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<Note> addNoteWithTtl({
    required String text,
    String color    = '#00FF88',
    int ttlSeconds  = 0,
  }) async {
    final now    = DateTime.now();
    final expiry = ttlSeconds > 0 ? now.add(Duration(seconds: ttlSeconds)) : null;
    final tempId = now.millisecondsSinceEpoch.toRadixString(16).substring(0, 8);

    _isLoading = true;
    notifyListeners();

    // Get GPS (instant if last known available)
    final pos = await _getPhoneLocation();

    final note = Note(
      id:           tempId,
      text:         text,
      color:        color,
      visible:      true,
      isPendingSync: false,
      expiryTime:   expiry,
      anchorLat:    pos?.latitude,
      anchorLon:    pos?.longitude,
      anchorFixed:  pos != null,
    );

    try {
      await _db.upsertNote(note);
      _notes.insert(0, note);
      _errorMessage = null;
      debugPrint('[Notes] addNoteWithTtl: "${note.text}"  '
          'GPS=${note.anchorLat?.toStringAsFixed(5)},${note.anchorLon?.toStringAsFixed(5)}');
    } catch (e) {
      debugPrint('[Notes] addNoteWithTtl error: $e');
    }

    _isLoading = false;
    notifyListeners();
    return note;
  }

  // ── Update ────────────────────────────────────────────────────────

  Future<void> updateNote(Note note) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _db.upsertNote(note);
      final idx = _notes.indexWhere((n) => n.id == note.id);
      if (idx != -1) _notes[idx] = note;
      _errorMessage = null;
    } catch (e) {
      debugPrint('[Notes] updateNote error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  // ── Delete ────────────────────────────────────────────────────────

  Future<void> deleteNote(String id) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _db.deleteNote(id);
      _notes.removeWhere((n) => n.id == id);
      _errorMessage = null;
    } catch (e) {
      debugPrint('[Notes] deleteNote error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  // ── Visibility toggle ─────────────────────────────────────────────

  Future<void> toggleVisibility(Note note) async {
    await updateNote(note.copyWith(visible: !note.visible));
  }

  // ── Refresh distances (call periodically from HomeScreen) ─────────

  Future<void> refreshDistances() async {
    final pos = await _getPhoneLocation();
    if (pos == null) return;

    bool changed = false;
    for (int i = 0; i < _notes.length; i++) {
      final n = _notes[i];
      if (n.anchorLat != null && n.anchorLon != null) {
        final dist = Geolocator.distanceBetween(
          pos.latitude, pos.longitude,
          n.anchorLat!, n.anchorLon!,
        );
        if ((dist - n.distanceM).abs() > 0.5) {
          _notes[i] = n.copyWith(distanceM: dist);
          changed = true;
        }
      }
    }
    if (changed) notifyListeners();
  }

  // ── Helpers ───────────────────────────────────────────────────────

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  Future<void> clearAll() async {
    _ttlTimer?.cancel();
    await _db.clearAll();
    _notes        = [];
    _errorMessage = null;
    _syncStatus   = SyncStatus.idle;
    notifyListeners();
    _startTtlTimer();
  }

  @override
  void dispose() {
    _ttlTimer?.cancel();
    super.dispose();
  }
}
