// providers/theme_provider.dart
// Manages app-wide ThemeMode with persistence via AuthService.

import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _mode = ThemeMode.system;
  final AuthService _auth = AuthService();

  ThemeMode get themeMode => _mode;

  Future<void> loadTheme() async {
    _mode = _parse(await _auth.getThemeMode());
    notifyListeners();
  }

  Future<void> setTheme(ThemeMode mode) async {
    _mode = mode;
    await _auth.setThemeMode(_stringify(mode));
    notifyListeners();
  }

  ThemeMode _parse(String s) => switch (s) {
        'light' => ThemeMode.light,
        'dark'  => ThemeMode.dark,
        _       => ThemeMode.system,
      };

  String _stringify(ThemeMode m) => switch (m) {
        ThemeMode.light => 'light',
        ThemeMode.dark  => 'dark',
        _               => 'system',
      };
}
