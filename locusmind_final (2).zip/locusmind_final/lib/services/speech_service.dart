// services/speech_service.dart
// ============================================================
// Voice-to-text service using speech_to_text package.
// Used by CameraViewScreen to create notes via voice dictation.
// ============================================================

import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

class SpeechService extends ChangeNotifier {
  static final SpeechService _i = SpeechService._();
  factory SpeechService() => _i;
  SpeechService._();

  final _stt = SpeechToText();

  bool   _available  = false;
  bool   _listening  = false;
  String _lastWords  = '';

  bool   get isAvailable => _available;
  bool   get isListening => _listening;
  String get lastWords   => _lastWords;

  /// Call once on app start (or lazily before first use).
  Future<void> init() async {
    _available = await _stt.initialize(
      onStatus: (status) {
        _listening = status == 'listening';
        notifyListeners();
      },
      onError: (_) {
        _listening = false;
        notifyListeners();
      },
    );
    notifyListeners();
  }

  /// Begin listening. Calls [onResult] with the recognised text when done.
  Future<void> startListening(void Function(String text) onResult) async {
    if (!_available) await init();
    if (!_available || _listening) return;

    _lastWords = '';
    _listening = true;
    notifyListeners();

    await _stt.listen(
      onResult: (result) {
        _lastWords = result.recognizedWords;
        notifyListeners();
        if (result.finalResult && result.recognizedWords.trim().isNotEmpty) {
          onResult(result.recognizedWords.trim());
        }
      },
      listenFor:      const Duration(seconds: 30),
      pauseFor:       const Duration(seconds: 3),
      listenMode:     ListenMode.dictation,
      cancelOnError:  true,
      partialResults: true,
    );
  }

  Future<void> stopListening() async {
    await _stt.stop();
    _listening = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _stt.cancel();
    super.dispose();
  }
}
