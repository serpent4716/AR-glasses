// lib/services/vio_ffi_service.dart
// Dart FFI bindings for the C++ VIO backend
// Loads liblocusmind_vio.so at runtime and exposes all C API functions

import 'dart:ffi';
import 'dart:io';
import 'package:ffi/ffi.dart';

// ═════════════════════════════════════════════════════════════════════════════
//  FFI DYNAMIC LIBRARY LOADING
// ═════════════════════════════════════════════════════════════════════════════

DynamicLibrary _openVioLibrary() {
  if (Platform.isAndroid) {
    return DynamicLibrary.open('liblocusmind_vio.so');
  } else if (Platform.isIOS) {
    return DynamicLibrary.process(); // iOS uses static linking
  } else if (Platform.isMacOS || Platform.isLinux) {
    return DynamicLibrary.open('liblocusmind_vio.dylib');
  }
  throw UnsupportedError('Platform not supported: ${Platform.operatingSystem}');
}

late final DynamicLibrary _vioLib = _openVioLibrary();

// ═════════════════════════════════════════════════════════════════════════════
//  C STRUCTURE DEFINITIONS (Dart FFI)
// ═════════════════════════════════════════════════════════════════════════════

// Vec3
typedef Vec3Native = Struct;
final class Vec3 extends Struct {
  @Double()
  external double x;
  @Double()
  external double y;
  @Double()
  external double z;
}

// Quat
typedef QuatNative = Struct;
final class Quat extends Struct {
  @Double()
  external double w;
  @Double()
  external double x;
  @Double()
  external double y;
  @Double()
  external double z;
}

// Pose6D
typedef Pose6DNative = Struct;
final class Pose6D extends Struct {
  external Vec3 position;
  external Quat orientation;
}

// ImuReading
typedef ImuReadingNative = Struct;
final class ImuReading extends Struct {
  external Vec3 accel;
  external Vec3 gyro;
  @Uint64()
  external int timestampUs;
}

// BaroReading
typedef BaroReadingNative = Struct;
final class BaroReading extends Struct {
  @Double()
  external double pressureHpa;
  @Double()
  external double altitudeM;
  @Uint64()
  external int timestampUs;
}

// MagReading
typedef MagReadingNative = Struct;
final class MagReading extends Struct {
  external Vec3 magneticUt;
  @Double()
  external double headingDeg;
  @Uint64()
  external int timestampUs;
}

// VisualFeature
typedef VisualFeatureNative = Struct;
final class VisualFeature extends Struct {
  @Float()
  external double x;
  @Float()
  external double y;
  @Array(32)
  external Array<Uint8> descriptor;
  @Uint32()
  external int id;
}

// Keyframe
typedef KeyframeNative = Struct;
final class Keyframe extends Struct {
  @Uint64()
  external int timestampUs;
  external Pose6D pose;
  external Pointer<VisualFeature> features;
  @Uint32()
  external int featureCount;
  external Pointer<Uint8> thumbnail;
}

// VioState
typedef VioStateNative = Struct;
final class VioState extends Struct {
  external Pose6D pose;
  external Vec3 velocity;
  external Vec3 gyroBias;
  external Vec3 accelBias;
  @Double()
  external double altitudeM;
  @Double()
  external double headingDeg;
  @Uint32()
  external int trackedFeatures;
  @Uint32()
  external int keyframeCount;
  @Float()
  external double confidence;
  @Uint8()
  external int isTracking;
  @Array(64)
  external Array<Uint8> statusMsg;
}

// WifiAp
typedef WifiApNative = Struct;
final class WifiAp extends Struct {
  @Array(32)
  external Array<Uint8> ssid;
  @Int32()
  external int rssiDbm;
}

// WifiFingerprint
typedef WifiFingerprintNative = Struct;
final class WifiFingerprint extends Struct {
  external Pointer<WifiAp> aps;
  @Uint32()
  external int apCount;
  @Uint64()
  external int timestampUs;
}

// LoopClosureResult
typedef LoopClosureResultNative = Struct;
final class LoopClosureResult extends Struct {
  @Uint8()
  external int visualMatch;
  @Uint8()
  external int altitudeMatch;
  @Uint8()
  external int headingMatch;
  @Uint8()
  external int wifiMatch;
  @Float()
  external double confidence;
  @Array(128)
  external Array<Uint8> rejectionReason;
}

// ═════════════════════════════════════════════════════════════════════════════
//  FFI FUNCTION SIGNATURES
// ═════════════════════════════════════════════════════════════════════════════

// vio_init
typedef VioInitC = Pointer<Void> Function(Double, Double, Double, Double, Double, Double);
typedef VioInitDart = Pointer<Void> Function(double, double, double, double, double, double);
final VioInitDart vioInit = _vioLib.lookupFunction<VioInitC, VioInitDart>('vio_init');

// vio_destroy
typedef VioDestroyC = Void Function(Pointer<Void>);
typedef VioDestroyDart = void Function(Pointer<Void>);
final VioDestroyDart vioDestroy = _vioLib.lookupFunction<VioDestroyC, VioDestroyDart>('vio_destroy');

// vio_process_imu_batch
typedef VioProcessImuC = Void Function(Pointer<Void>, Pointer<ImuReading>, Uint32);
typedef VioProcessImuDart = void Function(Pointer<Void>, Pointer<ImuReading>, int);
final VioProcessImuDart vioProcessImuBatch = 
    _vioLib.lookupFunction<VioProcessImuC, VioProcessImuDart>('vio_process_imu_batch');

// vio_process_baro
typedef VioProcessBaroC = Void Function(Pointer<Void>, Pointer<BaroReading>);
typedef VioProcessBaroDart = void Function(Pointer<Void>, Pointer<BaroReading>);
final VioProcessBaroDart vioProcessBaro = 
    _vioLib.lookupFunction<VioProcessBaroC, VioProcessBaroDart>('vio_process_baro');

// vio_process_mag
typedef VioProcessMagC = Void Function(Pointer<Void>, Pointer<MagReading>);
typedef VioProcessMagDart = void Function(Pointer<Void>, Pointer<MagReading>);
final VioProcessMagDart vioProcessMag = 
    _vioLib.lookupFunction<VioProcessMagC, VioProcessMagDart>('vio_process_mag');

// vio_process_keyframe
typedef VioProcessKeyframeC = Void Function(Pointer<Void>, Pointer<Keyframe>);
typedef VioProcessKeyframeDart = void Function(Pointer<Void>, Pointer<Keyframe>);
final VioProcessKeyframeDart vioProcessKeyframe = 
    _vioLib.lookupFunction<VioProcessKeyframeC, VioProcessKeyframeDart>('vio_process_keyframe');

// vio_get_state
typedef VioGetStateC = Void Function(Pointer<Void>, Pointer<VioState>);
typedef VioGetStateDart = void Function(Pointer<Void>, Pointer<VioState>);
final VioGetStateDart vioGetState = 
    _vioLib.lookupFunction<VioGetStateC, VioGetStateDart>('vio_get_state');

// vio_check_loop_closure
typedef VioCheckLoopClosureC = Void Function(Pointer<Void>, Pointer<Utf8>, Double, Double, Pointer<WifiFingerprint>, Pointer<LoopClosureResult>);
typedef VioCheckLoopClosureDart = void Function(Pointer<Void>, Pointer<Utf8>, double, double, Pointer<WifiFingerprint>, Pointer<LoopClosureResult>);
final VioCheckLoopClosureDart vioCheckLoopClosure = 
    _vioLib.lookupFunction<VioCheckLoopClosureC, VioCheckLoopClosureDart>('vio_check_loop_closure');

// vio_save_map — returns int32_t (1=success, 0=failure); header fixed in Block 3
typedef VioSaveMapC = Int32 Function(Pointer<Void>, Pointer<Utf8>);
typedef VioSaveMapDart = int Function(Pointer<Void>, Pointer<Utf8>);
final VioSaveMapDart vioSaveMap = 
    _vioLib.lookupFunction<VioSaveMapC, VioSaveMapDart>('vio_save_map');

// vio_load_map — returns int32_t (1=success, 0=failure); header fixed in Block 3
typedef VioLoadMapC = Int32 Function(Pointer<Void>, Pointer<Utf8>);
typedef VioLoadMapDart = int Function(Pointer<Void>, Pointer<Utf8>);
final VioLoadMapDart vioLoadMap = 
    _vioLib.lookupFunction<VioLoadMapC, VioLoadMapDart>('vio_load_map');

// vio_reset
typedef VioResetC = Void Function(Pointer<Void>);
typedef VioResetDart = void Function(Pointer<Void>);
final VioResetDart vioReset = 
    _vioLib.lookupFunction<VioResetC, VioResetDart>('vio_reset');

// vio_get_feature_count
typedef VioGetFeatureCountC = Uint32 Function(Pointer<Void>);
typedef VioGetFeatureCountDart = int Function(Pointer<Void>);
final VioGetFeatureCountDart vioGetFeatureCount = 
    _vioLib.lookupFunction<VioGetFeatureCountC, VioGetFeatureCountDart>('vio_get_feature_count');

// vio_get_keyframe_count
typedef VioGetKeyframeCountC = Uint32 Function(Pointer<Void>);
typedef VioGetKeyframeCountDart = int Function(Pointer<Void>);
final VioGetKeyframeCountDart vioGetKeyframeCount = 
    _vioLib.lookupFunction<VioGetKeyframeCountC, VioGetKeyframeCountDart>('vio_get_keyframe_count');

