// lib/services/map_persistence_service.dart
// Implements spec step 11: Map Persistence & Auto-Save
//
// Auto-saves the VIO pose graph + keyframe DB every 30 seconds to the app's
// documents directory. On startup, attempts to load the last saved map so the
// system can re-localise without a cold start.
//
// Usage:
//   await MapPersistenceService().initialize();   // call once in main.dart
//   await MapPersistenceService().forceSave();    // call on app pause/battery warning

import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'phone_slam_vio_service.dart';

class MapPersistenceService {
  final PhoneVioService vioService;
  MapPersistenceService(this.vioService);

  // ── State ──────────────────────────────────────────────────────────────────
  Timer? _autoSaveTimer;
  bool _initialized = false;
  bool _mapLoaded = false;
  String? _lastError;
  DateTime? _lastSaveTime;

  // ── Getters ────────────────────────────────────────────────────────────────
  bool get isInitialized => _initialized;

  /// True if a previously saved map was successfully loaded on startup.
  bool get isMapLoaded => _mapLoaded;

  String? get lastError => _lastError;
  DateTime? get lastSaveTime => _lastSaveTime;

  // ── File path ──────────────────────────────────────────────────────────────

  Future<String> get _mapPath async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/locusmind_map.bin';
  }

  // ── Initialization ─────────────────────────────────────────────────────────

  /// Call once on app startup (e.g. in main.dart after runApp, or in the root
  /// widget's initState). Safe to call multiple times — no-op after first call.
  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    // Attempt to load the last saved map
    await _tryLoadMap();

    // Start 30-second auto-save timer
    _autoSaveTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => _autoSave(),
    );

    debugPrint('[Map] Persistence service initialized (map loaded: $_mapLoaded)');
  }

  // ── Load ───────────────────────────────────────────────────────────────────

  Future<void> _tryLoadMap() async {
    try {
      final path = await _mapPath;
      final file = File(path);

      if (!await file.exists()) {
        debugPrint('[Map] No saved map found — cold start');
        return;
      }

      final ok = await vioService.loadMap(path);
      _mapLoaded = ok;

      if (ok) {
        debugPrint('[Map] Loaded map from $path');
      } else {
        _lastError = 'Map file exists but failed to load (corrupt?)';
        debugPrint('[Map] $_lastError');
      }
    } catch (e) {
      _lastError = 'Load error: $e';
      debugPrint('[Map] $_lastError');
    }
  }

  // ── Save ───────────────────────────────────────────────────────────────────

  Future<void> _autoSave() async {
    try {
      final path = await _mapPath;
      final ok = await vioService.saveMap(path);
      if (ok) {
        _lastSaveTime = DateTime.now();
        debugPrint('[Map] Auto-saved at $_lastSaveTime');
      } else {
        _lastError = 'Auto-save returned false (VIO not initialized?)';
        debugPrint('[Map] $_lastError');
      }
    } catch (e) {
      _lastError = 'Auto-save error: $e';
      debugPrint('[Map] $_lastError');
    }
  }

  /// Force an immediate save — call this when:
  ///   - App goes to background (AppLifecycleState.paused)
  ///   - Battery warning received
  ///   - User explicitly requests save
  Future<void> forceSave() async {
    debugPrint('[Map] Force save requested');
    await _autoSave();
  }

  /// Delete the saved map file — useful for "reset to factory" flows.
  Future<void> deleteMap() async {
    try {
      final path = await _mapPath;
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
        _mapLoaded = false;
        debugPrint('[Map] Saved map deleted');
      }
    } catch (e) {
      _lastError = 'Delete error: $e';
      debugPrint('[Map] $_lastError');
    }
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  void dispose() {
    _autoSaveTimer?.cancel();
    _autoSaveTimer = null;
  }
}
