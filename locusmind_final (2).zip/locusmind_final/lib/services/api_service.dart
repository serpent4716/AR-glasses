// services/api_service.dart
// ============================================================
// REST client for pi_server.py v6 and pc_slam_server.py.
//
// Pi server base URL:      http://<PI_IP>:5000
// PC SLAM server base URL: http://<PC_IP>:6001
//
// Pi endpoints used by this app:
//   GET    /api/notes          → list all notes
//   POST   /api/notes          → create note  body: {text, color}
//   PATCH  /api/notes/<id>     → update note  body: {text, color, visible, x, y, w, h}
//   DELETE /api/notes/<id>     → delete note
//   GET    /api/gps            → GPS fix state
//   GET    /api/slam           → SLAM tracking state
//
// PC SLAM endpoint:
//   GET    /health             → connectivity check
// ============================================================

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note.dart';
import '../utils/constants.dart';

/// Thrown when any API call fails.
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() =>
      statusCode != null ? '$message (HTTP $statusCode)' : message;
}

class ApiService {
  // Singleton
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final http.Client _client = http.Client();

  static const Map<String, String> _headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // ── URL helpers ──────────────────────────────────────────────────

  Future<String> _piBase() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getString(kPrefApiBaseUrl) ?? kDefaultPiBaseUrl).trimRight();
  }

  Future<String?> _pcBase() async {
    final prefs = await SharedPreferences.getInstance();
    final url = prefs.getString(kPrefPcSlamUrl) ?? '';
    return url.isEmpty ? null : url.trimRight();
  }

  // ── Notes API ────────────────────────────────────────────────────

  /// GET /api/notes — fetch all notes from the Pi.
  Future<List<Note>> getNotes() async {
    final base = await _piBase();
    try {
      final response = await _client
          .get(Uri.parse('$base/api/notes'), headers: _headers)
          .timeout(kApiTimeout);
      if (response.statusCode == 200) {
        final List<dynamic> list = jsonDecode(response.body);
        return list.map((j) => Note.fromJson(j as Map<String, dynamic>)).toList();
      }
      throw ApiException('GET /api/notes failed: ${response.reasonPhrase}',
          statusCode: response.statusCode);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Network error: $e');
    }
  }

  /// POST /api/notes — create a new note on the Pi.
  /// Pi returns: {"ok": true, "id": "a3f9bc12"}
  /// Returns the Pi-assigned ID string on success.
  Future<String> createNote(Note note) async {
    final base = await _piBase();
    try {
      final response = await _client
          .post(
            Uri.parse('$base/api/notes'),
            headers: _headers,
            body: jsonEncode(note.toCreateJson()),
          )
          .timeout(kApiTimeout);
      if (response.statusCode == 200 || response.statusCode == 201) {
        final json = jsonDecode(response.body) as Map<String, dynamic>;
        if (json['ok'] == true && json['id'] != null) {
          return json['id'].toString();
        }
        throw ApiException('Pi returned ok=false on create');
      }
      throw ApiException('POST /api/notes failed: ${response.reasonPhrase}',
          statusCode: response.statusCode);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Network error: $e');
    }
  }

  /// PATCH /api/notes/<id> — update an existing note on the Pi.
  /// Pi returns: {"ok": true}
  Future<void> updateNote(Note note) async {
    final base = await _piBase();
    try {
      final response = await _client
          .patch(
            Uri.parse('$base/api/notes/${note.id}'),
            headers: _headers,
            body: jsonEncode(note.toUpdateJson()),
          )
          .timeout(kApiTimeout);
      if (response.statusCode != 200) {
        throw ApiException('PATCH /api/notes/${note.id} failed: ${response.reasonPhrase}',
            statusCode: response.statusCode);
      }
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Network error: $e');
    }
  }

  /// DELETE /api/notes/<id> — delete a note from the Pi.
  Future<void> deleteNote(String id) async {
    final base = await _piBase();
    try {
      final response = await _client
          .delete(Uri.parse('$base/api/notes/$id'), headers: _headers)
          .timeout(kApiTimeout);
      if (response.statusCode != 200 && response.statusCode != 204) {
        throw ApiException('DELETE /api/notes/$id failed: ${response.reasonPhrase}',
            statusCode: response.statusCode);
      }
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Network error: $e');
    }
  }

  // ── GPS & SLAM status ────────────────────────────────────────────

  /// GET /api/gps — current GPS fix state from the Pi.
  Future<GpsState> getGps() async {
    final base = await _piBase();
    try {
      final response = await _client
          .get(Uri.parse('$base/api/gps'), headers: _headers)
          .timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        return GpsState.fromJson(
            jsonDecode(response.body) as Map<String, dynamic>);
      }
      throw ApiException('GET /api/gps failed', statusCode: response.statusCode);
    } catch (_) {
      return const GpsState();
    }
  }

  /// GET /api/slam — SLAM tracking state from the Pi.
  Future<SlamStatus> getSlam() async {
    final base = await _piBase();
    try {
      final response = await _client
          .get(Uri.parse('$base/api/slam'), headers: _headers)
          .timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        return SlamStatus.fromJson(
            jsonDecode(response.body) as Map<String, dynamic>);
      }
      throw ApiException('GET /api/slam failed', statusCode: response.statusCode);
    } catch (_) {
      return const SlamStatus();
    }
  }

  // ── Connectivity checks ──────────────────────────────────────────

  /// Ping the Pi by calling GET /api/notes — returns true if reachable.
  Future<bool> pingPi() async {
    try {
      final base = await _piBase();
      final response = await _client
          .get(Uri.parse('$base/api/notes'), headers: _headers)
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Ping the PC SLAM server via GET /health — returns true if reachable.
  Future<bool> pingPcSlam() async {
    try {
      final base = await _pcBase();
      if (base == null) return false;
      final response = await _client
          .get(Uri.parse('$base/health'), headers: _headers)
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  void dispose() => _client.close();
}
