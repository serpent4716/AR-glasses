import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import '../models/note.dart';

// ═════════════════════════════════════════════════════════════════════════════
//  DART-FRIENDLY VIO STATE
// ═════════════════════════════════════════════════════════════════════════════

class VioPose {
  final double x, y, z;           // total position from origin (meters)
  final double dx, dy, dz;        // delta drift from previous point (meters)
  final double qw, qx, qy, qz;   // orientation quaternion
  final double vx, vy, vz;       // velocity (m/s)
  final double altitude;          // barometer altitude (m)
  final double heading;           // magnetometer heading (deg)
  final int trackedFeatures;
  final int keyframeCount;
  final double confidence;
  final bool isTracking;
  final String status;

  const VioPose({
    this.x = 0, this.y = 0, this.z = 0,
    this.dx = 0, this.dy = 0, this.dz = 0,
    this.qw = 1, this.qx = 0, this.qy = 0, this.qz = 0,
    this.vx = 0, this.vy = 0, this.vz = 0,
    this.altitude = 0,
    this.heading = 0,
    this.trackedFeatures = 0,
    this.keyframeCount = 0,
    this.confidence = 0,
    this.isTracking = false,
    this.status = "Initializing",
  });
}

class VisualFeatureDart {
  final double x, y;           // normalized 0-1
  final Uint8List descriptor;  // 32 bytes BRIEF
  final int id;

  VisualFeatureDart({required this.x, required this.y, required this.descriptor, required this.id});
}

// ═════════════════════════════════════════════════════════════════════════════
//  PHONE VIO SERVICE — PURE DART FALLBACK
// ═════════════════════════════════════════════════════════════════════════════

class PhoneVioService extends ChangeNotifier {
  PhoneVioService() {
    _initVio();
  }

  VioPose _currentPose = const VioPose();
  bool _isInitialized = false;
  String? _error;

  // Internal state
  double _pitch = 0, _roll = 0, _yaw = 0;
  double _heading = 0;
  double _alt = 0;
  double _vx = 0, _vy = 0, _vz = 0;
  double _px = 0, _py = 0, _pz = 0;
  double _lastDx = 0, _lastDy = 0, _lastDz = 0; // delta drift
  int _lastTimestampUs = 0;
  
  // Confidence components
  bool _imuActive = false;
  bool _baroActive = false;
  bool _magActive = false;
  bool _motionDetected = false;
  
  Timer? _decayTimer;

  VioPose get currentPose => _currentPose;
  bool get isTracking => _currentPose.isTracking;
  bool get isInitialized => _isInitialized;
  String? get error => _error;

  // ═─ Initialization ───────────────────────────────────────────────

  void _initVio() {
    _isInitialized = true;
    _decayTimer = Timer.periodic(const Duration(seconds: 1), (_) => _decayConfidence());
    debugPrint('[VIO] Pure Dart Backend initialized successfully');
  }

  void _decayConfidence() {
    _imuActive = false;
    _baroActive = false;
    _magActive = false;
    _updateState();
  }

  // ═─ Process IMU Batch ───────────────────────────────────────────

  void processImuBatch(List<List<double>> imuReadings, int timestampUs) {
    if (imuReadings.isEmpty) return;
    _imuActive = true;

    for (int i = 0; i < imuReadings.length; i++) {
      final r = imuReadings[i];
      final ax = r[0];
      final ay = r[1];
      final az = r[2];
      final gx = r[3]; // dps
      final gy = r[4];
      final gz = r[5];
      
      final currentTs = timestampUs + (i * 10000);
      double dt = 0.01; // 10ms per sample approx
      if (_lastTimestampUs != 0) {
        dt = (currentTs - _lastTimestampUs) / 1000000.0;
        if (dt <= 0 || dt > 0.1) dt = 0.01;
      }
      _lastTimestampUs = currentTs;

      // Complementary filter
      double gyroPitch = _pitch + (gy * pi / 180.0) * dt;
      double gyroRoll = _roll + (gx * pi / 180.0) * dt;
      
      double accelPitch = atan2(ay, sqrt(ax * ax + az * az));
      double accelRoll = atan2(-ax, az);
      
      _pitch = 0.98 * gyroPitch + 0.02 * accelPitch;
      _roll = 0.98 * gyroRoll + 0.02 * accelRoll;

      // Dead reckoning
      // 1. Rotate accel to world frame
      // Simplified: just assuming small angles for now
      double lax = ax - (-sin(_pitch));
      double lay = ay - (sin(_roll));
      double laz = az - (cos(_pitch) * cos(_roll));

      // 2. Subtract gravity
      laz -= 1.0; // Assuming 1g is baseline

      double linAccelMag = sqrt(lax*lax + lay*lay + laz*laz);
      
      // 3. Check motion & update velocity
      if (linAccelMag < 0.05) { // tuned for normalized g
        _motionDetected = false;
        _vx *= 0.95;
        _vy *= 0.95;
        _vz *= 0.95;
      } else {
        _motionDetected = true;
        _vx += lax * 9.81 * dt;
        _vy += lay * 9.81 * dt;
        _vz += laz * 9.81 * dt;
      }

      // 4. Update position (calculate explicit dy/dx drift from previous point)
      double dX = _vx * dt;
      double dY = _vy * dt;
      
      _px += dX;
      _py += dY;
      
      _lastDx += dX;
      _lastDy += dY;
      // Z-axis handled by barometer primarily, but we can integrate too
    }
    
    _updateState();
  }

  // ═─ Process Barometer ────────────────────────────────────────────

  void processBarometer(double pressureHpa, double altitudeM, int timestampUs) {
    _baroActive = true;
    double oldAlt = _alt;
    _alt = 0.1 * altitudeM + 0.9 * _alt;
    _lastDz += (_alt - oldAlt);
    _pz = _alt;
    _updateState();
  }

  // ═─ Process Magnetometer ───────────────────────────────────────

  void processMagnetometer(List<double> magneticUt, double headingDeg, int timestampUs) {
    _magActive = true;
    
    // Un-wrap heading for smoothing
    double diff = headingDeg - _heading;
    while (diff > 180) diff -= 360;
    while (diff < -180) diff += 360;
    
    _heading = _heading + 0.1 * diff;
    while (_heading >= 360) _heading -= 360;
    while (_heading < 0) _heading += 360;
    
    _updateState();
  }

  // ═─ Process Keyframe ───────────────────────────────────────────

  void processKeyframe(List<VisualFeatureDart> features, int timestampUs) {
    // Feature tracking currently not implemented in pure dart
  }

  // ═─ Multi-Modal Loop Closure ──────────────────────────────────

  Future<bool> checkLoopClosure(Note candidateNote) async {
    return false; // Visual matching not possible in Dart without image library
  }

  // ═─ State Update ──────────────────────────────────────────────

  void _updateState() {
    double confidence = 0.0;
    if (_imuActive) confidence += 0.5;
    if (_baroActive) confidence += 0.15;
    if (_magActive) confidence += 0.1;
    if (_motionDetected) confidence += 0.05;
    
    _currentPose = VioPose(
      x: _px, y: _py, z: _pz,
      dx: _lastDx, dy: _lastDy, dz: _lastDz,
      qw: 1, qx: 0, qy: 0, qz: 0, // Not converting euler to quat for now
      vx: _vx, vy: _vy, vz: _vz,
      altitude: _alt,
      heading: _heading,
      confidence: confidence,
      isTracking: confidence > 0.4,
      status: "Dart Fallback Active",
    );
    // Reset deltas after reporting them
    _lastDx = 0; _lastDy = 0; _lastDz = 0;
    notifyListeners();
  }

  // ═─ Map Persistence ────────────────────────────────────────────

  Future<bool> saveMap(String filepath) async => true;
  Future<bool> loadMap(String filepath) async => true;

  // ═─ Reset ──────────────────────────────────────────────────────

  void reset() {
    _pitch = _roll = _yaw = 0;
    _px = _py = _pz = 0;
    _vx = _vy = _vz = 0;
    _lastTimestampUs = 0;
    _currentPose = const VioPose();
    notifyListeners();
  }

  // ═─ Debug Info ─────────────────────────────────────────────────

  Map<String, dynamic> get debugInfo {
    return {
      'features': 0,
      'keyframes': 0,
      'confidence': _currentPose.confidence,
      'tracking': _currentPose.isTracking,
      'status': _currentPose.status,
    };
  }

  @override
  void dispose() {
    _decayTimer?.cancel();
    super.dispose();
  }
}
