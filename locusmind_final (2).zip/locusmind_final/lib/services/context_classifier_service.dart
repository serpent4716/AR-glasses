// lib/services/context_classifier_service.dart
// Implements spec step 12: Context Classification & Dynamic Parameter Adjustment
//
// Every 2 seconds, reads feature density and confidence from PhoneVioService
// and classifies the current environment into one of four types. Each type
// maps to a VioParams set that the ESP32 and VIO backend should use.
//
// Environment → VIO parameter mapping:
//   whiteRoom   → lower Shi-Tomasi threshold (try harder), trust IMU more
//   corridor    → moderate params
//   texturedRoom → standard params, loose loop closure
//   outdoor     → higher threshold (fewer but better features), loose loop closure
//
// Usage:
//   ContextClassifierService().startClassifying();  // call in home_screen initState
//   ContextClassifierService().stopClassifying();   // call in dispose

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'phone_slam_vio_service.dart';

// ═════════════════════════════════════════════════════════════════════════════
//  ENVIRONMENT TYPE
// ═════════════════════════════════════════════════════════════════════════════

enum EnvironmentType {
  texturedRoom,   // good features, stable tracking
  whiteRoom,      // few/no features, visual blackout likely
  corridor,       // moderate features, repetitive structure
  outdoor,        // many features but fast motion, large scale
  unknown,        // initial state before first classification
}

extension EnvironmentTypeLabel on EnvironmentType {
  String get label {
    switch (this) {
      case EnvironmentType.texturedRoom:  return 'Textured Room';
      case EnvironmentType.whiteRoom:     return 'White Room';
      case EnvironmentType.corridor:      return 'Corridor';
      case EnvironmentType.outdoor:       return 'Outdoor';
      case EnvironmentType.unknown:       return 'Unknown';
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
//  VIO PARAMS (sent to ESP32 via BLE command + used in Kalman filter)
// ═════════════════════════════════════════════════════════════════════════════

class VioParams {
  /// Shi-Tomasi corner quality threshold (0.005–0.02).
  /// Lower = more corners detected (useful in sparse environments).
  final double shiTomasiThreshold;

  /// Multiplier on IMU noise covariance (0.5–1.5).
  /// < 1.0 = trust IMU more (useful in visual blackout).
  /// > 1.0 = trust IMU less (useful outdoors with vibration).
  final double imuNoiseMultiplier;

  /// Loop closure strictness (0.5–0.9).
  /// Higher = require stronger multi-modal agreement before closing a loop.
  final double loopClosureStrictness;

  const VioParams({
    this.shiTomasiThreshold   = 0.01,
    this.imuNoiseMultiplier   = 1.0,
    this.loopClosureStrictness = 0.7,
  });

  @override
  bool operator ==(Object other) =>
      other is VioParams &&
      other.shiTomasiThreshold   == shiTomasiThreshold &&
      other.imuNoiseMultiplier   == imuNoiseMultiplier &&
      other.loopClosureStrictness == loopClosureStrictness;

  @override
  int get hashCode => Object.hash(
        shiTomasiThreshold, imuNoiseMultiplier, loopClosureStrictness);

  @override
  String toString() =>
      'VioParams(shi=$shiTomasiThreshold, '
      'imu=$imuNoiseMultiplier, '
      'loop=$loopClosureStrictness)';
}

// ═════════════════════════════════════════════════════════════════════════════
//  CONTEXT CLASSIFIER SERVICE
// ═════════════════════════════════════════════════════════════════════════════

class ContextClassifierService extends ChangeNotifier {
  final PhoneVioService vioService;
  ContextClassifierService(this.vioService);

  // ── State ──────────────────────────────────────────────────────────────────
  Timer? _timer;
  EnvironmentType _environment = EnvironmentType.unknown;
  VioParams _params = const VioParams();

  EnvironmentType get environment => _environment;
  VioParams get params => _params;
  bool get isClassifying => _timer != null;

  // ── Param presets per environment ─────────────────────────────────────────

  static const Map<EnvironmentType, VioParams> _presets = {
    EnvironmentType.whiteRoom: VioParams(
      shiTomasiThreshold:    0.005,  // lower = try harder to find features
      imuNoiseMultiplier:    0.5,    // trust IMU more during visual blackout
      loopClosureStrictness: 0.9,    // very strict — don't close loop in featureless space
    ),
    EnvironmentType.corridor: VioParams(
      shiTomasiThreshold:    0.008,
      imuNoiseMultiplier:    0.8,
      loopClosureStrictness: 0.75,
    ),
    EnvironmentType.texturedRoom: VioParams(
      shiTomasiThreshold:    0.01,   // standard
      imuNoiseMultiplier:    1.0,
      loopClosureStrictness: 0.6,    // loose — good features → high confidence
    ),
    EnvironmentType.outdoor: VioParams(
      shiTomasiThreshold:    0.015,  // higher = fewer but stronger corners
      imuNoiseMultiplier:    1.2,    // trust IMU slightly less (vibration)
      loopClosureStrictness: 0.5,    // loose — outdoor scale is forgiving
    ),
    EnvironmentType.unknown: VioParams(), // defaults
  };

  // ── Control ────────────────────────────────────────────────────────────────

  /// Start classifying every 2 seconds. Safe to call multiple times.
  void startClassifying() {
    if (_timer != null) return;
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _classify());
    _classify(); // immediate first classification
    debugPrint('[Classifier] Started');
  }

  /// Stop classifying and cancel timer.
  void stopClassifying() {
    _timer?.cancel();
    _timer = null;
    debugPrint('[Classifier] Stopped');
  }

  // ── Classification logic ──────────────────────────────────────────────────

  void _classify() {
    final pose = vioService.currentPose;
    final features = pose.trackedFeatures;
    final confidence = pose.confidence;

    final EnvironmentType env;

    if (features < 5) {
      // Very few features — likely featureless room or occlusion
      env = EnvironmentType.whiteRoom;
    } else if (features < 15) {
      // Some features but sparse — likely corridor or hallway
      env = EnvironmentType.corridor;
    } else if (confidence > 0.8) {
      // Many features, high confidence — well-textured room
      env = EnvironmentType.texturedRoom;
    } else {
      // Many features but lower confidence — outdoor or large space
      env = EnvironmentType.outdoor;
    }

    // Only notify if environment changed — avoids unnecessary rebuilds
    if (env != _environment) {
      _environment = env;
      _params = _presets[env] ?? const VioParams();
      debugPrint('[Classifier] Environment: ${env.label} | $_params');
      notifyListeners();
    }
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  @override
  void dispose() {
    stopClassifying();
    super.dispose();
  }
}
