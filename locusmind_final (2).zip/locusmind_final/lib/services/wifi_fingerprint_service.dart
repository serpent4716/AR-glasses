// lib/services/wifi_fingerprint_service.dart
// Implements spec step 5: Phone-Side Wi-Fi Fingerprinting
//
// Scans visible Wi-Fi APs every 1 second, records RSSI values per SSID,
// and exposes a Jaccard-similarity comparison for loop closure validation.
// Used by PhoneVioService.checkLoopClosure() and stored in Note.wifiFingerprint.

import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:wifi_scan/wifi_scan.dart';

class WiFiFingerprintService extends ChangeNotifier {
  // ── Singleton ──────────────────────────────────────────────────────────────
  static final WiFiFingerprintService _instance = WiFiFingerprintService._();
  factory WiFiFingerprintService() => _instance;
  WiFiFingerprintService._();

  // ── State ──────────────────────────────────────────────────────────────────
  Map<String, int> _current = {};   // ssid → rssiDbm
  Timer? _timer;
  bool _scanning = false;
  String? _lastError;

  // ── Getters ────────────────────────────────────────────────────────────────
  /// Current fingerprint as an unmodifiable map of {ssid: rssiDbm}.
  Map<String, int> get currentFingerprint => Map.unmodifiable(_current);

  /// Current fingerprint serialised to JSON — store this in Note.wifiFingerprint.
  String get currentFingerprintJson => jsonEncode(_current);

  bool get isScanning => _scanning;
  String? get lastError => _lastError;

  // ── Control ────────────────────────────────────────────────────────────────

  /// Start periodic Wi-Fi scanning (every 1 second).
  /// Safe to call multiple times — no-op if already scanning.
  void startScanning() {
    if (_scanning) return;
    _scanning = true;
    _lastError = null;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _scan());
    _scan(); // immediate first scan
    debugPrint('[WiFi] Fingerprint scanning started');
  }

  /// Stop periodic scanning and cancel timer.
  void stopScanning() {
    if (!_scanning) return;
    _scanning = false;
    _timer?.cancel();
    _timer = null;
    debugPrint('[WiFi] Fingerprint scanning stopped');
  }

  // ── Internal scan ──────────────────────────────────────────────────────────

  Future<void> _scan() async {
    try {
      // Check permission / capability
      final canStart = await WiFiScan.instance.canStartScan(
        askPermissions: true,
      );
      if (canStart != CanStartScan.yes) {
        _lastError = 'Cannot start scan: $canStart';
        debugPrint('[WiFi] $_lastError');
        return;
      }

      // Trigger scan
      await WiFiScan.instance.startScan();

      // Read results (returns cached results if scan not finished yet)
      final results = await WiFiScan.instance.getScannedResults();

      // Build ssid → rssi map; keep strongest signal if SSID appears twice
      final updated = <String, int>{};
      for (final ap in results) {
        final ssid = ap.ssid.trim();
        if (ssid.isEmpty) continue; // skip hidden networks
        final existing = updated[ssid];
        if (existing == null || ap.level > existing) {
          updated[ssid] = ap.level; // level is rssiDbm (negative integer)
        }
      }

      _current = updated;
      _lastError = null;
      notifyListeners();

    } catch (e) {
      _lastError = 'Scan error: $e';
      debugPrint('[WiFi] $_lastError');
    }
  }

  // ── Comparison ─────────────────────────────────────────────────────────────

  /// Jaccard similarity between current fingerprint and a saved JSON fingerprint.
  ///
  /// Returns 0.0–1.0:
  ///   1.0 = identical SSID sets
  ///   0.0 = no SSIDs in common
  ///
  /// Only compares SSID presence (set membership), not RSSI values,
  /// because RSSI varies too much with device orientation and multipath.
  /// Threshold for loop closure acceptance: > 0.5 (per spec step 9).
  double compareFingerprint(String? savedJson) {
    if (savedJson == null || savedJson.isEmpty) return 0.0;
    if (_current.isEmpty) return 0.0;

    try {
      final raw = jsonDecode(savedJson);
      if (raw is! Map) return 0.0;

      final savedKeys = raw.keys.cast<String>().toSet();
      final currentKeys = _current.keys.toSet();

      final intersectionSize = currentKeys.intersection(savedKeys).length;
      final unionSize = currentKeys.union(savedKeys).length;

      if (unionSize == 0) return 0.0;
      return intersectionSize / unionSize;

    } catch (e) {
      debugPrint('[WiFi] compareFingerprint parse error: $e');
      return 0.0;
    }
  }

  /// Convenience: returns true if similarity exceeds the loop closure threshold.
  bool matchesFingerprint(String? savedJson, {double threshold = 0.5}) {
    return compareFingerprint(savedJson) >= threshold;
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  @override
  void dispose() {
    stopScanning();
    super.dispose();
  }
}
