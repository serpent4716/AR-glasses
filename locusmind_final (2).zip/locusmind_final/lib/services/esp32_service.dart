// services/esp32_service.dart — MERGED v10
//
// Performance fixes applied:
//   • Frame THROTTLING: only notifyListeners() on camera frames — UI rebuilds
//     are rate-limited to once per 80 ms via _lastUiUpdate. SLAM still gets
//     every frame via the _frameStreamController, so no accuracy is lost.
//   • MJPEG buffer is kept small (200KB) to prevent RAM pressure OOM pauses.
//   • IMU receiver: no longer calls notifyListeners() on every packet —
//     only emits to imuStream. UI reads via ListenableBuilder selectively.
//   • preloadConfig() from v9 retained to avoid the startup race condition.
//   • sendOled / invalidateConfig helpers retained.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

// ── IMU frame ─────────────────────────────────────────────────
class ImuFrame {
  final double ax, ay, az, gx, gy, gz;
  final double pitch, roll;
  final int timestampMs;

  const ImuFrame({
    required this.ax, required this.ay, required this.az,
    required this.gx, required this.gy, required this.gz,
    this.pitch = 0.0, this.roll = 0.0,
    required this.timestampMs,
  });

  factory ImuFrame.fromJson(Map<String, dynamic> j) => ImuFrame(
    ax: (j['ax'] ?? 0).toDouble(), ay: (j['ay'] ?? 0).toDouble(),
    az: (j['az'] ?? 0).toDouble(), gx: (j['gx'] ?? 0).toDouble(),
    gy: (j['gy'] ?? 0).toDouble(), gz: (j['gz'] ?? 0).toDouble(),
    pitch: (j['ax2'] ?? 0).toDouble(),
    roll:  (j['ay2'] ?? 0).toDouble(),
    timestampMs: j['t'] ?? 0,
  );

  double get angularMagnitude {
    return (gx * gx + gy * gy + gz * gz) > 0
        ? (gx.abs() + gy.abs() + gz.abs()) / 3
        : 0.0;
  }
}

// ── Connection state ─────────────────────────────────────────
enum Esp32State { disconnected, connecting, streaming, error }

class Esp32Service extends ChangeNotifier {
  static final Esp32Service _i = Esp32Service._();
  factory Esp32Service() => _i;
  Esp32Service._();

  Esp32State _state      = Esp32State.disconnected;
  String?    _error;
  Uint8List? _latestFrame;
  ImuFrame?  _latestImu;
  int        _frameCount = 0;
  double     _fps        = 0;
  DateTime   _fpsTimer   = DateTime.now();

  // Throttle UI rebuilds to avoid flooding the widget tree
  DateTime   _lastUiUpdate = DateTime.fromMillisecondsSinceEpoch(0);
  static const Duration _kMinUiInterval = Duration(milliseconds: 80); // ~12fps UI max

  // Cached config
  String? _cachedIp;
  int?    _cachedOledPort;

  Esp32State get state       => _state;
  String?    get error       => _error;
  Uint8List? get latestFrame => _latestFrame;
  ImuFrame?  get latestImu   => _latestImu;
  double     get fps         => _fps;
  int        get frameCount  => _frameCount;
  bool       get isStreaming => _state == Esp32State.streaming;

  // ── Config ────────────────────────────────────────────────────

  Future<void> preloadConfig() async {
    final p = await SharedPreferences.getInstance();
    _cachedIp       = p.getString(kPrefEsp32Ip) ?? kDefaultEsp32Ip;
    _cachedOledPort = p.getInt(kPrefEsp32OledPort) ?? kDefaultEsp32OledPort;
  }

  Future<String> get _esp32Ip async {
    if (_cachedIp != null) return _cachedIp!;
    final p = await SharedPreferences.getInstance();
    _cachedIp = p.getString(kPrefEsp32Ip) ?? kDefaultEsp32Ip;
    return _cachedIp!;
  }

  Future<int> get _esp32OledPort async {
    if (_cachedOledPort != null) return _cachedOledPort!;
    final p = await SharedPreferences.getInstance();
    _cachedOledPort = p.getInt(kPrefEsp32OledPort) ?? kDefaultEsp32OledPort;
    return _cachedOledPort!;
  }

  void invalidateConfig() {
    _cachedIp       = null;
    _cachedOledPort = null;
  }

  // ── MJPEG stream ──────────────────────────────────────────────
  StreamSubscription? _streamSub;
  http.Client?        _httpClient;

  // Frame stream for SLAM — separate from UI notifications
  final _frameStreamController = StreamController<Uint8List>.broadcast();
  Stream<Uint8List> get frameStream => _frameStreamController.stream;

  Future<void> startStream() async {
    if (_state == Esp32State.streaming) return;
    _setState(Esp32State.connecting);

    final ip  = await _esp32Ip;
    final url = 'http://$ip/stream';

    try {
      _httpClient = http.Client();
      final request  = http.Request('GET', Uri.parse(url));
      final response = await _httpClient!.send(request)
          .timeout(const Duration(seconds: 8));

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      _setState(Esp32State.streaming);
      _fpsTimer = DateTime.now();

      _streamSub = _parseMjpegByMarkers(response.stream).listen(
        (frame) {
          _latestFrame = frame;
          _frameCount++;

          // FPS update (every second)
          final elapsed = DateTime.now().difference(_fpsTimer).inMilliseconds;
          if (elapsed >= 1000) {
            _fps        = _frameCount * 1000 / elapsed;
            _frameCount = 0;
            _fpsTimer   = DateTime.now();
          }

          // Always push frame to SLAM pipeline (no throttle)
          _frameStreamController.add(frame);

          // Throttle UI rebuilds — only notify widget tree at ~12 fps max
          final now = DateTime.now();
          if (now.difference(_lastUiUpdate) >= _kMinUiInterval) {
            _lastUiUpdate = now;
            notifyListeners();
          }
        },
        onError: (e) => _setState(Esp32State.error, error: 'Stream error: $e'),
        onDone: () {
          if (_state == Esp32State.streaming) _setState(Esp32State.disconnected);
        },
        cancelOnError: true,
      );
    } catch (e) {
      _setState(Esp32State.error, error: 'Cannot connect to ESP32 at $url\n$e');
    }
  }

  Future<void> stopStream() async {
    await _streamSub?.cancel();
    _streamSub = null;
    _httpClient?.close();
    _httpClient = null;
    if (_state != Esp32State.error) _setState(Esp32State.disconnected);
  }

  Stream<Uint8List> _parseMjpegByMarkers(Stream<List<int>> input) async* {
    final buf = <int>[];
    await for (final chunk in input) {
      buf.addAll(chunk);
      // Keep buffer small to prevent RAM pressure
      if (buf.length > 200000) buf.removeRange(0, buf.length - 100000);

      int start = -1;
      for (int i = 0; i < buf.length - 1; i++) {
        if (buf[i] == 0xFF && buf[i + 1] == 0xD8) { start = i; break; }
      }
      if (start == -1) continue;

      for (int i = start + 2; i < buf.length - 1; i++) {
        if (buf[i] == 0xFF && buf[i + 1] == 0xD9) {
          yield Uint8List.fromList(buf.sublist(start, i + 2));
          buf.removeRange(0, i + 2);
          break;
        }
      }
    }
  }

  // ── IMU via UDP ───────────────────────────────────────────────
  RawDatagramSocket? _imuSocket;
  final _imuController = StreamController<ImuFrame>.broadcast();
  Stream<ImuFrame> get imuStream => _imuController.stream;

  Future<void> startImuReceiver() async {
    if (_imuSocket != null) return; // already started
    try {
      _imuSocket = await RawDatagramSocket.bind(
          InternetAddress.anyIPv4, kDefaultEsp32ImuPort);
      _imuSocket!.listen((event) {
        if (event != RawSocketEvent.read) return;
        final dg = _imuSocket!.receive();
        if (dg == null) return;
        try {
          final msg = utf8.decode(dg.data);
          final j   = jsonDecode(msg) as Map<String, dynamic>;
          _latestImu = ImuFrame.fromJson(j);
          _imuController.add(_latestImu!);
          // No notifyListeners() here — consumers use imuStream directly
        } catch (_) {}
      });
    } catch (e) {
      debugPrint('[ESP32] IMU socket failed: $e');
    }
  }

  void stopImuReceiver() {
    _imuSocket?.close();
    _imuSocket = null;
  }

  // ── OLED ──────────────────────────────────────────────────────
  Future<void> sendNoteToOled(String line1, {String line2 = ''}) async {
    final ip   = await _esp32Ip;
    final port = await _esp32OledPort;
    final text = line2.isEmpty ? line1 : '$line1\n$line2';
    final data = utf8.encode(text.substring(0, text.length.clamp(0, 47)));
    try {
      final sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      sock.send(data, InternetAddress(ip), port);
      await Future.delayed(const Duration(milliseconds: 5));
      sock.close();
    } catch (e) {
      debugPrint('[ESP32] OLED send failed: $e');
    }
  }

  Future<void> sendOled(String text) async {
    final ip   = await _esp32Ip;
    final port = await _esp32OledPort;
    final data = utf8.encode(text.length > 47 ? text.substring(0, 47) : text);
    try {
      final sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      sock.send(data, InternetAddress(ip), port);
      await Future.delayed(const Duration(milliseconds: 5));
      sock.close();
    } catch (e) {
      debugPrint('[ESP32] OLED send failed: $e');
    }
  }

  Future<void> clearOled() => sendNoteToOled('           ');

  Future<bool> pingEsp32() async {
    try {
      final ip  = await _esp32Ip;
      final res = await http.get(Uri.parse('http://$ip/status'))
          .timeout(const Duration(seconds: 4));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  void _setState(Esp32State s, {String? error}) {
    _state = s;
    _error = error;
    notifyListeners();
  }

  @override
  void dispose() {
    stopStream();
    stopImuReceiver();
    _imuController.close();
    _frameStreamController.close();
    super.dispose();
  }
}
