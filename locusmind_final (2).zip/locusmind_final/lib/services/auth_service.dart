// services/auth_service.dart
// Local authentication + server URL persistence via SharedPreferences.
// No backend needed — credentials validated against hardcoded demo values.

import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  // ── Auth ──────────────────────────────────────────────────────────

  Future<bool> isLoggedIn() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(kPrefIsLoggedIn) ?? false;
  }

  Future<String?> getUsername() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(kPrefUsername);
  }

  /// Validates credentials. Demo: admin / locusmind.
  Future<bool> login(String username, String password) async {
    if (username.trim() == kDemoUsername && password == kDemoPassword) {
      final p = await SharedPreferences.getInstance();
      await p.setBool(kPrefIsLoggedIn, true);
      await p.setString(kPrefUsername, username.trim());
      return true;
    }
    return false;
  }

  Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(kPrefIsLoggedIn);
    await p.remove(kPrefUsername);
  }

  // ── Server URLs ───────────────────────────────────────────────────

  /// Returns both stored URLs as a map with keys 'pi' and 'pc'.
  Future<Map<String, String>> getServerUrls() async {
    final p = await SharedPreferences.getInstance();
    return {
      'pi': p.getString(kPrefApiBaseUrl) ?? kDefaultPiBaseUrl,
      'pc': p.getString(kPrefPcSlamUrl)  ?? kDefaultPcSlamUrl,
    };
  }

  /// Persists the Raspberry Pi base URL (used by ApiService for /api/* calls).
  Future<void> setPiUrl(String url) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(kPrefApiBaseUrl, url);
  }

  /// Persists the PC SLAM server URL (used by ApiService for /health ping).
  Future<void> setPcSlamUrl(String url) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(kPrefPcSlamUrl, url);
  }

  // ── Theme ─────────────────────────────────────────────────────────

  Future<String> getThemeMode() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(kPrefThemeMode) ?? 'system';
  }

  Future<void> setThemeMode(String mode) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(kPrefThemeMode, mode);
  }
}
