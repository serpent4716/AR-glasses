// lib/services/esp32_ble_service.dart
// APPROACH 5: BLE 5.0 client for ESP32-S3 communication
// Replaces Wi-Fi MJPEG streaming with low-power BLE metadata
// Falls back to Wi-Fi for MJPEG burst on demand

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import 'phone_slam_vio_service.dart';

// ═════════════════════════════════════════════════════════════════════════════
//  SENSOR DATA FROM ESP32 (parsed from BLE JSON)
// ═════════════════════════════════════════════════════════════════════════════

class BleSensorPacket {
  final int timestampUs;
  final List<List<double>> imuBatch;     // [[ax,ay,az,gx,gy,gz], ...]
  final double? barometerHpa;
  final double? altitudeM;
  final List<int>? magnetometerRaw;       // [mx, my, mz]
  final double? headingDeg;
  final int featureCount;
  final String detectorMode;              // "shi_tomasi", "agast", "blackout"
  final Uint8List? briefDescriptor;       // 32 bytes for keyframe

  BleSensorPacket({
    required this.timestampUs,
    required this.imuBatch,
    this.barometerHpa,
    this.altitudeM,
    this.magnetometerRaw,
    this.headingDeg,
    this.featureCount = 0,
    this.detectorMode = "blackout",
    this.briefDescriptor,
  });

  factory BleSensorPacket.fromJson(Map<String, dynamic> json) {
    final imuList = (json['imu'] as List<dynamic>? ?? []).map((r) {
      final vals = r as List<dynamic>;
      return vals.map((v) => (v as num).toDouble()).toList();
    }).toList();

    final mag = json['mag'] as List<dynamic>?;
    final magnetometerRaw = mag?.map((v) => (v as num).toInt()).toList();

    return BleSensorPacket(
      timestampUs: json['t'] ?? 0,
      imuBatch: imuList,
      barometerHpa: json['baro']?.toDouble(),
      altitudeM: json['alt']?.toDouble(),
      magnetometerRaw: magnetometerRaw,
      headingDeg: json['head']?.toDouble(),
      featureCount: json['feat'] ?? 0,
      detectorMode: json['mode'] ?? 'blackout',
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
//  ESP32 BLE SERVICE
// ═════════════════════════════════════════════════════════════════════════════

enum BleConnectionState { disconnected, scanning, connecting, connected, error }

class Esp32BleService extends ChangeNotifier {
  final PhoneVioService vioService;
  Esp32BleService(this.vioService);

  BleConnectionState _state = BleConnectionState.disconnected;
  String? _error;
  BluetoothDevice? _device;
  BluetoothCharacteristic? _imuChar;
  BluetoothCharacteristic? _keyframeChar;
  BluetoothCharacteristic? _commandChar;
  StreamSubscription? _scanSub;
  StreamSubscription? _connSub;
  StreamSubscription? _imuNotifySub;
  StreamSubscription? _keyframeNotifySub;

  // Statistics
  int _packetsReceived = 0;
  double _packetRate = 0;  // Hz
  DateTime _lastPacketTime = DateTime.now();

  BleConnectionState get state => _state;
  String? get error => _error;
  bool get isConnected => _state == BleConnectionState.connected;
  bool get isScanning => _state == BleConnectionState.scanning;
  bool get isConnecting => _state == BleConnectionState.connecting;
  int get packetsReceived => _packetsReceived;
  double get packetRate => _packetRate;

  // ═─ Start BLE Scan ───────────────────────────────────────────────

  Future<void> startBleScan() async {
    if (_state == BleConnectionState.scanning || 
        _state == BleConnectionState.connected) return;

    _setState(BleConnectionState.scanning);
    _error = null;

    try {
      // Request Bluetooth permissions
      if (Platform.isAndroid) {
        await [
          Permission.location,
          Permission.bluetoothScan,
          Permission.bluetoothConnect,
        ].request();
      }

      // Check Bluetooth adapter state
      final adapterState = await FlutterBluePlus.adapterState.first;
      if (adapterState != BluetoothAdapterState.on) {
        _setState(BleConnectionState.error, error: 'Bluetooth is off');
        return;
      }

      // Listen for scan results
      _scanSub = FlutterBluePlus.scanResults.listen((results) async {
        for (final result in results) {
          final name = result.device.advName;
          if (name.isNotEmpty && 
              (name.contains("LocusMind") || name.contains("ESP32") || name.contains("VIO"))) {

            await FlutterBluePlus.stopScan();
            _device = result.device;
            await _connectToDevice();
            break;
          }
        }
      });

      // Start scanning
      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 15),
        withServices: [Guid(BLE_SERVICE_UUID)],
      );

    } catch (e) {
      _setState(BleConnectionState.error, error: 'Scan error: $e');
    }
  }

  // ═─ Connect to Device ──────────────────────────────────────────

  Future<void> _connectToDevice() async {
    if (_device == null) return;
    _setState(BleConnectionState.connecting);

    try {
      // Connect with timeout
      await _device!.connect(
        autoConnect: false,
        mtu: null,
      ).timeout(const Duration(seconds: 10));

      // Discover services
      final services = await _device!.discoverServices();

      for (final service in services) {
        if (service.uuid.toString().toLowerCase() == BLE_SERVICE_UUID.toLowerCase()) {
          for (final char in service.characteristics) {
            final uuid = char.uuid.toString().toLowerCase();

            if (uuid == BLE_IMU_CHAR_UUID.toLowerCase()) {
              _imuChar = char;
              await char.setNotifyValue(true);
              _imuNotifySub = char.lastValueStream.listen(_onImuData);
            } else if (uuid == BLE_KEYFRAME_CHAR_UUID.toLowerCase()) {
              _keyframeChar = char;
              await char.setNotifyValue(true);
              _keyframeNotifySub = char.lastValueStream.listen(_onKeyframeData);
            } else if (uuid == BLE_COMMAND_CHAR_UUID.toLowerCase()) {
              _commandChar = char;
            }
          }
        }
      }

      // Verify we have the required characteristic
      if (_imuChar == null) {
        throw Exception('IMU characteristic not found');
      }

      _setState(BleConnectionState.connected);
      debugPrint('[BLE] Connected to ${_device!.advName}');

      // Listen for disconnections
      _connSub = _device!.connectionState.listen((state) {
        if (state == BluetoothConnectionState.disconnected) {
          _handleDisconnect();
        }
      });

    } catch (e) {
      _setState(BleConnectionState.error, error: 'Connect failed: $e');
      await _cleanup();
    }
  }

  // ═─ Handle IMU Data ────────────────────────────────────────────

  void _onImuData(List<int> data) {
    try {
      final jsonStr = utf8.decode(data);
      final json = jsonDecode(jsonStr) as Map<String, dynamic>;
      final packet = BleSensorPacket.fromJson(json);

      _packetsReceived++;
      final now = DateTime.now();
      final dt = now.difference(_lastPacketTime).inMilliseconds;
      if (dt > 0) {
        _packetRate = 1000.0 / dt;
      }
      _lastPacketTime = now;

      // Forward to VIO backend
      final vio = vioService;

      // Process IMU batch
      if (packet.imuBatch.isNotEmpty) {
        vio.processImuBatch(packet.imuBatch, packet.timestampUs);
      }

      // Process barometer
      if (packet.barometerHpa != null && packet.altitudeM != null) {
        vio.processBarometer(packet.barometerHpa!, packet.altitudeM!, packet.timestampUs);
      }

      // Process magnetometer
      if (packet.magnetometerRaw != null && packet.headingDeg != null) {
        final magUt = packet.magnetometerRaw!.map((v) => v.toDouble()).toList();
        vio.processMagnetometer(magUt, packet.headingDeg!, packet.timestampUs);
      }

      // Process visual features if keyframe
      if (packet.featureCount > 0 && packet.detectorMode != 'blackout') {
        // TODO: Build VisualFeatureDart list from descriptor
        // For now, just update feature count in VIO
      }

      notifyListeners();

    } catch (e) {
      debugPrint('[BLE] Parse error: $e');
    }
  }

  // ═─ Handle Keyframe Data ─────────────────────────────────────

  void _onKeyframeData(List<int> data) {
    // Keyframe packet: [feature_count(1), descriptor(32), thumbnail_hash(1)]
    if (data.length < 34) return;

    final featureCount = data[0];
    final descriptor = Uint8List.fromList(data.sublist(1, 33));
    // final thumbnailHash = data[33];

    debugPrint('[BLE] Keyframe: $featureCount features');

    // Forward to VIO backend
    // vioService.processKeyframe(...);
  }

  // ═─ Send Command to ESP32 ───────────────────────────────────

  Future<void> sendCommand(String command) async {
    if (_commandChar == null || !isConnected) return;

    final data = utf8.encode(command);
    await _commandChar!.write(data, withoutResponse: true);
  }

  // ═─ Request Wi-Fi Burst ─────────────────────────────────────

  Future<void> requestWiFiBurst() async {
    await sendCommand('WIFI_BURST_ON');
  }

  Future<void> stopWiFiBurst() async {
    await sendCommand('WIFI_BURST_OFF');
  }

  // ═─ Disconnect ────────────────────────────────────────────────

  Future<void> disconnect() async {
    await _cleanup();
    _setState(BleConnectionState.disconnected);
  }

  Future<void> _cleanup() async {
    await _imuNotifySub?.cancel();
    await _keyframeNotifySub?.cancel();
    await _connSub?.cancel();
    await _scanSub?.cancel();

    if (_device != null) {
      try {
        await _device!.disconnect();
      } catch (_) {}
    }

    _imuChar = null;
    _keyframeChar = null;
    _commandChar = null;
    _device = null;
  }

  void _handleDisconnect() {
    _cleanup(); // fire-and-forget intentional — state update below is synchronous
    _setState(BleConnectionState.disconnected);
    debugPrint('[BLE] Disconnected');
  }

  // ═─ Helpers ──────────────────────────────────────────────────

  void _setState(BleConnectionState s, {String? error}) {
    _state = s;
    _error = error;
    notifyListeners();
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}
