// widgets/note_card.dart — v2
// Changes:
//   • Delete button added directly on the card (trash icon) — no more swipe-only
//   • Swipe-to-delete still works as a secondary gesture
//   • Distance shown in cm/m/km depending on value
//   • TTL expiry countdown shown if set
//   • "Pin camera view" hint replaces misleading "Pending" badge

import 'package:flutter/material.dart';
import '../models/note.dart';

class NoteCard extends StatelessWidget {
  final Note note;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onToggleVisible;

  const NoteCard({
    super.key,
    required this.note,
    required this.onEdit,
    required this.onDelete,
    required this.onToggleVisible,
  });

  @override
  Widget build(BuildContext context) {
    final theme     = Theme.of(context);
    final noteColor = note.flutterColor;

    return Dismissible(
      key: Key(note.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        decoration: BoxDecoration(
          color: Colors.red.shade400,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.delete_outline, color: Colors.white, size: 26),
            SizedBox(height: 2),
            Text('Delete', style: TextStyle(color: Colors.white, fontSize: 11)),
          ],
        ),
      ),
      confirmDismiss: (_) => _confirmDelete(context),
      onDismissed:    (_) => onDelete(),
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: InkWell(
          onTap: onEdit,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Color icon ──────────────────────────────────────
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: noteColor.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: noteColor.withOpacity(0.5), width: 1.5),
                  ),
                  child: Icon(Icons.sticky_note_2, color: noteColor, size: 22),
                ),
                const SizedBox(width: 12),

                // ── Content ─────────────────────────────────────────
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxHeight: 50),
                        child: SingleChildScrollView(
                          child: Text(
                            note.text.isEmpty ? '(empty note)' : note.text,
                            style: theme.textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6, runSpacing: 4,
                        children: [
                          // GPS distance chip
                          if (note.anchorLat != null)
                            _Chip(
                              icon: note.anchorFixed
                                  ? Icons.gps_fixed
                                  : Icons.gps_not_fixed,
                              label: _formatDistance(note.distanceM),
                              color: note.anchorFixed
                                  ? Colors.green.shade600
                                  : Colors.orange.shade700,
                            )
                          else
                            _Chip(
                              icon: Icons.gps_off,
                              label: 'No GPS anchor',
                              color: Colors.grey.shade500,
                            ),

                          // Visibility chip
                          _Chip(
                            icon: note.visible
                                ? Icons.visibility
                                : Icons.visibility_off,
                            label: note.visible ? 'Visible' : 'Hidden',
                            color: note.visible
                                ? theme.colorScheme.primary
                                : theme.colorScheme.onSurfaceVariant,
                          ),

                          // TTL expiry chip
                          if (note.expiryTime != null)
                            _Chip(
                              icon: Icons.timer_outlined,
                              label: _formatExpiry(note.expiryTime!),
                              color: Colors.deepOrange.shade400,
                            ),
                        ],
                      ),
                    ],
                  ),
                ),

                // ── Action buttons ──────────────────────────────────
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Edit
                    IconButton(
                      onPressed: onEdit,
                      icon: const Icon(Icons.edit_outlined, size: 19),
                      visualDensity: VisualDensity.compact,
                      tooltip: 'Edit',
                    ),
                    // Toggle visibility
                    IconButton(
                      onPressed: onToggleVisible,
                      icon: Icon(
                        note.visible
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        size: 19,
                      ),
                      visualDensity: VisualDensity.compact,
                      tooltip: note.visible ? 'Hide in AR' : 'Show in AR',
                    ),
                    // DELETE button — directly on card (no swipe required)
                    IconButton(
                      onPressed: () async {
                        final ok = await _confirmDelete(context);
                        if (ok) onDelete();
                      },
                      icon: const Icon(Icons.delete_outline, size: 19),
                      color: Colors.red.shade400,
                      visualDensity: VisualDensity.compact,
                      tooltip: 'Delete note',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Format distance: show cm < 1 m, m up to 999 m, km above that
  String _formatDistance(double meters) {
    if (meters < 0.01) return 'Here';
    if (meters < 1.0)  return '${(meters * 100).toStringAsFixed(0)} cm';
    if (meters < 1000) return '${meters.toStringAsFixed(0)} m';
    return '${(meters / 1000).toStringAsFixed(1)} km';
  }

  String _formatExpiry(DateTime expiry) {
    final diff = expiry.difference(DateTime.now());
    if (diff.isNegative) return 'Expired';
    if (diff.inDays > 0)    return 'Expires ${diff.inDays}d';
    if (diff.inHours > 0)   return 'Expires ${diff.inHours}h';
    if (diff.inMinutes > 0) return 'Expires ${diff.inMinutes}m';
    return 'Expires soon';
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delete Note?'),
            content: Text(
              'Delete "${note.text.substring(0, note.text.length.clamp(0, 40))}"?\n\n'
              'This cannot be undone.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Delete'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

class _Chip extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;
  const _Chip({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 3),
          Text(label,
              style: TextStyle(
                  fontSize: 11, color: color, fontWeight: FontWeight.w500)),
        ],
      );
}
