// widgets/sync_status_banner.dart — v2
// Shows ESP32 connection status only (no Pi/server sync).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/esp32_service.dart';

class SyncStatusBanner extends StatelessWidget {
  const SyncStatusBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<Esp32Service>(
      builder: (_, esp, __) {
        if (esp.state == Esp32State.disconnected) return const SizedBox.shrink();
        final isError = esp.state == Esp32State.error;
        final isConnecting = esp.state == Esp32State.connecting;
        final color = isError
            ? Colors.orange.shade100
            : isConnecting
                ? Colors.blue.shade50
                : Colors.green.shade50;
        final textColor = isError
            ? Colors.orange.shade900
            : isConnecting
                ? Colors.blue.shade900
                : Colors.green.shade900;
        final icon = isError
            ? Icons.wifi_off
            : isConnecting
                ? Icons.wifi_find
                : Icons.wifi;
        final msg = isError
            ? (esp.error ?? 'ESP32 unreachable — check Settings → IP address')
            : isConnecting
                ? 'Connecting to ESP32…'
                : 'ESP32 streaming  ${esp.fps.toStringAsFixed(0)} fps';

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: color,
          child: Row(children: [
            Icon(icon, size: 16, color: textColor),
            const SizedBox(width: 8),
            Expanded(child: Text(msg,
                style: TextStyle(fontSize: 12, color: textColor))),
          ]),
        );
      },
    );
  }
}
