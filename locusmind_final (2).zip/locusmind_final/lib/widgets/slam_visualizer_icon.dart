// widgets/slam_visualizer_icon.dart — v5 (VIO)
//
// ROOT CAUSE FIX (_dependents.isEmpty crash):
//   context.watch<PhoneVioService>() was called INSIDE AnimatedBuilder.builder.
//   AnimatedBuilder.builder runs on every animation tick, which is a build-phase
//   callback. Calling context.watch() there registers a new InheritedWidget
//   dependency mid-frame, corrupting Flutter's dependency tracking.
//
//   FIX: Both SlamStatusIcon and SlamVisualizerIcon now store VIO state
//   in local fields (tracked, conf, pose) that are updated via addListener
//   registered in didChangeDependencies — completely outside any build path.
//   AnimatedBuilder.builder only reads plain Dart fields, never context.watch.

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/phone_slam_vio_service.dart';

// ═══════════════════════════════════════════════════════════════
//  SlamStatusIcon  —  animated 3-D wireframe cube
//  Safe: reads SLAM state via addListener, never context.watch
// ═══════════════════════════════════════════════════════════════

class SlamStatusIcon extends StatefulWidget {
  final double size;
  const SlamStatusIcon({super.key, this.size = 32});

  @override
  State<SlamStatusIcon> createState() => _SlamStatusIconState();
}

class _SlamStatusIconState extends State<SlamStatusIcon>
    with TickerProviderStateMixin {
  late final AnimationController _spinCtrl;
  late final AnimationController _pulseCtrl;
  late final Animation<double>   _pulseAnim;

  // Local SLAM state — updated by listener, NOT by context.watch
  PhoneVioService? _slam;
  bool   _tracked = false;
  double _conf    = 0.0;

  void _onSlamChanged() {
    // Only update fields — never call setState inside listener during build
    _tracked = _slam!.currentPose.isTracking;
    _conf    = _slam!.currentPose.confidence;
    // No setState needed — AnimatedBuilder redraws on every tick already
  }

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2800))
      ..repeat();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.55, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Register listener once, safely outside any build/animation callback
    final newSlam = context.read<PhoneVioService>();
    if (_slam != newSlam) {
      _slam?.removeListener(_onSlamChanged);
      _slam = newSlam;
      _slam!.addListener(_onSlamChanged);
      // Sync current state immediately
      _tracked = _slam!.currentPose.isTracking;
      _conf    = _slam!.currentPose.confidence;
    }
  }

  @override
  void dispose() {
    _slam?.removeListener(_onSlamChanged);
    _spinCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // AnimatedBuilder reads only plain fields — NO context.watch here
    return AnimatedBuilder(
      animation: Listenable.merge([_spinCtrl, _pulseAnim]),
      builder: (_, __) => SizedBox(
        width:  widget.size,
        height: widget.size,
        child: CustomPaint(
          painter: _CubeIconPainter(
            angle:   _spinCtrl.value * 2 * pi,
            pulse:   _pulseAnim.value,
            tracked: _tracked,  // plain field, not context.watch
            conf:    _conf,     // plain field, not context.watch
          ),
        ),
      ),
    );
  }
}

class _CubeIconPainter extends CustomPainter {
  final double angle, pulse, conf;
  final bool   tracked;
  const _CubeIconPainter(
      {required this.angle, required this.pulse,
       required this.tracked, required this.conf});

  @override
  bool shouldRepaint(covariant _CubeIconPainter o) =>
      angle != o.angle || pulse != o.pulse ||
      tracked != o.tracked || conf != o.conf;

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width  / 2;
    final cy = size.height / 2;
    final r  = size.width  * 0.36;

    final Color col;
    if (tracked) {
      if (conf >= 0.75)      col = const Color(0xFF00FF88);
      else if (conf >= 0.45) col = const Color(0xFFFFB300);
      else                   col = const Color(0xFFFF3D00);
    } else {
      col = Color.lerp(const Color(0xFF4488FF), const Color(0xFF00CCFF),
          (sin(angle) * 0.5 + 0.5))!;
    }

    final opacity = tracked ? (0.5 + pulse * 0.5) : 0.75;
    final sw      = size.width * 0.055;

    const verts = [
      [-1.0, -1.0, -1.0], [ 1.0, -1.0, -1.0],
      [ 1.0,  1.0, -1.0], [-1.0,  1.0, -1.0],
      [-1.0, -1.0,  1.0], [ 1.0, -1.0,  1.0],
      [ 1.0,  1.0,  1.0], [-1.0,  1.0,  1.0],
    ];

    final ry = angle;
    final rx = angle * 0.38;
    final cosY = cos(ry), sinY = sin(ry);
    final cosX = cos(rx), sinX = sin(rx);

    Offset project(List<double> v) {
      final x1 =  v[0] * cosY + v[2] * sinY;
      final z1 = -v[0] * sinY + v[2] * cosY;
      final y2 =  v[1] * cosX - z1 * sinX;
      final z2 =  v[1] * sinX + z1 * cosX;
      final sc = 1.6 / (2.8 + z2 * 0.45);
      return Offset(cx + x1 * r * sc, cy + y2 * r * sc);
    }

    final pts = verts.map(project).toList();

    const edges = [
      [0,1],[1,2],[2,3],[3,0],
      [4,5],[5,6],[6,7],[7,4],
      [0,4],[1,5],[2,6],[3,7],
    ];

    for (final e in edges) {
      final isFront = e[0] >= 4 || e[1] >= 4;
      canvas.drawLine(
        pts[e[0]], pts[e[1]],
        Paint()
          ..color = col.withOpacity(opacity * (isFront ? 1.0 : 0.5))
          ..strokeWidth = sw * (isFront ? 1.0 : 0.6)
          ..strokeCap = StrokeCap.round,
      );
    }

    canvas.drawCircle(
      Offset(cx, cy),
      size.width * (tracked ? 0.07 * pulse : 0.045),
      Paint()..color = col.withOpacity(opacity),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  SlamVisualizerIcon  —  AR wireframe overlay
//  Safe: uses addListener (registered in didChangeDependencies)
//        AnimatedBuilder only reads plain fields
// ═══════════════════════════════════════════════════════════════

class SlamVisualizerIcon extends StatefulWidget {
  final double screenW, screenH;
  final double refW, refH;

  const SlamVisualizerIcon({
    super.key,
    required this.screenW,
    required this.screenH,
    this.refW = 320,
    this.refH = 240,
  });

  @override
  State<SlamVisualizerIcon> createState() => _SlamVisualizerIconState();
}

class _SlamVisualizerIconState extends State<SlamVisualizerIcon>
    with TickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final Animation<double>   _pulseAnim;
  late final AnimationController _fadeCtrl;
  late final Animation<double>   _fadeAnim;

  // Smoothed pose — updated by listener, never by context.watch in build
  double _smCx    = 160;
  double _smCy    = 120;
  double _smScale = 1.0;
  double _smRoll  = 0;
  double _smConf  = 0;
  bool   _tracked = false;
  int    _inliers = 0;

  static const double _kAlpha = 0.25;
  PhoneVioService? _slam;

  /// Extract yaw from VIO quaternion for roll display
  static double _extractYaw(double qw, double qx, double qy, double qz) {
    return atan2(2 * (qw * qz + qx * qy), 1 - 2 * (qy * qy + qz * qz)) * 180 / pi;
  }

  void _onSlamChanged() {
    final pose = _slam!.currentPose;
    if (pose.isTracking) {
      _smCx    = _lerp(_smCx,    pose.x * 100,    _kAlpha);
      _smCy    = _lerp(_smCy,    pose.y * 100,    _kAlpha);
      _smScale = _lerp(_smScale, 1.0,             _kAlpha);
      _smRoll  = _lerp(_smRoll,  _extractYaw(pose.qw, pose.qx, pose.qy, pose.qz), _kAlpha);
      _smConf  = _lerp(_smConf,  pose.confidence, _kAlpha);
      _tracked = true;
      _inliers = pose.trackedFeatures;
      if (_fadeCtrl.status != AnimationStatus.forward &&
          _fadeCtrl.status != AnimationStatus.completed) {
        _fadeCtrl.forward();
      }
    } else {
      _smConf  = _lerp(_smConf, 0, _kAlpha * 2);
      _tracked = false;
      _inliers = 0;
      if (_smConf < 0.05 &&
          _fadeCtrl.status != AnimationStatus.reverse &&
          _fadeCtrl.status != AnimationStatus.dismissed) {
        _fadeCtrl.reverse();
      }
    }
    // No setState — AnimatedBuilder redraws automatically
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.7, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeInOut);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final newSlam = context.read<PhoneVioService>();
    if (_slam != newSlam) {
      _slam?.removeListener(_onSlamChanged);
      _slam = newSlam;
      _slam!.addListener(_onSlamChanged);
      _tracked = _slam!.currentPose.isTracking;
      _inliers = _slam!.currentPose.trackedFeatures;
      _smConf  = _slam!.currentPose.confidence;
    }
  }

  @override
  void dispose() {
    _slam?.removeListener(_onSlamChanged);
    _pulseCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  static double _lerp(double a, double b, double t) => a + (b - a) * t;

  @override
  Widget build(BuildContext context) {
    // IgnorePointer so FABs underneath remain tappable (F4)
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: Listenable.merge([_pulseAnim, _fadeAnim]),
        builder: (_, __) {
          // Only plain fields here — NO context.watch, NO context.read
          final scaleX   = widget.screenW / widget.refW;
          final scaleY   = widget.screenH / widget.refH;
          final screenCx = _smCx * scaleX;
          final screenCy = _smCy * scaleY;
          final boxW     = widget.screenW * 0.25 * _smScale;
          final boxH     = widget.screenH * 0.30 * _smScale;
          final col      = _confColor(_smConf);

          return SizedBox(
            width:  widget.screenW,
            height: widget.screenH,
            child: CustomPaint(
              painter: _SlamPainter(
                cx:      screenCx,
                cy:      screenCy,
                boxW:    boxW,
                boxH:    boxH,
                rollDeg: _smRoll,
                color:   col,
                conf:    _smConf,
                pulse:   _pulseAnim.value,
                tracked: _tracked || _smConf > 0.1,
                inliers: _inliers,
              ),
            ),
          );
        },
      ),
    );
  }

  static Color _confColor(double conf) {
    if (conf >= 0.75) return const Color(0xFF00FF88);
    if (conf >= 0.45) {
      final t = (conf - 0.45) / 0.30;
      return Color.lerp(const Color(0xFFFF3D00), const Color(0xFFFFB300), t)!;
    }
    return const Color(0xFFFF3D00);
  }
}

// ─────────────────────────────────────────────────────────────
//  AR wireframe painter
// ─────────────────────────────────────────────────────────────

class _SlamPainter extends CustomPainter {
  final double cx, cy, boxW, boxH, rollDeg, conf, pulse;
  final Color  color;
  final bool   tracked;
  final int    inliers;

  static const double _kDepth   = 0.35;
  static const double _kAxisLen = 28;

  const _SlamPainter({
    required this.cx,     required this.cy,
    required this.boxW,   required this.boxH,
    required this.rollDeg, required this.color,
    required this.conf,   required this.pulse,
    required this.tracked, required this.inliers,
  });

  @override
  bool shouldRepaint(covariant _SlamPainter o) =>
      cx != o.cx || cy != o.cy || rollDeg != o.rollDeg ||
      conf != o.conf || pulse != o.pulse || tracked != o.tracked ||
      boxW != o.boxW || boxH != o.boxH || color != o.color;

  @override
  void paint(Canvas canvas, Size size) {
    if (!tracked && conf < 0.05) {
      _drawNoLockRing(canvas, size);
      return;
    }
    canvas.save();
    final opacity = (conf * 1.4).clamp(0.25, 1.0);
    _drawBoxShadow(canvas, opacity * 0.3);
    _drawWireframeBox(canvas, opacity);
    _drawAxes(canvas, opacity);
    _drawCornerBrackets(canvas, opacity);
    if (tracked) _drawHud(canvas);
    canvas.restore();
  }

  void _drawNoLockRing(Canvas canvas, Size size) {
    final rcx = size.width / 2, rcy = size.height / 2;
    final paint = Paint()
      ..color = const Color(0xAAFF3D00)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    const radius = 36.0, dashLen = 8.0, gapLen = 5.0;
    double angle = 0;
    bool   drawing = true;
    while (angle < 2 * pi) {
      final arcLen = drawing ? dashLen : gapLen;
      final sweep  = arcLen / radius;
      if (drawing) {
        canvas.drawArc(Rect.fromCircle(center: Offset(rcx, rcy), radius: radius),
            angle, sweep, false, paint);
      }
      angle += sweep;
      drawing = !drawing;
    }
    final xp = Paint()..color = const Color(0xAAFF3D00)..strokeWidth = 1.5;
    const r = 8.0;
    canvas.drawLine(Offset(rcx-r, rcy-r), Offset(rcx+r, rcy+r), xp);
    canvas.drawLine(Offset(rcx+r, rcy-r), Offset(rcx-r, rcy+r), xp);
  }

  void _drawWireframeBox(Canvas canvas, double opacity) {
    final p = Paint()
      ..color = color.withOpacity(0.85 * opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeJoin = StrokeJoin.round;
    final frontPts = _boxFace(1.0);
    final backPts  = _boxFace(1.0 - _kDepth);
    _drawQuad(canvas, frontPts, p);
    final bp = Paint()
      ..color = color.withOpacity(0.45 * opacity)
      ..style = PaintingStyle.stroke..strokeWidth = 1.0;
    _drawQuad(canvas, backPts, bp);
    for (int i = 0; i < 4; i++) canvas.drawLine(frontPts[i], backPts[i], bp);
  }

  List<Offset> _boxFace(double d) {
    final hw = boxW * 0.5 * d, hh = boxH * 0.5 * d;
    const offX = 10.0;
    final local = [Offset(-hw,-hh),Offset(hw,-hh),Offset(hw,hh),Offset(-hw,hh)];
    final angle = rollDeg * pi / 180;
    final cosA = cos(angle), sinA = sin(angle);
    final shift = (1.0 - d) * offX;
    return local.map((p) => Offset(
        cx + p.dx*cosA - p.dy*sinA + shift,
        cy + p.dx*sinA + p.dy*cosA + shift)).toList();
  }

  void _drawQuad(Canvas canvas, List<Offset> pts, Paint paint) {
    canvas.drawPath(
      Path()..moveTo(pts[0].dx,pts[0].dy)..lineTo(pts[1].dx,pts[1].dy)
            ..lineTo(pts[2].dx,pts[2].dy)..lineTo(pts[3].dx,pts[3].dy)..close(),
      paint);
  }

  void _drawBoxShadow(Canvas canvas, double opacity) {
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx+4, cy+boxH*0.55),
          width: boxW*0.8, height: boxH*0.15),
      Paint()..color = Colors.black.withOpacity(opacity)
             ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
  }

  void _drawAxes(Canvas canvas, double opacity) {
    final angle = rollDeg * pi / 180;
    final cosA = cos(angle), sinA = sin(angle);
    void drawAxis(Offset dir, Color ac) {
      final dx = dir.dx*cosA - dir.dy*sinA;
      final dy = dir.dx*sinA + dir.dy*cosA;
      final tip = Offset(cx + dx*_kAxisLen, cy + dy*_kAxisLen);
      final p = Paint()
        ..color = ac.withOpacity(0.9 * opacity)
        ..strokeWidth = 1.8..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(cx, cy), tip, p);
      final ha = atan2(dy, dx);
      canvas.drawLine(tip, Offset(tip.dx-6*cos(ha-0.4), tip.dy-6*sin(ha-0.4)), p);
      canvas.drawLine(tip, Offset(tip.dx-6*cos(ha+0.4), tip.dy-6*sin(ha+0.4)), p);
    }
    drawAxis(const Offset(1, 0),       const Color(0xFFFF4444));
    drawAxis(const Offset(0, -1),      const Color(0xFF44FF88));
    drawAxis(const Offset(0.55, 0.55), const Color(0xFF4488FF));
  }

  void _drawCornerBrackets(Canvas canvas, double opacity) {
    final hw = boxW * 0.5, hh = boxH * 0.5;
    final bLen = min(hw, hh) * 0.28 * pulse;
    if (bLen <= 0) return;
    final paint = Paint()
      ..color = color.withOpacity(opacity)..strokeWidth = 2.0
      ..style = PaintingStyle.stroke..strokeCap = StrokeCap.square;
    final angle = rollDeg * pi / 180;
    final cosA = cos(angle), sinA = sin(angle);
    Offset rot(double lx, double ly) =>
        Offset(cx + lx*cosA - ly*sinA, cy + lx*sinA + ly*cosA);
    void bracket(double bx, double by, int sx, int sy) {
      final corner = rot(bx, by);
      final hx     = rot(bx + sx*bLen, by);
      final vy     = rot(bx, by + sy*bLen);
      final d = bLen * 0.12;
      final dxH = (hx - corner); final dxV = (vy - corner);
      canvas.drawLine(corner + dxH*(d/bLen), hx, paint);
      canvas.drawLine(corner + dxV*(d/bLen), vy, paint);
    }
    bracket(-hw,-hh, 1, 1); bracket(hw,-hh,-1, 1);
    bracket( hw, hh,-1,-1); bracket(-hw, hh, 1,-1);
  }

  void _drawHud(Canvas canvas) {
    final label = '$inliers/15 features';
    final tp = TextPainter(
      text: TextSpan(text: label, style: TextStyle(
          color: color.withOpacity(0.9), fontSize: 9,
          fontFamily: 'monospace', letterSpacing: 0.8)),
      textDirection: TextDirection.ltr)..layout();
    final bg = Rect.fromLTWH(cx - tp.width/2 - 4, cy + boxH*0.5 + 6,
        tp.width + 8, tp.height + 4);
    canvas.drawRRect(RRect.fromRectAndRadius(bg, const Radius.circular(3)),
        Paint()..color = Colors.black54);
    tp.paint(canvas, Offset(bg.left+4, bg.top+2));
  }
}
