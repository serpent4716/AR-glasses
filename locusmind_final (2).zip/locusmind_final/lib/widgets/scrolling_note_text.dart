// widgets/scrolling_note_text.dart
//
// Auto-scrolling marquee widget for note text in the camera view note row.
// Short text stays static. Long text scrolls left→right at a steady speed,
// pauses at each end, then reverses — exactly like an OLED ticker.

import 'package:flutter/material.dart';

class ScrollingNoteText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  final double pixelsPerSecond;  // scroll speed
  final Duration pauseAtEnds;    // how long to pause at each end

  const ScrollingNoteText({
    super.key,
    required this.text,
    this.style,
    this.pixelsPerSecond = 30,
    this.pauseAtEnds = const Duration(milliseconds: 1200),
  });

  @override
  State<ScrollingNoteText> createState() => _ScrollingNoteTextState();
}

class _ScrollingNoteTextState extends State<ScrollingNoteText>
    with SingleTickerProviderStateMixin {
  final ScrollController _ctrl = ScrollController();
  bool _scrolling = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startScroll());
  }

  @override
  void didUpdateWidget(covariant ScrollingNoteText old) {
    super.didUpdateWidget(old);
    if (old.text != widget.text) {
      _ctrl.jumpTo(0);
      _scrolling = false;
      WidgetsBinding.instance.addPostFrameCallback((_) => _startScroll());
    }
  }

  Future<void> _startScroll() async {
    if (!mounted || _scrolling) return;
    _scrolling = true;

    // Wait for layout to know the maxScrollExtent
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted) return;

    final max = _ctrl.position.maxScrollExtent;
    if (max <= 0) { _scrolling = false; return; } // text fits — no scroll needed

    while (mounted) {
      // Scroll to end
      final duration = Duration(
          milliseconds: (max / widget.pixelsPerSecond * 1000).round());
      await _ctrl.animateTo(max,
          duration: duration, curve: Curves.linear);
      if (!mounted) break;

      // Pause at end
      await Future.delayed(widget.pauseAtEnds);
      if (!mounted) break;

      // Scroll back
      await _ctrl.animateTo(0,
          duration: duration, curve: Curves.linear);
      if (!mounted) break;

      // Pause at start
      await Future.delayed(widget.pauseAtEnds);
    }
    _scrolling = false;
  }

  @override
  void dispose() {
    _scrolling = false;
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      controller: _ctrl,
      scrollDirection: Axis.horizontal,
      physics: const NeverScrollableScrollPhysics(), // animation-only, not manual
      child: Text(widget.text, style: widget.style, maxLines: 1),
    );
  }
}
