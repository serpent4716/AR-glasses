LocusMind icon assets placeholder.
