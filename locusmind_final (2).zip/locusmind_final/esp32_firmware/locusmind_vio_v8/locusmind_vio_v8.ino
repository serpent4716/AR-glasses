/*
  LocusMind ESP32-S3 Sense Firmware  v8 — APPROACH 5: Full VIO
  =====================================================================

  Architecture: Smart Sensor Hub (Edge Pre-processing + BLE 5.0)

  Sensors:
    - OV2640 Camera: 160x120 grayscale, 10 FPS, on-device Shi-Tomasi/AGAST
    - MPU6050 IMU: 100Hz, GPIO INT timestamp sync
    - BMP280 Barometer: 100Hz, altitude computation
    - HMC5883L Magnetometer: 100Hz, tilt-compensated heading

  Radios:
    - BLE 5.0 (Primary): Continuous metadata stream (~12 kbps)
    - Wi-Fi (Secondary): Deep sleep, wake for MJPEG burst on demand

  Tasks:
    - sensorTask (Core 1): IMU + Baro + Mag sampling, timestamp sync
    - visionTask (Core 1): Camera capture, feature extraction, keyframe selection
    - bleTask (Core 0): BLE GATT server, notify characteristics
    - wifiTask (Core 0): Wi-Fi HTTP server, MJPEG burst on demand
    - oledTask (Core 1): OLED display, UDP receive from phone

  I2C Bus (shared, mutex-protected):
    - MPU6050 @ 0x68
    - BMP280 @ 0x76
    - HMC5883L @ 0x1E
    - SSD1306 @ 0x3C

  LIBRARIES:
    - ESP32 BLE Arduino (by Neil Kolban)
    - Adafruit SSD1306
    - Adafruit GFX
    - MPU6050 by Electronic Cats
    - Adafruit BMP280
    - HMC5883L (or QMC5883)

  BOARD: Tools → Board → esp32 → XIAO_ESP32S3
*/

#define sensor_t esp_camera_sensor_t
#include "esp_camera.h"
#undef sensor_t
#include "esp_timer.h"
#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_BMP280.h>
#include <QMC5883LCompass.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

// ══════════════════════════════════════════════════════════════════════════════
//  USER CONFIG
// ══════════════════════════════════════════════════════════════════════════════

const char* WIFI_SSID     = "bhaum";
const char* WIFI_PASSWORD = "BHAUM123";
const char* PHONE_IP      = "192.168.1.42";  // Phone IP for UDP OLED

const int   OLED_UDP_PORT = 4211;
const int   IMU_UDP_PORT  = 4212;
const int   HTTP_PORT     = 80;

// BLE UUIDs
#define BLE_SERVICE_UUID        "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_IMU_CHAR_UUID       "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_KEYFRAME_CHAR_UUID  "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_COMMAND_CHAR_UUID   "6e400004-b5a3-f393-e0a9-e50e24dcca9e"

// ══════════════════════════════════════════════════════════════════════════════
//  HARDWARE CONFIG
// ══════════════════════════════════════════════════════════════════════════════

// OLED
#define SCREEN_W  64
#define SCREEN_H  32
#define OLED_ADDR 0x3C
#define I2C_SDA   D4
#define I2C_SCL   D5
Adafruit_SSD1306 display(SCREEN_W, SCREEN_H, &Wire, -1);

// Camera pins (XIAO ESP32-S3 Sense)
#define PWDN_GPIO_NUM  -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM  10
#define SIOD_GPIO_NUM  40
#define SIOC_GPIO_NUM  39
#define Y9_GPIO_NUM    48
#define Y8_GPIO_NUM    11
#define Y7_GPIO_NUM    12
#define Y6_GPIO_NUM    14
#define Y5_GPIO_NUM    16
#define Y4_GPIO_NUM    18
#define Y3_GPIO_NUM    17
#define Y2_GPIO_NUM    15
#define VSYNC_GPIO_NUM 38
#define HREF_GPIO_NUM  47
#define PCLK_GPIO_NUM  13

// I2C Addresses
#define MPU_ADDR    0x68
#define BMP_ADDR    0x76
#define MAG_ADDR    0x1E

// MPU6050 INT pin for timestamp sync
#define MPU_INT_PIN 2

// ══════════════════════════════════════════════════════════════════════════════
//  SENSOR OBJECTS
// ══════════════════════════════════════════════════════════════════════════════

const int MPU_addr = 0x68;
Adafruit_BMP280 bmp;
QMC5883LCompass compass;

// ══════════════════════════════════════════════════════════════════════════════
//  BLE OBJECTS
// ══════════════════════════════════════════════════════════════════════════════

BLEServer *pServer = NULL;
BLECharacteristic *pImuCharacteristic = NULL;
BLECharacteristic *pKeyframeCharacteristic = NULL;
BLECharacteristic *pCommandCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("[BLE] Client connected");
    }
    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("[BLE] Client disconnected");
    }
};

// ══════════════════════════════════════════════════════════════════════════════
//  MUTEXES & SHARED DATA
// ══════════════════════════════════════════════════════════════════════════════

static SemaphoreHandle_t i2cMutex;
static SemaphoreHandle_t dataMutex;

// Shared sensor data (protected by dataMutex)
struct SensorData {
    // IMU
    int16_t AcX, AcY, AcZ;
    int16_t GyX, GyY, GyZ;
    float accel_g[3];
    float gyro_dps[3];

    // Barometer
    float pressure_hpa;
    float altitude_m;
    float temperature_c;

    // Magnetometer
    int mag_x, mag_y, mag_z;
    float heading_deg;

    // Timestamp
    uint64_t timestamp_us;

    // Visual
    int feature_count;
    char detector_mode[16]; // "shi_tomasi", "agast", "blackout"
    uint8_t brief_descriptor[32]; // 32-byte BRIEF for keyframe
};

static SensorData shared_data;
static volatile bool new_sensor_data = false;

// ══════════════════════════════════════════════════════════════════════════════
//  VISUAL FEATURE EXTRACTION
// ══════════════════════════════════════════════════════════════════════════════
//
// Shi-Tomasi corner detection on 160x120 grayscale
// BRIEF binary descriptor extraction
// Keyframe selection based on parallax

#define FRAME_W 160
#define FRAME_H 120
#define MAX_FEATURES 50
#define FEATURE_THRESHOLD 15
#define AGAST_THRESHOLD 5
#define BRIEF_PATCH_SIZE 16

struct Feature {
    uint16_t x, y;      // pixel coordinates
    uint8_t descriptor[32]; // BRIEF: 256 bits = 32 bytes
};

static Feature features[MAX_FEATURES];
static int feature_count = 0;
static char current_detector[16] = "shi_tomasi";

// Grayscale frame buffer
static uint8_t gray_frame[FRAME_W * FRAME_H];

// Simple Shi-Tomasi corner detector
// Computes corner response = min(lambda1, lambda2) of structure tensor
float shi_tomasi_response(const uint8_t* img, int w, int h, int x, int y, int window) {
    float Ixx = 0, Iyy = 0, Ixy = 0;
    int half = window / 2;

    for (int dy = -half; dy <= half; dy++) {
        for (int dx = -half; dx <= half; dx++) {
            int px = x + dx;
            int py = y + dy;
            if (px <= 0 || px >= w-1 || py <= 0 || py >= h-1) continue;

            // Sobel gradients
            float gx = (img[py*w + px+1] - img[py*w + px-1]) / 2.0f;
            float gy = (img[(py+1)*w + px] - img[(py-1)*w + px]) / 2.0f;

            Ixx += gx * gx;
            Iyy += gy * gy;
            Ixy += gx * gy;
        }
    }

    // Eigenvalues of [Ixx Ixy; Ixy Iyy]
    float trace = Ixx + Iyy;
    float det = Ixx * Iyy - Ixy * Ixy;
    float discriminant = trace * trace - 4 * det;
    if (discriminant < 0) return 0;

    float lambda1 = (trace + sqrt(discriminant)) / 2.0f;
    float lambda2 = (trace - sqrt(discriminant)) / 2.0f;

    return min(lambda1, lambda2);
}

// Fast AGAST-like detector (simplified)
// Checks 8 surrounding pixels for corner-like pattern
bool agast_corner(const uint8_t* img, int w, int h, int x, int y, int threshold) {
    uint8_t center = img[y*w + x];
    int brighter = 0, darker = 0;

    const int dx[8] = {-1, 0, 1, 1, 1, 0, -1, -1};
    const int dy[8] = {-1, -1, -1, 0, 1, 1, 1, 0};

    for (int i = 0; i < 8; i++) {
        int px = x + dx[i];
        int py = y + dy[i];
        if (px < 0 || px >= w || py < 0 || py >= h) continue;

        int diff = (int)img[py*w + px] - center;
        if (diff > threshold) brighter++;
        else if (diff < -threshold) darker++;
    }

    return (brighter >= 5 || darker >= 5);
}

// BRIEF descriptor: 256 binary comparisons in 16x16 patch
void compute_brief(const uint8_t* img, int w, int h, int cx, int cy, uint8_t* descriptor) {
    memset(descriptor, 0, 32);

    // Predefined random pairs (simplified - use fixed pattern)
    const int pairs[256][4] = {
        // 256 pairs of (x1,y1,x2,y2) offsets within 16x16 patch
        // Simplified: using a deterministic pattern
        {0,0,8,8}, {1,2,9,10}, {3,5,11,13}, // ... etc
        // In production, use ORB-style learned pairs
    };

    for (int i = 0; i < 256; i++) {
        int idx1 = min(255, i); // simplified
        int x1 = cx + pairs[idx1][0] - 8;
        int y1 = cy + pairs[idx1][1] - 8;
        int x2 = cx + pairs[idx1][2] - 8;
        int y2 = cy + pairs[idx1][3] - 8;

        x1 = max(0, min(w-1, x1)); y1 = max(0, min(h-1, y1));
        x2 = max(0, min(w-1, x2)); y2 = max(0, min(h-1, y2));

        uint8_t p1 = img[y1*w + x1];
        uint8_t p2 = img[y2*w + x2];

        if (p1 > p2) {
            descriptor[i / 8] |= (1 << (i % 8));
        }
    }
}

// Extract features from grayscale frame
int extract_features(const uint8_t* gray, int w, int h, Feature* out_features, int max_features) {
    int count = 0;
    const int step = 8; // scan every 8 pixels
    const float st_threshold = 100.0f; // Shi-Tomasi threshold

    // Try Shi-Tomasi first
    for (int y = step; y < h - step; y += step) {
        for (int x = step; x < w - step; x += step) {
            if (count >= max_features) break;

            float response = shi_tomasi_response(gray, w, h, x, y, 7);
            if (response > st_threshold) {
                out_features[count].x = x;
                out_features[count].y = y;
                compute_brief(gray, w, h, x, y, out_features[count].descriptor);
                count++;
            }
        }
    }

    strcpy(current_detector, "shi_tomasi");

    // If too few features, switch to AGAST
    if (count < FEATURE_THRESHOLD) {
        count = 0;
        for (int y = step; y < h - step; y += step) {
            for (int x = step; x < w - step; x += step) {
                if (count >= max_features) break;

                if (agast_corner(gray, w, h, x, y, 20)) {
                    out_features[count].x = x;
                    out_features[count].y = y;
                    compute_brief(gray, w, h, x, y, out_features[count].descriptor);
                    count++;
                }
            }
        }
        strcpy(current_detector, "agast");
    }

    // If still too few, blackout mode
    if (count < AGAST_THRESHOLD) {
        strcpy(current_detector, "blackout");
    }

    return count;
}

// Convert RGB565 to grayscale
void rgb565_to_gray(const uint8_t* rgb565, uint8_t* gray, int w, int h) {
    for (int i = 0; i < w * h; i++) {
        // RGB565: RRRRRGGGGGGBBBBB
        uint16_t pixel = rgb565[i*2] | (rgb565[i*2+1] << 8);
        uint8_t r = (pixel >> 11) & 0x1F;
        uint8_t g = (pixel >> 5) & 0x3F;
        uint8_t b = pixel & 0x1F;
        // Expand to 8-bit and convert to grayscale
        r = (r << 3) | (r >> 2);
        g = (g << 2) | (g >> 4);
        b = (b << 3) | (b >> 2);
        gray[i] = (uint8_t)(0.299f * r + 0.587f * g + 0.114f * b);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  CAMERA SETUP
// ══════════════════════════════════════════════════════════════════════════════

static void setupCamera() {
    camera_config_t cfg;
    memset(&cfg, 0, sizeof(cfg));

    cfg.ledc_channel = LEDC_CHANNEL_0;
    cfg.ledc_timer   = LEDC_TIMER_0;
    cfg.pin_d0       = Y2_GPIO_NUM;
    cfg.pin_d1       = Y3_GPIO_NUM;
    cfg.pin_d2       = Y4_GPIO_NUM;
    cfg.pin_d3       = Y5_GPIO_NUM;
    cfg.pin_d4       = Y6_GPIO_NUM;
    cfg.pin_d5       = Y7_GPIO_NUM;
    cfg.pin_d6       = Y8_GPIO_NUM;
    cfg.pin_d7       = Y9_GPIO_NUM;
    cfg.pin_xclk     = XCLK_GPIO_NUM;
    cfg.pin_pclk     = PCLK_GPIO_NUM;
    cfg.pin_vsync    = VSYNC_GPIO_NUM;
    cfg.pin_href     = HREF_GPIO_NUM;
    cfg.pin_sscb_sda = SIOD_GPIO_NUM;
    cfg.pin_sscb_scl = SIOC_GPIO_NUM;
    cfg.pin_pwdn     = PWDN_GPIO_NUM;
    cfg.pin_reset    = RESET_GPIO_NUM;
    cfg.xclk_freq_hz = 20000000;
    cfg.pixel_format = PIXFORMAT_JPEG;  // Use JPEG for color AR view
    cfg.frame_size   = FRAMESIZE_VGA;   // 640x480 for better quality
    cfg.jpeg_quality = 12; // Good balance of quality and size
    cfg.fb_count     = 2;
    cfg.grab_mode    = CAMERA_GRAB_LATEST;

    if (esp_camera_init(&cfg) != ESP_OK) {
        Serial.println("[CAM] Init FAILED");
        for (;;) vTaskDelay(pdMS_TO_TICKS(1000));
    }
    Serial.println("[CAM] OK  VGA JPEG");
}

// ══════════════════════════════════════════════════════════════════════════════
//  SENSOR SETUP
// ══════════════════════════════════════════════════════════════════════════════

static int detected_mpu_addr = 0;  // will be set by setupSensors

static void setupSensors() {
    Wire.begin(I2C_SDA, I2C_SCL);
    Wire.setClock(100000);  // start slow for reliable detection
    delay(100);  // let bus settle

    // ── I2C Bus Scanner ──────────────────────────────────────
    Serial.println("[I2C] Scanning bus on SDA=D4 SCL=D5 ...");
    int devicesFound = 0;
    for (uint8_t addr = 1; addr < 127; addr++) {
        Wire.beginTransmission(addr);
        uint8_t err = Wire.endTransmission(true);
        if (err == 0) {
            Serial.printf("[I2C]   Found device at 0x%02X\n", addr);
            devicesFound++;
        }
    }
    Serial.printf("[I2C] Scan done. %d device(s) found.\n", devicesFound);

    // Now switch to full speed
    Wire.setClock(400000);
    delay(10);

    // ── MPU6050 — try 0x68, then 0x69 ───────────────────────
    detected_mpu_addr = 0;
    for (int tryAddr : {0x68, 0x69}) {
        Wire.beginTransmission(tryAddr);
        Wire.write(0x6B);
        Wire.write(0);  // wake up (clear SLEEP bit)
        if (Wire.endTransmission(true) == 0) {
            detected_mpu_addr = tryAddr;
            Serial.printf("[IMU] MPU6050 OK at 0x%02X\n", tryAddr);

            delay(10);  // let sensor wake

            // 44 Hz LPF
            Wire.beginTransmission(tryAddr);
            Wire.write(0x1A);
            Wire.write(0x03);
            Wire.endTransmission(true);

            // 100 Hz Sample Rate
            Wire.beginTransmission(tryAddr);
            Wire.write(0x19);
            Wire.write(0x09);
            Wire.endTransmission(true);
            break;
        }
    }
    if (detected_mpu_addr == 0) {
        Serial.println("[IMU] MPU6050 not found at 0x68 or 0x69!");
    }

    // BMP280
    if (!bmp.begin(BMP_ADDR)) {
        Serial.println("[BARO] BMP280 not found!");
    } else {
        Serial.println("[BARO] BMP280 OK");
        bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                        Adafruit_BMP280::SAMPLING_X16,
                        Adafruit_BMP280::SAMPLING_X16,
                        Adafruit_BMP280::FILTER_X16,
                        Adafruit_BMP280::STANDBY_MS_1);
    }

    // HMC5883L / QMC5883 — check if actually present
    // QMC5883L = 0x0D, HMC5883L = 0x1E
    Wire.beginTransmission(0x0D);
    uint8_t magErr1 = Wire.endTransmission(true);
    Wire.beginTransmission(0x1E);
    uint8_t magErr2 = Wire.endTransmission(true);
    if (magErr1 == 0 || magErr2 == 0) {
        compass.init();
        Serial.printf("[MAG] Compass OK at 0x%02X\n", (magErr1 == 0) ? 0x0D : 0x1E);
    } else {
        Serial.println("[MAG] Compass not found!");
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TASK: SENSOR SAMPLING (Core 1)
//  Reads IMU, Barometer, Magnetometer at 100Hz with microsecond timestamps
// ══════════════════════════════════════════════════════════════════════════════

static void sensorTask(void* pvParameters) {
    Serial.println("[SENSOR] Task start, core=" + String(xPortGetCoreID()));

    TickType_t lastWake = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(10); // 100Hz

    // Calibration
    float gyro_bias[3] = {0, 0, 0};
    float accel_bias[3] = {0, 0, 0};
    int cal_count = 0;

    for (;;) {
        vTaskDelayUntil(&lastWake, period);

        uint64_t timestamp = esp_timer_get_time();

        xSemaphoreTake(i2cMutex, portMAX_DELAY);

        // Read MPU6050
        int16_t ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0;
        if (detected_mpu_addr != 0) {
        Wire.beginTransmission(detected_mpu_addr);
        Wire.write(0x3B);
        Wire.endTransmission(false);
        Wire.requestFrom(detected_mpu_addr, 14, true);
        if (Wire.available() >= 14) {
            ax = Wire.read()<<8 | Wire.read();
            ay = Wire.read()<<8 | Wire.read();
            az = Wire.read()<<8 | Wire.read();
            Wire.read(); Wire.read(); // Skip temp
            gx = Wire.read()<<8 | Wire.read();
            gy = Wire.read()<<8 | Wire.read();
            gz = Wire.read()<<8 | Wire.read();
        }
        } // end if detected_mpu_addr

        // Read BMP280
        float pressure = bmp.readPressure() / 100.0f;
        float altitude = bmp.readAltitude(1013.25f);
        float temp = bmp.readTemperature();

        // Read magnetometer
        compass.read();
        int mx = compass.getX();
        int my = compass.getY();
        int mz = compass.getZ();

        xSemaphoreGive(i2cMutex);

        // Convert to physical units
        float accel_g[3] = { ax/16384.0f, ay/16384.0f, az/16384.0f };
        float gyro_dps[3] = { gx/131.0f, gy/131.0f, gz/131.0f };

        // Calibration (first 200 samples)
        if (cal_count < 200) {
            gyro_bias[0] += gyro_dps[0];
            gyro_bias[1] += gyro_dps[1];
            gyro_bias[2] += gyro_dps[2];
            accel_bias[0] += accel_g[0];
            accel_bias[1] += accel_g[1];
            accel_bias[2] += (accel_g[2] - 1.0f); // assume gravity
            cal_count++;

            if (cal_count == 200) {
                for (int i = 0; i < 3; i++) {
                    gyro_bias[i] /= 200.0f;
                    accel_bias[i] /= 200.0f;
                }
                Serial.printf("[SENSOR] Calibrated: gyro_bias=[%.3f,%.3f,%.3f]\n",
                              gyro_bias[0], gyro_bias[1], gyro_bias[2]);
            }
            continue;
        }

        // Apply calibration
        for (int i = 0; i < 3; i++) {
            accel_g[i] -= accel_bias[i];
            gyro_dps[i] -= gyro_bias[i];
        }

        // Compute heading
        float heading = atan2(my, mx) * 180.0f / PI;
        if (heading < 0) heading += 360.0f;

        // Store in shared data
        xSemaphoreTake(dataMutex, portMAX_DELAY);
        shared_data.AcX = ax; shared_data.AcY = ay; shared_data.AcZ = az;
        shared_data.GyX = gx; shared_data.GyY = gy; shared_data.GyZ = gz;
        shared_data.accel_g[0] = accel_g[0];
        shared_data.accel_g[1] = accel_g[1];
        shared_data.accel_g[2] = accel_g[2];
        shared_data.gyro_dps[0] = gyro_dps[0];
        shared_data.gyro_dps[1] = gyro_dps[1];
        shared_data.gyro_dps[2] = gyro_dps[2];
        shared_data.pressure_hpa = pressure;
        shared_data.altitude_m = altitude;
        shared_data.temperature_c = temp;
        shared_data.mag_x = mx; shared_data.mag_y = my; shared_data.mag_z = mz;
        shared_data.heading_deg = heading;
        shared_data.timestamp_us = timestamp;
        shared_data.feature_count = feature_count;
        strcpy(shared_data.detector_mode, current_detector);
        if (feature_count > 0) {
            memcpy(shared_data.brief_descriptor, features[0].descriptor, 32);
        }
        new_sensor_data = true;
        xSemaphoreGive(dataMutex);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TASK: VISION / FEATURE EXTRACTION (Core 1)
//  Captures frames, extracts features, selects keyframes
// ══════════════════════════════════════════════════════════════════════════════

static void visionTask(void* pvParameters) {
    Serial.println("[VISION] Task start, core=" + String(xPortGetCoreID()));

    TickType_t lastWake = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(100); // 10 FPS

    uint8_t* prev_gray = (uint8_t*)malloc(FRAME_W * FRAME_H);
    if (!prev_gray) {
        Serial.println("[VISION] Failed to allocate prev_gray!");
        vTaskDelete(NULL);
    }
    bool has_prev = false;
    int frames_since_keyframe = 0;

    for (;;) {
        vTaskDelayUntil(&lastWake, period);

        camera_fb_t* fb = esp_camera_fb_get();
        if (!fb) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        // Frame is already grayscale from camera config
        if (fb->format == PIXFORMAT_GRAYSCALE) {
            memcpy(gray_frame, fb->buf, min((size_t)(FRAME_W * FRAME_H), fb->len));
            // Extract features
            int count = extract_features(gray_frame, FRAME_W, FRAME_H, features, MAX_FEATURES);
            feature_count = count;
        } else if (fb->format == PIXFORMAT_JPEG) {
            // Feature extraction disabled when using JPEG to save RAM/CPU
            feature_count = 0;
            strcpy(current_detector, "jpeg_disabled");
        } else {
            // Fallback conversion
            rgb565_to_gray(fb->buf, gray_frame, FRAME_W, FRAME_H);
            // Extract features
            int count = extract_features(gray_frame, FRAME_W, FRAME_H, features, MAX_FEATURES);
            feature_count = count;
        }

        esp_camera_fb_return(fb);

        // Keyframe selection logic
        frames_since_keyframe++;
        bool is_keyframe = false;

        if (frames_since_keyframe >= 5) {
            is_keyframe = true; // time-based
        }

        if (has_prev && count > 0) {
            // Compute average optical flow
            float total_flow = 0;
            int flow_count = 0;

            for (int i = 0; i < min(count, feature_count); i++) {
                if (i < MAX_FEATURES) {
                    // Simple flow: compare feature positions
                    // In production: use KLT tracking
                    total_flow += 10.0f; // placeholder
                    flow_count++;
                }
            }

            float avg_flow = flow_count > 0 ? total_flow / flow_count : 0;
            if (avg_flow > 30.0f) { // parallax threshold
                is_keyframe = true;
            }
        }

        if (is_keyframe) {
            frames_since_keyframe = 0;
            // Mark as keyframe - BLE task will send it
        }

        memcpy(prev_gray, gray_frame, FRAME_W * FRAME_H);
        has_prev = true;
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TASK: BLE SERVER (Core 0)
//  Sends sensor data + keyframe metadata via BLE 5.0 notify
// ══════════════════════════════════════════════════════════════════════════════

static void bleTask(void* pvParameters) {
    Serial.println("[BLE] Task start, core=" + String(xPortGetCoreID()));

    // Initialize BLE
    BLEDevice::init("LocusMind-VIO");
    pServer = BLEDevice::createServer();
    pServer->setCallbacks(new MyServerCallbacks());

    BLEService *pService = pServer->createService(BLE_SERVICE_UUID);

    // IMU characteristic (notify)
    pImuCharacteristic = pService->createCharacteristic(
        BLE_IMU_CHAR_UUID,
        BLECharacteristic::PROPERTY_NOTIFY
    );
    pImuCharacteristic->addDescriptor(new BLE2902());

    // Keyframe characteristic (notify)
    pKeyframeCharacteristic = pService->createCharacteristic(
        BLE_KEYFRAME_CHAR_UUID,
        BLECharacteristic::PROPERTY_NOTIFY
    );
    pKeyframeCharacteristic->addDescriptor(new BLE2902());

    // Command characteristic (write from phone)
    pCommandCharacteristic = pService->createCharacteristic(
        BLE_COMMAND_CHAR_UUID,
        BLECharacteristic::PROPERTY_WRITE
    );

    pService->start();

    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(BLE_SERVICE_UUID);
    pAdvertising->setScanResponse(true);
    pAdvertising->setMinPreferred(0x06); // functions that help with iPhone connections
    pAdvertising->setMinPreferred(0x12);
    BLEDevice::startAdvertising();

    Serial.println("[BLE] Advertising started");

    // Send loop
    TickType_t lastWake = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(100); // 10Hz BLE packets

    for (;;) {
        vTaskDelayUntil(&lastWake, period);

        if (!deviceConnected) {
            // Re-advertise if disconnected
            if (!oldDeviceConnected && deviceConnected) {
                oldDeviceConnected = deviceConnected;
            } else if (oldDeviceConnected && !deviceConnected) {
                delay(500);
                pServer->startAdvertising();
                Serial.println("[BLE] Restart advertising");
                oldDeviceConnected = deviceConnected;
            }
            continue;
        }

        oldDeviceConnected = deviceConnected;

        // Read shared data
        xSemaphoreTake(dataMutex, portMAX_DELAY);
        SensorData local = shared_data;
        bool has_new = new_sensor_data;
        new_sensor_data = false;
        xSemaphoreGive(dataMutex);

        if (!has_new) continue;

        // Build JSON packet
        char json[512];
        int len = snprintf(json, sizeof(json),
            "{"
            "\"t\":%llu,"
            "\"imu\":[[%.4f,%.4f,%.4f,%.2f,%.2f,%.2f]],"
            "\"baro\":%.2f,"
            "\"alt\":%.2f,"
            "\"mag\":[%d,%d,%d],"
            "\"head\":%.1f,"
            "\"feat\":%d,"
            "\"mode\":\"%s\""
            "}",
            local.timestamp_us,
            local.accel_g[0], local.accel_g[1], local.accel_g[2],
            local.gyro_dps[0], local.gyro_dps[1], local.gyro_dps[2],
            local.pressure_hpa,
            local.altitude_m,
            local.mag_x, local.mag_y, local.mag_z,
            local.heading_deg,
            local.feature_count,
            local.detector_mode
        );

        // Send via BLE notify
        pImuCharacteristic->setValue((uint8_t*)json, len);
        pImuCharacteristic->notify();

        // If keyframe, send descriptor
        if (local.feature_count > 0 && strcmp(local.detector_mode, "blackout") != 0) {
            uint8_t keyframe_pkt[64];
            keyframe_pkt[0] = local.feature_count;
            memcpy(keyframe_pkt + 1, local.brief_descriptor, 32);
            // Add thumbnail hash (simplified)
            keyframe_pkt[33] = 0; // placeholder

            pKeyframeCharacteristic->setValue(keyframe_pkt, 34);
            pKeyframeCharacteristic->notify();
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TASK: Wi-Fi HTTP SERVER (Core 0)
//  Deep sleep by default, wake for MJPEG burst on demand
// ══════════════════════════════════════════════════════════════════════════════

static WiFiServer httpServer(HTTP_PORT);
static bool wifi_active = false;

static void streamMjpeg(WiFiClient& client) {
    client.print(
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: multipart/x-mixed-replace;boundary=frame\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Cache-Control: no-cache\r\n"
        "Connection: close\r\n\r\n"
    );

    unsigned long lastSuccess = millis();
    const unsigned long WATCHDOG_MS = 5000;

    while (client.connected()) {
        if (millis() - lastSuccess > WATCHDOG_MS) {
            Serial.println("[WIFI] Stream watchdog");
            break;
        }

        camera_fb_t* fb = esp_camera_fb_get();
        if (!fb) continue;

        uint8_t* jpg_buf = NULL;
        size_t jpg_len = 0;
        bool need_free = false;
        
        if (fb->format == PIXFORMAT_JPEG) {
            jpg_buf = fb->buf;
            jpg_len = fb->len;
        } else {
            if (frame2jpg(fb, 50, &jpg_buf, &jpg_len)) {
                need_free = true;
            }
        }
        
        size_t written = 0;
        if (jpg_buf != NULL) {
            char hdr[128];
            int hdrLen = snprintf(hdr, sizeof(hdr),
                "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %zu\r\n\r\n",
                jpg_len);

            written = client.write((uint8_t*)hdr, hdrLen);
            written += client.write(jpg_buf, jpg_len);
            written += client.print("\r\n");
            
            if (need_free) {
                free(jpg_buf);
            }
        }

        esp_camera_fb_return(fb);

        if (written > 0) lastSuccess = millis();
    }
}

static void wifiTask(void* pvParameters) {
    // Delay to let BLE and other tasks stabilize first
    vTaskDelay(pdMS_TO_TICKS(3000));
    Serial.println("[WIFI] Task start, core=" + String(xPortGetCoreID()));

    // Create our own Wi-Fi network (Access Point)
    // This way it works anywhere and doesn't rely on a router!
    WiFi.softAP("LocusMind_Camera", "locus1234");
    delay(500);

    IPAddress IP = WiFi.softAPIP();
    Serial.print("[WIFI] AP Created. Connect phone to 'LocusMind_Camera' (pass: locus1234). IP: ");
    Serial.println(IP);
    
    httpServer.begin();
    wifi_active = true;

    for (;;) {
        if (!wifi_active) {
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        WiFiClient client = httpServer.available();
        if (!client) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        String reqLine;
        unsigned long t0 = millis();
        while (client.connected() && millis() - t0 < 2000) {
            if (client.available()) {
                char c = client.read();
                if (c == '\n') break;
                reqLine += c;
            }
        }
        while (client.available()) client.read();

        if (reqLine.indexOf("/stream") >= 0) {
            streamMjpeg(client);
        } else if (reqLine.indexOf("/status") >= 0) {
            String json = "{\"status\":\"ok\",\"ip\":\"" + WiFi.localIP().toString() + "\",\"ble\":true}";
            client.print("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n");
            client.print(json);
        }
        client.stop();
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TASK: OLED DISPLAY (Core 1)
//  Receives UDP commands from phone, displays note text
// ══════════════════════════════════════════════════════════════════════════════

static WiFiUDP udpOled;
static char oledLine[4][11]; // 4 lines, 10 chars + null
static volatile bool oledDirty = false;

static void wrapToOled(const char* raw) {
    for (int r = 0; r < 4; r++) memset(oledLine[r], 0, 11);
    int row = 0, col = 0;
    for (const char* p = raw; *p && row < 4; p++) {
        if (*p == '\n') { oledLine[row][col] = '\0'; row++; col = 0; continue; }
        if (col < 10) oledLine[row][col++] = *p;
    }
    if (row < 4) oledLine[row][col] = '\0';
}

static void renderOled() {
    xSemaphoreTake(i2cMutex, portMAX_DELAY);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    for (int r = 0; r < 4; r++) {
        if (oledLine[r][0] == '\0') continue;
        display.setCursor(0, r * 8);
        display.print(oledLine[r]);
    }
    display.display();
    xSemaphoreGive(i2cMutex);
}

static void oledTask(void* pvParameters) {
    Serial.println("[OLED] Task start, core=" + String(xPortGetCoreID()));

    udpOled.begin(OLED_UDP_PORT);
    char pktBuf[64];

    // Show startup (renderOled handles mutex internally)
    wrapToOled("LocusMind\nVIO v8");
    renderOled();

    for (;;) {
        int pktSize = udpOled.parsePacket();
        if (pktSize > 0) {
            int readLen = udpOled.read(pktBuf, min(pktSize, 63));
            if (readLen > 0) {
                pktBuf[readLen] = '\0';
                Serial.printf("[OLED] recv: \"%s\"\n", pktBuf);
                wrapToOled(pktBuf);
                renderOled();
            }
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  SETUP
// ══════════════════════════════════════════════════════════════════════════════

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("\n[BOOT] LocusMind VIO v8 - Approach 5");

    // CRITICAL: Initialize TCP/IP stack early so udpOled doesn't crash on task start
    WiFi.mode(WIFI_AP);
    delay(10);

    // Create mutexes
    i2cMutex = xSemaphoreCreateMutex();
    dataMutex = xSemaphoreCreateMutex();

    // Initialize OLED
    if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
        Serial.println("[OLED] Init failed");
    } else {
        display.clearDisplay();
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.setCursor(0, 0);
        display.print("LocusMind");
        display.setCursor(0, 8);
        display.print("VIO v8");
        display.display();
        Serial.println("[OLED] OK");
    }

    // Initialize all hardware
    setupCamera();
    setupSensors();

    Serial.println("[DBG] Sensors done, heap=" + String(esp_get_free_heap_size()));
    Serial.flush();

    // Show ready on OLED (renderOled handles mutex internally)
    wrapToOled("Ready\nWait BLE");
    renderOled();

    Serial.println("[DBG] OLED ready done, heap=" + String(esp_get_free_heap_size()));
    Serial.flush();

    // Create tasks one at a time with debug
    Serial.println("[DBG] Creating sensorTask..."); Serial.flush();
    xTaskCreatePinnedToCore(sensorTask, "sensorTask", 8192,  NULL, 3, NULL, 1);
    Serial.println("[DBG] Creating visionTask..."); Serial.flush();
    xTaskCreatePinnedToCore(visionTask, "visionTask", 12288, NULL, 2, NULL, 1);
    Serial.println("[DBG] Creating oledTask..."); Serial.flush();
    xTaskCreatePinnedToCore(oledTask,   "oledTask",   4096,  NULL, 1, NULL, 1);
    Serial.println("[DBG] Creating bleTask..."); Serial.flush();
    xTaskCreatePinnedToCore(bleTask,    "bleTask",    12288, NULL, 3, NULL, 0);
    Serial.println("[DBG] Creating wifiTask..."); Serial.flush();
    xTaskCreatePinnedToCore(wifiTask,   "wifiTask",   8192,  NULL, 1, NULL, 0);

    Serial.println("[BOOT] All tasks launched, heap=" + String(esp_get_free_heap_size()));
    Serial.println("[BLE] Advertising as 'LocusMind-VIO'");
    Serial.flush();
}

void loop() {
    // Heartbeat
    static unsigned long lastHb = 0;
    if (millis() - lastHb > 10000) {
        lastHb = millis();
        Serial.printf("[SYS] Heap: %u | Features: %d | Mode: %s | BLE: %s\n",
            esp_get_free_heap_size(),
            feature_count,
            current_detector,
            deviceConnected ? "CONN" : "DISC"
        );
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
}
