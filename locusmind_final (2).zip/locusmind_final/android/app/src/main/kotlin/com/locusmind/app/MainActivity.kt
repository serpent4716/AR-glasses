package com.locusmind.app

// io.flutter.embedding.android.FlutterActivity is provided by the Flutter
// Gradle plugin at compile time via the flutter.jar / flutter_embedding_debug.jar
// AAR that the dev.flutter.flutter-gradle-plugin adds automatically.
// If your IDE shows "Unresolved reference: FlutterActivity", run:
//   flutter clean && flutter pub get
// then sync Gradle again — the IDE needs the generated .jar on its classpath.
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
