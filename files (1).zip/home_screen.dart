// lib/screens/home_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/note.dart';
import '../services/note_store.dart';
import '../services/gps_service.dart';
import '../services/speech_service.dart';
import '../services/server_service.dart';
import '../widgets/note_card.dart';
import '../config.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  List<Note> _notes = [];
  String _selectedColor = '#00FF8C';
  bool _isListening = false;
  String _interimText = '';
  bool _serverRunning = false;
  String? _serverIp;
  String _gpsStatus = 'GPS searching';
  bool _gpsFix = false;
  String _slamStatus = 'SLAM --';

  Timer? _pollTimer;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  static const _colors = [
    '#00FF8C', '#00C8FF', '#FFE24B',
    '#FF6B6B', '#C77DFF', '#FF9F43',
  ];

  // Available STT languages
  static const _langs = [
    ('English (India)', 'en_IN'),
    ('Hindi', 'hi_IN'),
    ('Bengali', 'bn_IN'),
    ('Tamil', 'ta_IN'),
    ('Telugu', 'te_IN'),
    ('Marathi', 'mr_IN'),
    ('Gujarati', 'gu_IN'),
  ];
  String _selectedLang = 'en_IN';

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween(begin: 0.6, end: 1.0).animate(_pulseCtrl);

    _init();
  }

  Future<void> _init() async {
    await SpeechService().init();
    await GpsService().start();
    GpsService().stream.listen(_onGps);
    await _loadNotes();
    await _startServer();
    _pollTimer = Timer.periodic(
        const Duration(milliseconds: 1500), (_) => _loadNotes());
  }

  Future<void> _loadNotes() async {
    final notes = await NoteStore().all();
    if (mounted) setState(() => _notes = notes);
  }

  Future<void> _startServer() async {
    await ServerService().start();
    setState(() {
      _serverRunning = ServerService().isRunning;
      _serverIp = ServerService().localIp;
    });
  }

  void _onGps(GpsState g) {
    if (!mounted) return;
    setState(() {
      _gpsFix = g.fix;
      _gpsStatus = g.fix
          ? 'GPS ${g.lat!.toStringAsFixed(5)}, ${g.lon!.toStringAsFixed(5)}'
              ' ±${g.accuracy.toStringAsFixed(0)}m'
          : 'GPS searching';
    });
  }

  // ── Note actions ──────────────────────────────────────────────
  Future<void> _sendNote() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty) {
      _showToast('Write something first');
      return;
    }
    final gps = GpsService().current;
    final note = Note(
      id: DateTime.now().millisecondsSinceEpoch.toRadixString(16),
      text: text,
      color: _selectedColor,
      createdAt: DateTime.now().millisecondsSinceEpoch / 1000,
      anchorLat: gps.lat,
      anchorLon: gps.lon,
      anchorFixed: gps.fix,
    );
    await NoteStore().insert(note);
    _textCtrl.clear();
    setState(() => _interimText = '');
    await _loadNotes();
    _showToast('Note pinned ✦');
    HapticFeedback.lightImpact();
  }

  Future<void> _toggleNote(Note note) async {
    note.visible = !note.visible;
    note.autoShown = false;
    await NoteStore().update(note);
    await _loadNotes();
  }

  Future<void> _deleteNote(Note note) async {
    await NoteStore().delete(note.id);
    await _loadNotes();
    _showToast('Note deleted');
  }

  // ── Voice input ───────────────────────────────────────────────
  Future<void> _toggleVoice() async {
    if (_isListening) {
      await SpeechService().stopListening();
      setState(() { _isListening = false; _interimText = ''; });
      return;
    }

    setState(() { _isListening = true; _interimText = ''; });
    HapticFeedback.mediumImpact();

    await SpeechService().startListening(
      localeId: _selectedLang,
      onInterim: (text) {
        if (mounted) setState(() => _interimText = text);
      },
      onFinal: (result) {
        if (!mounted) return;
        setState(() {
          _isListening = false;
          _interimText = '';
          _textCtrl.text = result.text;
        });
        if (result.wasTranslated) {
          _showToast('Translated from ${result.originalLang}');
        }
        // Auto-send after 400ms so user sees the text
        Future.delayed(const Duration(milliseconds: 400), _sendNote);
      },
    );
  }

  // ── UI helpers ────────────────────────────────────────────────
  void _showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        duration: const Duration(milliseconds: 2000),
        backgroundColor: const Color(0xFF111820),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFF00FF8C), width: 0.5)),
      ),
    );
  }

  Color _parseColor(String hex) {
    try {
      return Color(int.parse('FF${hex.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return const Color(0xFF00FF8C);
    }
  }

  // ── Build ─────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080B10),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildServerBanner(),
            Expanded(
              child: ListView(
                controller: _scrollCtrl,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  const SizedBox(height: 20),
                  _buildInputCard(),
                  const SizedBox(height: 20),
                  _buildNotesSection(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0x1F00FF8C), width: 1),
        ),
      ),
      child: Row(
        children: [
          // Logo
          Row(children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  color: const Color(0xFF00FF8C),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00FF8C)
                          .withOpacity(_pulseAnim.value * 0.4),
                      blurRadius: 6,
                      spreadRadius: 2,
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Text('LOCUSMIND',
                style: TextStyle(
                  color: Color(0xFF00FF8C),
                  fontFamily: 'monospace',
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ]),
          const Spacer(),
          // GPS badge
          _Badge(
            text: _gpsFix ? 'GPS ok' : 'GPS --',
            active: _gpsFix,
            activeColor: const Color(0xFF00FF8C),
          ),
          const SizedBox(width: 8),
          // 2D mode badge
          const _Badge(
            text: '2D MODE',
            active: false,
            activeColor: Color(0xFFFFE24B),
          ),
        ],
      ),
    );
  }

  Widget _buildServerBanner() {
    if (!_serverRunning) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      color: const Color(0xFF0D1117),
      child: Text(
        _serverIp != null
            ? 'Server: http://$_serverIp:5000  |  Set this in pi_server.py'
            : 'Server starting...',
        style: const TextStyle(
          color: Color(0xFF4A6A5A),
          fontSize: 10,
          fontFamily: 'monospace',
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildInputCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF111820),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0x1F00FF8C)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('NEW NOTE',
              style: TextStyle(
                color: Color(0xFF4A6A5A),
                fontSize: 10,
                fontFamily: 'monospace',
                letterSpacing: 2,
              )),
          const SizedBox(height: 10),

          // Text area — shows interim voice text with different style
          Stack(
            children: [
              TextField(
                controller: _textCtrl,
                style: const TextStyle(color: Color(0xFFD4E8D4), fontSize: 15),
                decoration: InputDecoration(
                  hintText: _isListening
                      ? 'Listening...'
                      : 'Type a note, or tap the mic...',
                  hintStyle: TextStyle(
                    color: _isListening
                        ? const Color(0xFF00FF8C).withOpacity(0.5)
                        : const Color(0xFF4A6A5A),
                  ),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.3),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                        color: const Color(0xFF00FF8C).withOpacity(0.15)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                        color: const Color(0xFF00FF8C).withOpacity(0.4)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                        color: const Color(0xFF00FF8C).withOpacity(0.15)),
                  ),
                  contentPadding: const EdgeInsets.all(12),
                ),
                maxLines: 3,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendNote(),
              ),
              // Interim voice text overlay
              if (_isListening && _interimText.isNotEmpty)
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(
                      _interimText,
                      style: const TextStyle(
                        color: Color(0xFF00FF8C),
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 12),

          // Color picker row
          Row(
            children: [
              const Text('Color ',
                  style: TextStyle(color: Color(0xFF4A6A5A), fontSize: 12)),
              ..._colors.map((c) => GestureDetector(
                    onTap: () => setState(() => _selectedColor = c),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      width: 22, height: 22,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: _parseColor(c),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _selectedColor == c
                              ? Colors.white
                              : Colors.transparent,
                          width: 2,
                        ),
                      ),
                    ),
                  )),
              const Spacer(),
              // Language picker
              GestureDetector(
                onTap: _showLangPicker,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: const Color(0xFF00C8FF).withOpacity(0.3)),
                  ),
                  child: Text(
                    _langs.firstWhere(
                      (l) => l.$2 == _selectedLang,
                      orElse: () => _langs.first,
                    ).$1.split(' ').first,
                    style: const TextStyle(
                      color: Color(0xFF00C8FF),
                      fontSize: 10,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Action buttons
          Row(children: [
            Expanded(
              child: _Button(
                label: _isListening ? 'STOP' : 'SPEAK',
                icon: _isListening ? Icons.stop : Icons.mic,
                recording: _isListening,
                color: const Color(0xFF00C8FF),
                onTap: _toggleVoice,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _Button(
                label: 'SEND',
                icon: Icons.send,
                color: const Color(0xFF00FF8C),
                filled: true,
                onTap: _sendNote,
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildNotesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('ACTIVE NOTES',
            style: TextStyle(
              color: Color(0xFF4A6A5A),
              fontSize: 10,
              fontFamily: 'monospace',
              letterSpacing: 2,
            )),
        const SizedBox(height: 10),
        if (_notes.isEmpty)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(40),
              child: Text(
                '[ ]\nNo notes yet.\nType or tap the mic.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF4A6A5A), fontSize: 14, height: 1.6),
              ),
            ),
          )
        else
          ..._notes.map((n) => NoteCard(
                note: n,
                onToggle: () => _toggleNote(n),
                onDelete: () => _deleteNote(n),
              )),
      ],
    );
  }

  void _showLangPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111820),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Select language',
                style: TextStyle(
                    color: Color(0xFFD4E8D4),
                    fontWeight: FontWeight.bold)),
          ),
          ..._langs.map((l) => ListTile(
                title: Text(l.$1,
                    style: const TextStyle(color: Color(0xFFD4E8D4))),
                trailing: _selectedLang == l.$2
                    ? const Icon(Icons.check, color: Color(0xFF00FF8C))
                    : null,
                onTap: () {
                  setState(() => _selectedLang = l.$2);
                  Navigator.pop(context);
                },
              )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pulseCtrl.dispose();
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    GpsService().stop();
    ServerService().stop();
    super.dispose();
  }
}

// ── Shared small widgets ───────────────────────────────────────
class _Badge extends StatelessWidget {
  final String text;
  final bool active;
  final Color activeColor;

  const _Badge({
    required this.text,
    required this.active,
    required this.activeColor,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? activeColor.withOpacity(0.5) : const Color(0xFF4A6A5A),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: active ? activeColor : const Color(0xFF4A6A5A),
            fontSize: 10,
            fontFamily: 'monospace',
          ),
        ),
      );
}

class _Button extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final bool filled;
  final bool recording;
  final VoidCallback onTap;

  const _Button({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
    this.filled = false,
    this.recording = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: filled ? color : (recording ? color.withOpacity(0.12) : Colors.transparent),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: recording ? const Color(0xFFFF4560).withOpacity(0.6) : color.withOpacity(0.4),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16,
                color: filled ? Colors.black : (recording ? const Color(0xFFFF4560) : color)),
            const SizedBox(width: 7),
            Text(
              recording ? 'STOP' : label,
              style: TextStyle(
                color: filled ? Colors.black : (recording ? const Color(0xFFFF4560) : color),
                fontSize: 12,
                fontFamily: 'monospace',
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
