// lib/widgets/note_card.dart
import 'package:flutter/material.dart';
import '../models/note.dart';

class NoteCard extends StatelessWidget {
  final Note note;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  const NoteCard({
    super.key,
    required this.note,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final color = _parseColor(note.color);
    final timeStr = _timeAgo(note.createdAt);

    return AnimatedOpacity(
      opacity: note.visible ? 1.0 : 0.4,
      duration: const Duration(milliseconds: 200),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF111820),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.15), width: 1),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Color bar
            Container(
              width: 3,
              height: 72,
              decoration: BoxDecoration(
                color: color,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Body
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      note.text,
                      style: const TextStyle(
                        color: Color(0xFFD4E8D4),
                        fontSize: 14,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '#${note.id} · $timeStr'
                      '${note.anchorFixed ? ' · GPS anchored' : ' · no GPS'}'
                      '${note.visible ? ' · ON' : ' · HIDDEN'}',
                      style: const TextStyle(
                        color: Color(0xFF4A6A5A),
                        fontSize: 10,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Actions
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: Row(
                children: [
                  _ActionBtn(
                    label: note.visible ? 'ON' : 'OFF',
                    active: note.visible,
                    color: color,
                    onTap: onToggle,
                  ),
                  const SizedBox(width: 6),
                  _ActionBtn(
                    label: 'X',
                    active: false,
                    color: const Color(0xFFFF4560),
                    onTap: onDelete,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _parseColor(String hex) {
    try {
      final h = hex.replaceAll('#', '');
      return Color(int.parse('FF$h', radix: 16));
    } catch (_) {
      return const Color(0xFF00FF8C);
    }
  }

  String _timeAgo(double ts) {
    final diff = DateTime.now().millisecondsSinceEpoch / 1000 - ts;
    if (diff < 60) return '${diff.toInt()}s ago';
    if (diff < 3600) return '${(diff / 60).toInt()}m ago';
    return '${(diff / 3600).toInt()}h ago';
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.label,
    required this.active,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: active ? color.withOpacity(0.4) : Colors.white.withOpacity(0.06),
          ),
          color: active ? color.withOpacity(0.08) : Colors.white.withOpacity(0.03),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: active ? color : const Color(0xFF4A6A5A),
              fontSize: 10,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
            ),
          ),
        ),
      ),
    );
  }
}
