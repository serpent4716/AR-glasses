// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/home_screen.dart';
import 'services/server_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait — AR glasses are always held the same way
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // Dark status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF080B10),
  ));

  await _requestPermissions();
  runApp(const LocusMindApp());
}

Future<void> _requestPermissions() async {
  await [
    Permission.microphone,
    Permission.location,
    Permission.locationWhenInUse,
    Permission.locationAlways, // needed for background GPS
  ].request();
}

class LocusMindApp extends StatelessWidget {
  const LocusMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LocusMind',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFF00FF8C),
          surface: const Color(0xFF111820),
          background: const Color(0xFF080B10),
        ),
        scaffoldBackgroundColor: const Color(0xFF080B10),
        fontFamily: 'sans-serif',
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: Color(0xFF111820),
          contentTextStyle: TextStyle(color: Color(0xFFD4E8D4)),
        ),
      ),
      home: const _AppLifecycle(child: HomeScreen()),
    );
  }
}

/// Keeps the HTTP server alive when app goes to background
class _AppLifecycle extends StatefulWidget {
  final Widget child;
  const _AppLifecycle({required this.child});

  @override
  State<_AppLifecycle> createState() => _AppLifecycleState();
}

class _AppLifecycleState extends State<_AppLifecycle>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // shelf HTTP server is a pure Dart isolate — it keeps running
    // in background as long as the process is alive.
    // On Android, this works until the OS kills the process.
    // For guaranteed background: use flutter_background_service (future).
    if (state == AppLifecycleState.paused) {
      // Server keeps running — no action needed for shelf
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
