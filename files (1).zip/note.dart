// lib/models/note.dart
import 'dart:convert';

class Note {
  final String id;
  String text;
  double x, y, w, h;
  String color;
  bool visible;
  bool autoShown;
  final double createdAt;
  double? anchorLat;
  double? anchorLon;
  bool anchorFixed;
  double distanceM;
  bool poseTracked;

  Note({
    required this.id,
    required this.text,
    this.x = 80,
    this.y = 80,
    this.w = 280,
    this.h = 110,
    this.color = '#00FF88',
    this.visible = true,
    this.autoShown = false,
    required this.createdAt,
    this.anchorLat,
    this.anchorLon,
    this.anchorFixed = false,
    this.distanceM = 0,
    this.poseTracked = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'text': text,
    'x': x, 'y': y, 'w': w, 'h': h,
    'color': color, 'visible': visible,
    'auto_shown': autoShown,
    'created_at': createdAt,
    'anchor_lat': anchorLat, 'anchor_lon': anchorLon,
    'anchor_fixed': anchorFixed,
    'distance_m': distanceM,
    'pose_tracked': poseTracked,
  };

  factory Note.fromJson(Map<String, dynamic> j) => Note(
    id: j['id'], text: j['text'],
    x: (j['x'] ?? 80).toDouble(),
    y: (j['y'] ?? 80).toDouble(),
    w: (j['w'] ?? 280).toDouble(),
    h: (j['h'] ?? 110).toDouble(),
    color: j['color'] ?? '#00FF88',
    visible: j['visible'] ?? true,
    autoShown: j['auto_shown'] ?? false,
    createdAt: (j['created_at'] ?? 0).toDouble(),
    anchorLat: j['anchor_lat']?.toDouble(),
    anchorLon: j['anchor_lon']?.toDouble(),
    anchorFixed: j['anchor_fixed'] ?? false,
    distanceM: (j['distance_m'] ?? 0).toDouble(),
    poseTracked: j['pose_tracked'] ?? false,
  );

  Map<String, dynamic> toDb() => {
    'id': id, 'text': text,
    'x': x, 'y': y, 'w': w, 'h': h,
    'color': color, 'visible': visible ? 1 : 0,
    'auto_shown': autoShown ? 1 : 0,
    'created_at': createdAt,
    'anchor_lat': anchorLat, 'anchor_lon': anchorLon,
    'anchor_fixed': anchorFixed ? 1 : 0,
  };

  factory Note.fromDb(Map<String, dynamic> r) => Note(
    id: r['id'], text: r['text'],
    x: r['x'], y: r['y'], w: r['w'], h: r['h'],
    color: r['color'],
    visible: r['visible'] == 1,
    autoShown: r['auto_shown'] == 1,
    createdAt: r['created_at'],
    anchorLat: r['anchor_lat'],
    anchorLon: r['anchor_lon'],
    anchorFixed: r['anchor_fixed'] == 1,
  );
}
