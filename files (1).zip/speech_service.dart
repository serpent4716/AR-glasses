// lib/services/speech_service.dart
//
// Flow:
//   User speaks in ANY language
//   → on-device STT transcribes (speech_to_text package)
//   → if not English, Gemini translates to English
//   → returns final English string
//
// Set GEMINI_API_KEY in lib/config.dart (never commit this to git)

import 'package:speech_to_text/speech_to_text.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'config.dart';

class SpeechResult {
  final String text;
  final String? originalLang; // e.g. "hi" for Hindi
  final bool wasTranslated;
  const SpeechResult(this.text, {this.originalLang, this.wasTranslated = false});
}

class SpeechService {
  static final SpeechService _i = SpeechService._();
  factory SpeechService() => _i;
  SpeechService._();

  final _stt = SpeechToText();
  bool _ready = false;
  bool isListening = false;

  // Gemini model for translation
  late final GenerativeModel _gemini = GenerativeModel(
    model: 'gemini-1.5-flash',
    apiKey: AppConfig.geminiApiKey,
  );

  Future<bool> init() async {
    _ready = await _stt.initialize(
      onStatus: (s) {},
      onError: (e) {},
    );
    return _ready;
  }

  /// Start listening. Calls [onInterim] with live partial text,
  /// calls [onFinal] with translated English result when done.
  Future<void> startListening({
    required void Function(String) onInterim,
    required void Function(SpeechResult) onFinal,
    String localeId = 'en_IN', // default Indian English
  }) async {
    if (!_ready || isListening) return;
    isListening = true;

    await _stt.listen(
      localeId: localeId,
      listenFor: const Duration(seconds: 10),
      pauseFor: const Duration(seconds: 2),
      partialResults: true,
      onResult: (result) async {
        final text = result.recognizedWords.trim();
        if (text.isEmpty) return;

        if (result.finalResult) {
          isListening = false;
          final translated = await _translateIfNeeded(text, localeId);
          onFinal(translated);
        } else {
          onInterim(text);
        }
      },
    );
  }

  Future<void> stopListening() async {
    await _stt.stop();
    isListening = false;
  }

  Future<SpeechResult> _translateIfNeeded(String text, String localeId) async {
    // If locale is already English, skip Gemini call
    if (localeId.startsWith('en')) {
      return SpeechResult(text);
    }

    try {
      final prompt = '''Translate the following text to English. 
Return ONLY the translated text, nothing else, no explanations.
Text: "$text"''';

      final response = await _gemini.generateContent([Content.text(prompt)]);
      final translated = response.text?.trim() ?? text;
      return SpeechResult(
        translated,
        originalLang: localeId.split('_').first,
        wasTranslated: true,
      );
    } catch (e) {
      // Gemini failed — return original text
      return SpeechResult(text);
    }
  }

  /// Get available locales for language picker
  Future<List<LocaleName>> availableLocales() async {
    if (!_ready) return [];
    return _stt.locales();
  }
}
