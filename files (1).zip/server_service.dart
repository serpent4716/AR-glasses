// lib/services/server_service.dart
//
// Runs a lightweight HTTP server on the phone using the `shelf` package.
// The Pi (and later ESP32) connects to this server instead of the phone
// connecting to the Pi. This is the key architectural shift.
//
// Endpoints mirror pi_server.py exactly so the Pi overlay code needs
// zero changes — it just points to the phone IP instead of localhost.
//
// Port 5000 on phone. Pi connects to http://PHONE_IP:5000

import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_router/shelf_router.dart';
import 'note_store.dart';
import 'gps_service.dart';
import '../models/note.dart';

class ServerService {
  static final ServerService _i = ServerService._();
  factory ServerService() => _i;
  ServerService._();

  HttpServer? _server;
  bool get isRunning => _server != null;
  int port = 5000;
  String? localIp;

  Future<void> start() async {
    if (isRunning) return;

    // Get LAN IP so user can see what to enter on Pi
    for (final iface in await NetworkInterface.list()) {
      for (final addr in iface.addresses) {
        if (addr.type == InternetAddressType.IPv4 &&
            !addr.isLoopback) {
          localIp = addr.address;
          break;
        }
      }
      if (localIp != null) break;
    }

    final router = Router()
      ..get('/api/notes', _getNotes)
      ..post('/api/notes', _addNote)
      ..put('/api/notes/<id>', _updateNote)
      ..delete('/api/notes/<id>', _deleteNote)
      ..get('/api/gps', _getGps)
      ..get('/api/slam', _getSlam)
      ..get('/health', _health);

    final handler = Pipeline()
        .addMiddleware(_cors())
        .addMiddleware(logRequests())
        .addHandler(router.call);

    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port);
    print('Server running at http://$localIp:$port');
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
  }

  // ── CORS middleware ──────────────────────────────────────────
  Middleware _cors() {
    return (Handler inner) => (Request req) async {
      if (req.method == 'OPTIONS') {
        return Response.ok('', headers: _corsHeaders);
      }
      final res = await inner(req);
      return res.change(headers: _corsHeaders);
    };
  }

  static const _corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  Response _json(Object data, {int status = 200}) => Response(
    status,
    body: jsonEncode(data),
    headers: {'Content-Type': 'application/json'},
  );

  // ── Endpoints ────────────────────────────────────────────────
  Future<Response> _getNotes(Request req) async {
    final notes = await NoteStore().all();
    return _json(notes.map((n) => n.toJson()).toList());
  }

  Future<Response> _addNote(Request req) async {
    final body = jsonDecode(await req.readAsString()) as Map;
    final text = (body['text'] as String?)?.trim() ?? '';
    if (text.isEmpty) return _json({'error': 'empty text'}, status: 400);

    final gps = GpsService().current;
    final note = Note(
      id: DateTime.now().millisecondsSinceEpoch.toRadixString(16),
      text: text,
      color: body['color'] as String? ?? '#00FF88',
      createdAt: DateTime.now().millisecondsSinceEpoch / 1000,
      anchorLat: gps.lat,
      anchorLon: gps.lon,
      anchorFixed: gps.fix,
    );
    await NoteStore().insert(note);
    return _json({'ok': true, 'id': note.id}, status: 201);
  }

  Future<Response> _updateNote(Request req, String id) async {
    final body = jsonDecode(await req.readAsString()) as Map;
    final notes = await NoteStore().all();
    final note = notes.firstWhere((n) => n.id == id,
        orElse: () => throw StateError('not found'));
    if (body.containsKey('visible')) note.visible = body['visible'] as bool;
    if (body.containsKey('text'))    note.text    = body['text'] as String;
    if (body.containsKey('color'))   note.color   = body['color'] as String;
    if (body.containsKey('x'))       note.x       = (body['x'] as num).toDouble();
    if (body.containsKey('y'))       note.y       = (body['y'] as num).toDouble();
    if (body.containsKey('w'))       note.w       = (body['w'] as num).toDouble();
    if (body.containsKey('h'))       note.h       = (body['h'] as num).toDouble();
    await NoteStore().update(note);
    return _json({'ok': true});
  }

  Future<Response> _deleteNote(Request req, String id) async {
    await NoteStore().delete(id);
    return _json({'ok': true});
  }

  Future<Response> _getGps(Request req) async {
    final g = GpsService().current;
    return _json({
      'lat': g.lat, 'lon': g.lon,
      'fix': g.fix, 'accuracy': g.accuracy,
      'satellites': 0, // geolocator doesn't expose this easily
    });
  }

  Future<Response> _getSlam(Request req) async {
    // Placeholder — will be populated when Termux SLAM is integrated
    return _json({'tracking': false, 'keypoints': 0, 'fps': 0});
  }

  Future<Response> _health(Request req) =>
      Future.value(_json({'status': 'ok', 'ip': localIp}));
}
