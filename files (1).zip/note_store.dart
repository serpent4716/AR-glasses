// lib/services/note_store.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/note.dart';

class NoteStore {
  static final NoteStore _i = NoteStore._();
  factory NoteStore() => _i;
  NoteStore._();

  Database? _db;

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'locusmind.db');
    return openDatabase(path, version: 1, onCreate: (db, _) {
      db.execute('''CREATE TABLE notes(
        id TEXT PRIMARY KEY, text TEXT,
        x REAL, y REAL, w REAL, h REAL,
        color TEXT, visible INTEGER, auto_shown INTEGER,
        created_at REAL,
        anchor_lat REAL, anchor_lon REAL, anchor_fixed INTEGER
      )''');
    });
  }

  Future<List<Note>> all() async {
    final rows = await (await db).query('notes', orderBy: 'created_at DESC');
    return rows.map(Note.fromDb).toList();
  }

  Future<void> insert(Note n) async =>
      (await db).insert('notes', n.toDb(),
          conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> update(Note n) async =>
      (await db).update('notes', n.toDb(),
          where: 'id = ?', whereArgs: [n.id]);

  Future<void> delete(String id) async =>
      (await db).delete('notes', where: 'id = ?', whereArgs: [id]);

  Future<void> clear() async => (await db).delete('notes');
}
