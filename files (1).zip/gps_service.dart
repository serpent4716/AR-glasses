// lib/services/gps_service.dart
import 'dart:async';
import 'dart:math';
import 'package:geolocator/geolocator.dart';

class GpsState {
  final double? lat, lon;
  final bool fix;
  final double accuracy; // metres
  const GpsState({this.lat, this.lon, this.fix = false, this.accuracy = 999});
}

class GpsService {
  static final GpsService _i = GpsService._();
  factory GpsService() => _i;
  GpsService._();

  final _latBuf = <double>[];
  final _lonBuf = <double>[];
  final _bufSize = 10;

  GpsState current = const GpsState();
  final _controller = StreamController<GpsState>.broadcast();
  Stream<GpsState> get stream => _controller.stream;

  StreamSubscription? _sub;

  Future<void> start() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied) return;
    }

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 1, // update every 1 metre
      ),
    ).listen(_onPosition);
  }

  void _onPosition(Position p) {
    _latBuf.add(p.latitude);
    _lonBuf.add(p.longitude);
    if (_latBuf.length > _bufSize) {
      _latBuf.removeAt(0);
      _lonBuf.removeAt(0);
    }
    // Median filter — kills GPS outlier spikes
    final lats = List<double>.from(_latBuf)..sort();
    final lons = List<double>.from(_lonBuf)..sort();
    final mid = lats.length ~/ 2;
    final slat = lats[mid];
    final slon = lons[mid];

    current = GpsState(lat: slat, lon: slon, fix: true, accuracy: p.accuracy);
    _controller.add(current);
  }

  /// Haversine distance in metres between two coordinates
  static double haversine(double la1, double lo1, double la2, double lo2) {
    const R = 6371000.0;
    final p1 = la1 * pi / 180, p2 = la2 * pi / 180;
    final dp = (la2 - la1) * pi / 180, dl = (lo2 - lo1) * pi / 180;
    final a = sin(dp / 2) * sin(dp / 2) +
        cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2);
    return R * 2 * atan2(sqrt(a), sqrt(1 - a));
  }

  void stop() {
    _sub?.cancel();
    _controller.close();
  }
}
