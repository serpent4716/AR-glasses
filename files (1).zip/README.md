# LocusMind Flutter App — Setup Guide
# =====================================

## Prerequisites
- Flutter SDK 3.x  →  https://flutter.dev/docs/get-started/install
- Android Studio (for Android SDK)
- Android phone with USB debugging enabled

## Project structure
```
locusmind/
  lib/
    main.dart                  — app entry
    config.dart                — API keys (add to .gitignore)
    models/note.dart           — data model
    services/
      note_store.dart          — SQLite persistence
      gps_service.dart         — location with median filter
      speech_service.dart      — STT + Gemini translation
      server_service.dart      — HTTP server (phone serves Pi)
    screens/home_screen.dart   — main UI
    widgets/note_card.dart     — note tile
```

## Step 1 — Get Gemini API key
1. Go to https://aistudio.google.com/app/apikey
2. Create a free key
3. Paste it into lib/config.dart:
   static const geminiApiKey = 'YOUR_KEY_HERE';

## Step 2 — Set Pi IP
In lib/config.dart:
  static const piServerUrl = 'http://10.25.218.154:5000';

## Step 3 — Run the app
```bash
cd locusmind
flutter pub get
flutter run
```

## Step 4 — Connect Pi to phone server
The app displays its IP in the server banner at the top.
Update pi_server.py to point to phone instead of itself:

  # This change is NOT needed yet — Pi still serves itself
  # When we flip architecture (Phase 3), Pi will connect to phone

## Step 5 — How to use
1. Open app on phone
2. Green server banner shows: http://192.168.x.x:5000
3. Point Pi's pi_server.py at this address (future)
4. Tap mic → speak in any language → auto-translates → auto-sends note
5. Or type → tap SEND
6. Toggle ON/OFF to show/hide on Pi display
7. X to delete

## Voice languages supported
- English (India) — default, no translation needed
- Hindi, Bengali, Tamil, Telugu, Marathi, Gujarati
- Gemini translates to English before saving

## Background server
The shelf HTTP server runs in the Flutter process.
Android may kill it after ~10 minutes in background.
For always-on: enable flutter_background_service (future phase).
For now: keep app in foreground while doing AR demos.

## .gitignore — add these
lib/config.dart
*.npy
dataset/
